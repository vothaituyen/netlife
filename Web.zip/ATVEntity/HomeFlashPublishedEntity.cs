using System;
using System.Collections.Generic;
using System.Text;

namespace ATVEntity
{
    class HomeFlashPublishedEntity
    {
        string Image;
        string link;
        string title;
        string sapo;
    }
}
