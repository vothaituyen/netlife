function showJWPlayer(e, t, n, i, r, s) {
    var o = {
        file: t,
        height: r,
        width: i,
        mute: false,
        autostart: true,
        primary: flash,
        advertising: {
            skipoffset: 5,
            client: vast
            //,tag: http://delivery.adnetwork.vn/247/xmlvideoad/zid_1402387259/wid_1245836202/type_inline/cb_[timestamp]/w_[player-width]/h_[player-height]/purl_[content-page-url]
        }
    };
    jwplayer(e).setup(o)
}

function showMediaplayer() {
    $(".fmsmedia").length > 0 && $(".fmsmedia").fmsmedia()
}

function showMediaPlayer(e, t, n, i, r, s) {
    var o = {
        flashplayer: "http://static.netlife.vn/Images/swfplayer.swf",
        width: i,
        height: r,
        starttime: 0,
        autostart: null == s ? !1 : s,
        skin: "/Images/newtubedark/newtubedark.xml",
        controlbar: "bottom",
        playlist: "none",
        "playlist.position": "bottom",
        "playlist.size": "0",
        image: n,
        file: t,
        logo: {
            file: "",
            link: "",
            hide: !1,
            position: "top-left"
        },
        plugins: {
            "ova-jw": {
                canFireEventAPICalls: !0,
                ads: {
                    skipAd: {
                        enabled: "true",
                        minimumAdDuration: 6,
                        showAfterSeconds: 3,
                        image: "http://clip.vietnamnetjsc.vn/Images/skip-ad.png",
                        width: 75,
                        height: 20
                    },
                    schedule: [{
                        position: "pre-roll",
                        tag: "https://ima3vpaid.appspot.com/?adTagUrl=http%3A%2F%2Fgoogleads.g.doubleclick.net%2Fpagead%2Fads%3Fad_type%3Dvideo_image_flash%26client%3Dca-video-pub-3139852990257667%26description_url%3Dhttp%253A%252F%252Fclip.netlife.com.vn%26videoad_start_delay%3D0%26hl%3Dvi%26max_ad_duration%3D15000"
                    }]
                }
            }
        }
    };
    jwplayer(e).setup(o)
}
if ("undefined" == typeof jQuery && ! function (e, t) {
    function n(e) {
        var t = he[e] = {};
        return Z.each(e.split(te), function (e, n) {
            t[n] = !0
        }), t
    }

    function i(e, n, i) {
        if (i === t && 1 === e.nodeType) {
            var r = "data-" + n.replace(me, "-$1").toLowerCase();
            if (i = e.getAttribute(r), "string" == typeof i) {
                try {
                    i = "true" === i ? !0 : "false" === i ? !1 : "null" === i ? null : +i + "" === i ? +i : ge.test(i) ? Z.parseJSON(i) : i
                } catch (s) { }
                Z.data(e, n, i)
            } else i = t
        }
        return i
    }

    function r(e) {
        var t;
        for (t in e)
            if (("data" !== t || !Z.isEmptyObject(e[t])) && "toJSON" !== t) return !1;
        return !0
    }

    function s() {
        return !1
    }

    function o() {
        return !0
    }

    function a(e) {
        return !e || !e.parentNode || 11 === e.parentNode.nodeType
    }

    function l(e, t) {
        do e = e[t]; while (e && 1 !== e.nodeType);
        return e
    }

    function u(e, t, n) {
        if (t = t || 0, Z.isFunction(t)) return Z.grep(e, function (e, i) {
            var r = !!t.call(e, i, e);
            return r === n
        });
        if (t.nodeType) return Z.grep(e, function (e) {
            return e === t === n
        });
        if ("string" == typeof t) {
            var i = Z.grep(e, function (e) {
                return 1 === e.nodeType
            });
            if (Me.test(t)) return Z.filter(t, i, !n);
            t = Z.filter(t, i)
        }
        return Z.grep(e, function (e) {
            return Z.inArray(e, t) >= 0 === n
        })
    }

    function c(e) {
        var t = Fe.split("|"),
            n = e.createDocumentFragment();
        if (n.createElement)
            for (; t.length;) n.createElement(t.pop());
        return n
    }

    function d(e, t) {
        return e.getElementsByTagName(t)[0] || e.appendChild(e.ownerDocument.createElement(t))
    }

    function p(e, t) {
        if (1 === t.nodeType && Z.hasData(e)) {
            var n, i, r, s = Z._data(e),
                o = Z._data(t, s),
                a = s.events;
            if (a) {
                delete o.handle, o.events = {};
                for (n in a)
                    for (i = 0, r = a[n].length; r > i; i++) Z.event.add(t, n, a[n][i])
            }
            o.data && (o.data = Z.extend({}, o.data))
        }
    }

    function f(e, t) {
        var n;
        1 === t.nodeType && (t.clearAttributes && t.clearAttributes(), t.mergeAttributes && t.mergeAttributes(e), n = t.nodeName.toLowerCase(), "object" === n ? (t.parentNode && (t.outerHTML = e.outerHTML), Z.support.html5Clone && e.innerHTML && !Z.trim(t.innerHTML) && (t.innerHTML = e.innerHTML)) : "input" === n && qe.test(e.type) ? (t.defaultChecked = t.checked = e.checked, t.value !== e.value && (t.value = e.value)) : "option" === n ? t.selected = e.defaultSelected : "input" === n || "textarea" === n ? t.defaultValue = e.defaultValue : "script" === n && t.text !== e.text && (t.text = e.text), t.removeAttribute(Z.expando))
    }

    function h(e) {
        return "undefined" != typeof e.getElementsByTagName ? e.getElementsByTagName("*") : "undefined" != typeof e.querySelectorAll ? e.querySelectorAll("*") : []
    }

    function g(e) {
        qe.test(e.type) && (e.defaultChecked = e.checked)
    }

    function m(e, t) {
        if (t in e) return t;
        for (var n = t.charAt(0).toUpperCase() + t.slice(1), i = t, r = yt.length; r--;)
            if (t = yt[r] + n, t in e) return t;
        return i
    }

    function y(e, t) {
        return e = t || e, "none" === Z.css(e, "display") || !Z.contains(e.ownerDocument, e)
    }

    function v(e, t) {
        for (var n, i, r = [], s = 0, o = e.length; o > s; s++) n = e[s], n.style && (r[s] = Z._data(n, "olddisplay"), t ? (!r[s] && "none" === n.style.display && (n.style.display = ""), "" === n.style.display && y(n) && (r[s] = Z._data(n, "olddisplay", b(n.nodeName)))) : (i = nt(n, "display"), !r[s] && "none" !== i && Z._data(n, "olddisplay", i)));
        for (s = 0; o > s; s++) n = e[s], n.style && (t && "none" !== n.style.display && "" !== n.style.display || (n.style.display = t ? r[s] || "" : "none"));
        return e
    }

    function A(e, t, n) {
        var i = ct.exec(t);
        return i ? Math.max(0, i[1] - (n || 0)) + (i[2] || "px") : t
    }

    function w(e, t, n, i) {
        for (var r = n === (i ? "border" : "content") ? 4 : "width" === t ? 1 : 0, s = 0; 4 > r; r += 2) "margin" === n && (s += Z.css(e, n + mt[r], !0)), i ? ("content" === n && (s -= parseFloat(nt(e, "padding" + mt[r])) || 0), "margin" !== n && (s -= parseFloat(nt(e, "border" + mt[r] + "Width")) || 0)) : (s += parseFloat(nt(e, "padding" + mt[r])) || 0, "padding" !== n && (s += parseFloat(nt(e, "border" + mt[r] + "Width")) || 0));
        return s
    }

    function E(e, t, n) {
        var i = "width" === t ? e.offsetWidth : e.offsetHeight,
            r = !0,
            s = Z.support.boxSizing && "border-box" === Z.css(e, "boxSizing");
        if (0 >= i || null == i) {
            if (i = nt(e, t), (0 > i || null == i) && (i = e.style[t]), dt.test(i)) return i;
            r = s && (Z.support.boxSizingReliable || i === e.style[t]), i = parseFloat(i) || 0
        }
        return i + w(e, t, n || (s ? "border" : "content"), r) + "px"
    }

    function b(e) {
        if (ft[e]) return ft[e];
        var t = Z("<" + e + ">").appendTo(W.body),
            n = t.css("display");
        return t.remove(), "none" !== n && "" !== n || (it = W.body.appendChild(it || Z.extend(W.createElement("iframe"), {
            frameBorder: 0,
            width: 0,
            height: 0
        })), rt && it.createElement || (rt = (it.contentWindow || it.contentDocument).document, rt.write("<!doctype html><html><body>"), rt.close()), t = rt.body.appendChild(rt.createElement(e)), n = nt(t, "display"), W.body.removeChild(it)), ft[e] = n, n
    }

    function x(e, t, n, i) {
        var r;
        if (Z.isArray(t)) Z.each(t, function (t, r) {
            n || wt.test(e) ? i(e, r) : x(e + "[" + ("object" == typeof r ? t : "") + "]", r, n, i)
        });
        else if (n || "object" !== Z.type(t)) i(e, t);
        else
            for (r in t) x(e + "[" + r + "]", t[r], n, i)
    }

    function _(e) {
        return function (t, n) {
            "string" != typeof t && (n = t, t = "*");
            var i, r, s, o = t.toLowerCase().split(te),
                a = 0,
                l = o.length;
            if (Z.isFunction(n))
                for (; l > a; a++) i = o[a], s = /^\+/.test(i), s && (i = i.substr(1) || "*"), r = e[i] = e[i] || [], r[s ? "unshift" : "push"](n)
        }
    }

    function k(e, n, i, r, s, o) {
        s = s || n.dataTypes[0], o = o || {}, o[s] = !0;
        for (var a, l = e[s], u = 0, c = l ? l.length : 0, d = e === Mt; c > u && (d || !a); u++) a = l[u](n, i, r), "string" == typeof a && (!d || o[a] ? a = t : (n.dataTypes.unshift(a), a = k(e, n, i, r, a, o)));
        return (d || !a) && !o["*"] && (a = k(e, n, i, r, "*", o)), a
    }

    function L(e, n) {
        var i, r, s = Z.ajaxSettings.flatOptions || {};
        for (i in n) n[i] !== t && ((s[i] ? e : r || (r = {}))[i] = n[i]);
        r && Z.extend(!0, e, r)
    }

    function I(e, n, i) {
        var r, s, o, a, l = e.contents,
            u = e.dataTypes,
            c = e.responseFields;
        for (s in c) s in i && (n[c[s]] = i[s]);
        for (;
            "*" === u[0];) u.shift(), r === t && (r = e.mimeType || n.getResponseHeader("content-type"));
        if (r)
            for (s in l)
                if (l[s] && l[s].test(r)) {
                    u.unshift(s);
                    break
                }
        if (u[0] in i) o = u[0];
        else {
            for (s in i) {
                if (!u[0] || e.converters[s + " " + u[0]]) {
                    o = s;
                    break
                }
                a || (a = s)
            }
            o = o || a
        }
        return o ? (o !== u[0] && u.unshift(o), i[o]) : void 0
    }

    function S(e, t) {
        var n, i, r, s, o = e.dataTypes.slice(),
            a = o[0],
            l = {},
            u = 0;
        if (e.dataFilter && (t = e.dataFilter(t, e.dataType)), o[1])
            for (n in e.converters) l[n.toLowerCase()] = e.converters[n];
        for (; r = o[++u];)
            if ("*" !== r) {
                if ("*" !== a && a !== r) {
                    if (n = l[a + " " + r] || l["* " + r], !n)
                        for (i in l)
                            if (s = i.split(" "), s[1] === r && (n = l[a + " " + s[0]] || l["* " + s[0]])) {
                                n === !0 ? n = l[i] : l[i] !== !0 && (r = s[0], o.splice(u--, 0, r));
                                break
                            }
                    if (n !== !0)
                        if (n && e["throws"]) t = n(t);
                        else try {
                            t = n(t)
                        } catch (c) {
                            return {
                                state: "parsererror",
                                error: n ? c : "No conversion from " + a + " to " + r
                            }
                        }
                }
                a = r
            }
        return {
            state: "success",
            data: t
        }
    }

    function j() {
        try {
            return new e.XMLHttpRequest
        } catch (t) { }
    }

    function N() {
        try {
            return new e.ActiveXObject("Microsoft.XMLHTTP")
        } catch (t) { }
    }

    function R() {
        return setTimeout(function () {
            zt = t
        }, 0), zt = Z.now()
    }

    function T(e, t) {
        Z.each(t, function (t, n) {
            for (var i = ($t[t] || []).concat($t["*"]), r = 0, s = i.length; s > r; r++)
                if (i[r].call(e, t, n)) return
        })
    }

    function P(e, t, n) {
        var i, r = 0,
            s = Zt.length,
            o = Z.Deferred().always(function () {
                delete a.elem
            }),
            a = function () {
                for (var t = zt || R(), n = Math.max(0, l.startTime + l.duration - t), i = 1 - (n / l.duration || 0), r = 0, s = l.tweens.length; s > r; r++) l.tweens[r].run(i);
                return o.notifyWith(e, [l, i, n]), 1 > i && s ? n : (o.resolveWith(e, [l]), !1)
            },
            l = o.promise({
                elem: e,
                props: Z.extend({}, t),
                opts: Z.extend(!0, {
                    specialEasing: {}
                }, n),
                originalProperties: t,
                originalOptions: n,
                startTime: zt || R(),
                duration: n.duration,
                tweens: [],
                createTween: function (t, n) {
                    var i = Z.Tween(e, l.opts, t, n, l.opts.specialEasing[t] || l.opts.easing);
                    return l.tweens.push(i), i
                },
                stop: function (t) {
                    for (var n = 0, i = t ? l.tweens.length : 0; i > n; n++) l.tweens[n].run(1);
                    return t ? o.resolveWith(e, [l, t]) : o.rejectWith(e, [l, t]), this
                }
            }),
            u = l.props;
        for (C(u, l.opts.specialEasing); s > r; r++)
            if (i = Zt[r].call(l, e, u, l.opts)) return i;
        return T(l, u), Z.isFunction(l.opts.start) && l.opts.start.call(e, l), Z.fx.timer(Z.extend(a, {
            anim: l,
            queue: l.opts.queue,
            elem: e
        })), l.progress(l.opts.progress).done(l.opts.done, l.opts.complete).fail(l.opts.fail).always(l.opts.always)
    }

    function C(e, t) {
        var n, i, r, s, o;
        for (n in e)
            if (i = Z.camelCase(n), r = t[i], s = e[n], Z.isArray(s) && (r = s[1], s = e[n] = s[0]), n !== i && (e[i] = s, delete e[n]), o = Z.cssHooks[i], o && "expand" in o) {
                s = o.expand(s), delete e[i];
                for (n in s) n in e || (e[n] = s[n], t[n] = r)
            } else t[i] = r
    }

    function D(e, t, n) {
        var i, r, s, o, a, l, u, c, d = this,
            p = e.style,
            f = {},
            h = [],
            g = e.nodeType && y(e);
        n.queue || (u = Z._queueHooks(e, "fx"), null == u.unqueued && (u.unqueued = 0, c = u.empty.fire, u.empty.fire = function () {
            u.unqueued || c()
        }), u.unqueued++ , d.always(function () {
            d.always(function () {
                u.unqueued-- , Z.queue(e, "fx").length || u.empty.fire()
            })
        })), 1 === e.nodeType && ("height" in t || "width" in t) && (n.overflow = [p.overflow, p.overflowX, p.overflowY], "inline" === Z.css(e, "display") && "none" === Z.css(e, "float") && (Z.support.inlineBlockNeedsLayout && "inline" !== b(e.nodeName) ? p.zoom = 1 : p.display = "inline-block")), n.overflow && (p.overflow = "hidden", Z.support.shrinkWrapBlocks || d.done(function () {
            p.overflow = n.overflow[0], p.overflowX = n.overflow[1], p.overflowY = n.overflow[2]
        }));
        for (i in t)
            if (s = t[i], qt.exec(s)) {
                if (delete t[i], s === (g ? "hide" : "show")) continue;
                h.push(i)
            }
        if (o = h.length)
            for (a = Z._data(e, "fxshow") || Z._data(e, "fxshow", {}), g ? Z(e).show() : d.done(function () {
                Z(e).hide()
            }), d.done(function () {
                var t;
                Z.removeData(e, "fxshow", !0);
                for (t in f) Z.style(e, t, f[t])
            }), i = 0; o > i; i++) r = h[i], l = d.createTween(r, g ? a[r] : 0), f[r] = a[r] || Z.style(e, r), r in a || (a[r] = l.start, g && (l.end = l.start, l.start = "width" === r || "height" === r ? 1 : 0))
    }

    function M(e, t, n, i, r) {
        return new M.prototype.init(e, t, n, i, r)
    }

    function O(e, t) {
        var n, i = {
            height: e
        },
            r = 0;
        for (t = t ? 1 : 0; 4 > r; r += 2 - t) n = mt[r], i["margin" + n] = i["padding" + n] = e;
        return t && (i.opacity = i.width = e), i
    }

    function B(e) {
        return Z.isWindow(e) ? e : 9 === e.nodeType ? e.defaultView || e.parentWindow : !1
    }
    var F, Y, W = e.document,
        G = e.location,
        U = e.navigator,
        H = e.jQuery,
        J = e.$,
        V = Array.prototype.push,
        z = Array.prototype.slice,
        Q = Array.prototype.indexOf,
        q = Object.prototype.toString,
        X = Object.prototype.hasOwnProperty,
        K = String.prototype.trim,
        Z = function (e, t) {
            return new Z.fn.init(e, t, F)
        },
        $ = /[\-+]?(?:\d*\.|)\d+(?:[eE][\-+]?\d+|)/.source,
        ee = /\S/,
        te = /\s+/,
        ne = /^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g,
        ie = /^(?:[^#<]*(<[\w\W]+>)[^>]*$|#([\w\-]*)$)/,
        re = /^<(\w+)\s*\/?>(?:<\/\1>|)$/,
        se = /^[\],:{}\s]*$/,
        oe = /(?:^|:|,)(?:\s*\[)+/g,
        ae = /\\(?:["\\\/bfnrt]|u[\da-fA-F]{4})/g,
        le = /"[^"\\\r\n]*"|true|false|null|-?(?:\d\d*\.|)\d+(?:[eE][\-+]?\d+|)/g,
        ue = /^-ms-/,
        ce = /-([\da-z])/gi,
        de = function (e, t) {
            return (t + "").toUpperCase()
        },
        pe = function () {
            W.addEventListener ? (W.removeEventListener("DOMContentLoaded", pe, !1), Z.ready()) : "complete" === W.readyState && (W.detachEvent("onreadystatechange", pe), Z.ready())
        },
        fe = {};
    Z.fn = Z.prototype = {
        constructor: Z,
        init: function (e, n, i) {
            var r, s, o;
            if (!e) return this;
            if (e.nodeType) return this.context = this[0] = e, this.length = 1, this;
            if ("string" == typeof e) {
                if (r = "<" === e.charAt(0) && ">" === e.charAt(e.length - 1) && e.length >= 3 ? [null, e, null] : ie.exec(e), r && (r[1] || !n)) {
                    if (r[1]) return n = n instanceof Z ? n[0] : n, o = n && n.nodeType ? n.ownerDocument || n : W, e = Z.parseHTML(r[1], o, !0), re.test(r[1]) && Z.isPlainObject(n) && this.attr.call(e, n, !0), Z.merge(this, e);
                    if (s = W.getElementById(r[2]), s && s.parentNode) {
                        if (s.id !== r[2]) return i.find(e);
                        this.length = 1, this[0] = s
                    }
                    return this.context = W, this.selector = e, this
                }
                return !n || n.jquery ? (n || i).find(e) : this.constructor(n).find(e)
            }
            return Z.isFunction(e) ? i.ready(e) : (e.selector !== t && (this.selector = e.selector, this.context = e.context), Z.makeArray(e, this))
        },
        selector: "",
        jquery: "1.8.2",
        length: 0,
        size: function () {
            return this.length
        },
        toArray: function () {
            return z.call(this)
        },
        get: function (e) {
            return null == e ? this.toArray() : 0 > e ? this[this.length + e] : this[e]
        },
        pushStack: function (e, t, n) {
            var i = Z.merge(this.constructor(), e);
            return i.prevObject = this, i.context = this.context, "find" === t ? i.selector = this.selector + (this.selector ? " " : "") + n : t && (i.selector = this.selector + "." + t + "(" + n + ")"), i
        },
        each: function (e, t) {
            return Z.each(this, e, t)
        },
        ready: function (e) {
            return Z.ready.promise().done(e), this
        },
        eq: function (e) {
            return e = +e, -1 === e ? this.slice(e) : this.slice(e, e + 1)
        },
        first: function () {
            return this.eq(0)
        },
        last: function () {
            return this.eq(-1)
        },
        slice: function () {
            return this.pushStack(z.apply(this, arguments), "slice", z.call(arguments).join(","))
        },
        map: function (e) {
            return this.pushStack(Z.map(this, function (t, n) {
                return e.call(t, n, t)
            }))
        },
        end: function () {
            return this.prevObject || this.constructor(null)
        },
        push: V,
        sort: [].sort,
        splice: [].splice
    }, Z.fn.init.prototype = Z.fn, Z.extend = Z.fn.extend = function () {
        var e, n, i, r, s, o, a = arguments[0] || {},
            l = 1,
            u = arguments.length,
            c = !1;
        for ("boolean" == typeof a && (c = a, a = arguments[1] || {}, l = 2), "object" != typeof a && !Z.isFunction(a) && (a = {}), u === l && (a = this, --l); u > l; l++)
            if (null != (e = arguments[l]))
                for (n in e) i = a[n], r = e[n], a !== r && (c && r && (Z.isPlainObject(r) || (s = Z.isArray(r))) ? (s ? (s = !1, o = i && Z.isArray(i) ? i : []) : o = i && Z.isPlainObject(i) ? i : {}, a[n] = Z.extend(c, o, r)) : r !== t && (a[n] = r));
        return a
    }, Z.extend({
        noConflict: function (t) {
            return e.$ === Z && (e.$ = J), t && e.jQuery === Z && (e.jQuery = H), Z
        },
        isReady: !1,
        readyWait: 1,
        holdReady: function (e) {
            e ? Z.readyWait++ : Z.ready(!0)
        },
        ready: function (e) {
            if (e === !0 ? !--Z.readyWait : !Z.isReady) {
                if (!W.body) return setTimeout(Z.ready, 1);
                Z.isReady = !0, e !== !0 && --Z.readyWait > 0 || (Y.resolveWith(W, [Z]), Z.fn.trigger && Z(W).trigger("ready").off("ready"))
            }
        },
        isFunction: function (e) {
            return "function" === Z.type(e)
        },
        isArray: Array.isArray || function (e) {
            return "array" === Z.type(e)
        },
        isWindow: function (e) {
            return null != e && e == e.window
        },
        isNumeric: function (e) {
            return !isNaN(parseFloat(e)) && isFinite(e)
        },
        type: function (e) {
            return null == e ? String(e) : fe[q.call(e)] || "object"
        },
        isPlainObject: function (e) {
            if (!e || "object" !== Z.type(e) || e.nodeType || Z.isWindow(e)) return !1;
            try {
                if (e.constructor && !X.call(e, "constructor") && !X.call(e.constructor.prototype, "isPrototypeOf")) return !1
            } catch (n) {
                return !1
            }
            var i;
            for (i in e);
            return i === t || X.call(e, i)
        },
        isEmptyObject: function (e) {
            var t;
            for (t in e) return !1;
            return !0
        },
        error: function (e) {
            throw new Error(e)
        },
        parseHTML: function (e, t, n) {
            var i;
            return e && "string" == typeof e ? ("boolean" == typeof t && (n = t, t = 0), t = t || W, (i = re.exec(e)) ? [t.createElement(i[1])] : (i = Z.buildFragment([e], t, n ? null : []), Z.merge([], (i.cacheable ? Z.clone(i.fragment) : i.fragment).childNodes))) : null
        },
        parseJSON: function (t) {
            return t && "string" == typeof t ? (t = Z.trim(t), e.JSON && e.JSON.parse ? e.JSON.parse(t) : se.test(t.replace(ae, "@").replace(le, "]").replace(oe, "")) ? new Function("return " + t)() : void Z.error("Invalid JSON: " + t)) : null
        },
        parseXML: function (n) {
            var i, r;
            if (!n || "string" != typeof n) return null;
            try {
                e.DOMParser ? (r = new DOMParser, i = r.parseFromString(n, "text/xml")) : (i = new ActiveXObject("Microsoft.XMLDOM"), i.async = "false", i.loadXML(n))
            } catch (s) {
                i = t
            }
            return (!i || !i.documentElement || i.getElementsByTagName("parsererror").length) && Z.error("Invalid XML: " + n), i
        },
        noop: function () { },
        globalEval: function (t) {
            t && ee.test(t) && (e.execScript || function (t) {
                e.eval.call(e, t)
            })(t)
        },
        camelCase: function (e) {
            return e.replace(ue, "ms-").replace(ce, de)
        },
        nodeName: function (e, t) {
            return e.nodeName && e.nodeName.toLowerCase() === t.toLowerCase()
        },
        each: function (e, n, i) {
            var r, s = 0,
                o = e.length,
                a = o === t || Z.isFunction(e);
            if (i)
                if (a) {
                    for (r in e)
                        if (n.apply(e[r], i) === !1) break
                } else
                    for (; o > s && n.apply(e[s++], i) !== !1;);
            else if (a) {
                for (r in e)
                    if (n.call(e[r], r, e[r]) === !1) break
            } else
                for (; o > s && n.call(e[s], s, e[s++]) !== !1;);
            return e
        },
        trim: K && !K.call("\ufeff ") ? function (e) {
            return null == e ? "" : K.call(e)
        } : function (e) {
            return null == e ? "" : (e + "").replace(ne, "")
        },
        makeArray: function (e, t) {
            var n, i = t || [];
            return null != e && (n = Z.type(e), null == e.length || "string" === n || "function" === n || "regexp" === n || Z.isWindow(e) ? V.call(i, e) : Z.merge(i, e)), i
        },
        inArray: function (e, t, n) {
            var i;
            if (t) {
                if (Q) return Q.call(t, e, n);
                for (i = t.length, n = n ? 0 > n ? Math.max(0, i + n) : n : 0; i > n; n++)
                    if (n in t && t[n] === e) return n
            }
            return -1
        },
        merge: function (e, n) {
            var i = n.length,
                r = e.length,
                s = 0;
            if ("number" == typeof i)
                for (; i > s; s++) e[r++] = n[s];
            else
                for (; n[s] !== t;) e[r++] = n[s++];
            return e.length = r, e
        },
        grep: function (e, t, n) {
            var i, r = [],
                s = 0,
                o = e.length;
            for (n = !!n; o > s; s++) i = !!t(e[s], s), n !== i && r.push(e[s]);
            return r
        },
        map: function (e, n, i) {
            var r, s, o = [],
                a = 0,
                l = e.length,
                u = e instanceof Z || l !== t && "number" == typeof l && (l > 0 && e[0] && e[l - 1] || 0 === l || Z.isArray(e));
            if (u)
                for (; l > a; a++) r = n(e[a], a, i), null != r && (o[o.length] = r);
            else
                for (s in e) r = n(e[s], s, i), null != r && (o[o.length] = r);
            return o.concat.apply([], o)
        },
        guid: 1,
        proxy: function (e, n) {
            var i, r, s;
            return "string" == typeof n && (i = e[n], n = e, e = i), Z.isFunction(e) ? (r = z.call(arguments, 2), s = function () {
                return e.apply(n, r.concat(z.call(arguments)))
            }, s.guid = e.guid = e.guid || Z.guid++ , s) : t
        },
        access: function (e, n, i, r, s, o, a) {
            var l, u = null == i,
                c = 0,
                d = e.length;
            if (i && "object" == typeof i) {
                for (c in i) Z.access(e, n, c, i[c], 1, o, r);
                s = 1
            } else if (r !== t) {
                if (l = a === t && Z.isFunction(r), u && (l ? (l = n, n = function (e, t, n) {
                    return l.call(Z(e), n)
                }) : (n.call(e, r), n = null)), n)
                    for (; d > c; c++) n(e[c], i, l ? r.call(e[c], c, n(e[c], i)) : r, a);
                s = 1
            }
            return s ? e : u ? n.call(e) : d ? n(e[0], i) : o
        },
        now: function () {
            return (new Date).getTime()
        }
    }), Z.ready.promise = function (t) {
        if (!Y)
            if (Y = Z.Deferred(), "complete" === W.readyState) setTimeout(Z.ready, 1);
            else if (W.addEventListener) W.addEventListener("DOMContentLoaded", pe, !1), e.addEventListener("load", Z.ready, !1);
            else {
                W.attachEvent("onreadystatechange", pe), e.attachEvent("onload", Z.ready);
                var n = !1;
                try {
                    n = null == e.frameElement && W.documentElement
                } catch (i) { }
                n && n.doScroll && function r() {
                    if (!Z.isReady) {
                        try {
                            n.doScroll("left")
                        } catch (e) {
                            return setTimeout(r, 50)
                        }
                        Z.ready()
                    }
                }()
            }
        return Y.promise(t)
    }, Z.each("Boolean Number String Function Array Date RegExp Object".split(" "), function (e, t) {
        fe["[object " + t + "]"] = t.toLowerCase()
    }), F = Z(W);
    var he = {};
    Z.Callbacks = function (e) {
        e = "string" == typeof e ? he[e] || n(e) : Z.extend({}, e);
        var i, r, s, o, a, l, u = [],
            c = !e.once && [],
            d = function (t) {
                for (i = e.memory && t, r = !0, l = o || 0, o = 0, a = u.length, s = !0; u && a > l; l++)
                    if (u[l].apply(t[0], t[1]) === !1 && e.stopOnFalse) {
                        i = !1;
                        break
                    }
                s = !1, u && (c ? c.length && d(c.shift()) : i ? u = [] : p.disable())
            },
            p = {
                add: function () {
                    if (u) {
                        var t = u.length;
                        ! function n(t) {
                            Z.each(t, function (t, i) {
                                var r = Z.type(i);
                                "function" !== r || e.unique && p.has(i) ? i && i.length && "string" !== r && n(i) : u.push(i)
                            })
                        }(arguments), s ? a = u.length : i && (o = t, d(i))
                    }
                    return this
                },
                remove: function () {
                    return u && Z.each(arguments, function (e, t) {
                        for (var n;
                            (n = Z.inArray(t, u, n)) > -1;) u.splice(n, 1), s && (a >= n && a-- , l >= n && l--)
                    }), this
                },
                has: function (e) {
                    return Z.inArray(e, u) > -1
                },
                empty: function () {
                    return u = [], this
                },
                disable: function () {
                    return u = c = i = t, this
                },
                disabled: function () {
                    return !u
                },
                lock: function () {
                    return c = t, i || p.disable(), this
                },
                locked: function () {
                    return !c
                },
                fireWith: function (e, t) {
                    return t = t || [], t = [e, t.slice ? t.slice() : t], u && (!r || c) && (s ? c.push(t) : d(t)), this
                },
                fire: function () {
                    return p.fireWith(this, arguments), this
                },
                fired: function () {
                    return !!r
                }
            };
        return p
    }, Z.extend({
        Deferred: function (e) {
            var t = [
                ["resolve", "done", Z.Callbacks("once memory"), "resolved"],
                ["reject", "fail", Z.Callbacks("once memory"), "rejected"],
                ["notify", "progress", Z.Callbacks("memory")]
            ],
                n = "pending",
                i = {
                    state: function () {
                        return n
                    },
                    always: function () {
                        return r.done(arguments).fail(arguments), this
                    },
                    then: function () {
                        var e = arguments;
                        return Z.Deferred(function (n) {
                            Z.each(t, function (t, i) {
                                var s = i[0],
                                    o = e[t];
                                r[i[1]](Z.isFunction(o) ? function () {
                                    var e = o.apply(this, arguments);
                                    e && Z.isFunction(e.promise) ? e.promise().done(n.resolve).fail(n.reject).progress(n.notify) : n[s + "With"](this === r ? n : this, [e])
                                } : n[s])
                            }), e = null
                        }).promise()
                    },
                    promise: function (e) {
                        return null != e ? Z.extend(e, i) : i
                    }
                },
                r = {};
            return i.pipe = i.then, Z.each(t, function (e, s) {
                var o = s[2],
                    a = s[3];
                i[s[1]] = o.add, a && o.add(function () {
                    n = a
                }, t[1 ^ e][2].disable, t[2][2].lock), r[s[0]] = o.fire, r[s[0] + "With"] = o.fireWith
            }), i.promise(r), e && e.call(r, r), r
        },
        when: function (e) {
            var t, n, i, r = 0,
                s = z.call(arguments),
                o = s.length,
                a = 1 !== o || e && Z.isFunction(e.promise) ? o : 0,
                l = 1 === a ? e : Z.Deferred(),
                u = function (e, n, i) {
                    return function (r) {
                        n[e] = this, i[e] = arguments.length > 1 ? z.call(arguments) : r, i === t ? l.notifyWith(n, i) : --a || l.resolveWith(n, i)
                    }
                };
            if (o > 1)
                for (t = new Array(o), n = new Array(o), i = new Array(o); o > r; r++) s[r] && Z.isFunction(s[r].promise) ? s[r].promise().done(u(r, i, s)).fail(l.reject).progress(u(r, n, t)) : --a;
            return a || l.resolveWith(i, s), l.promise()
        }
    }), Z.support = function () {
        var t, n, i, r, s, o, a, l, u, c, d, p = W.createElement("div");
        if (p.setAttribute("className", "t"), p.innerHTML = "  <link/><table></table><a href='/a'>a</a><input type='checkbox'/>", n = p.getElementsByTagName("*"), i = p.getElementsByTagName("a")[0], i.style.cssText = "top:1px;float:left;opacity:.5", !n || !n.length) return {};
        r = W.createElement("select"), s = r.appendChild(W.createElement("option")), o = p.getElementsByTagName("input")[0], t = {
            leadingWhitespace: 3 === p.firstChild.nodeType,
            tbody: !p.getElementsByTagName("tbody").length,
            htmlSerialize: !!p.getElementsByTagName("link").length,
            style: /top/.test(i.getAttribute("style")),
            hrefNormalized: "/a" === i.getAttribute("href"),
            opacity: /^0.5/.test(i.style.opacity),
            cssFloat: !!i.style.cssFloat,
            checkOn: "on" === o.value,
            optSelected: s.selected,
            getSetAttribute: "t" !== p.className,
            enctype: !!W.createElement("form").enctype,
            html5Clone: "<:nav></:nav>" !== W.createElement("nav").cloneNode(!0).outerHTML,
            boxModel: "CSS1Compat" === W.compatMode,
            submitBubbles: !0,
            changeBubbles: !0,
            focusinBubbles: !1,
            deleteExpando: !0,
            noCloneEvent: !0,
            inlineBlockNeedsLayout: !1,
            shrinkWrapBlocks: !1,
            reliableMarginRight: !0,
            boxSizingReliable: !0,
            pixelPosition: !1
        }, o.checked = !0, t.noCloneChecked = o.cloneNode(!0).checked, r.disabled = !0, t.optDisabled = !s.disabled;
        try {
            delete p.test
        } catch (f) {
            t.deleteExpando = !1
        }
        if (!p.addEventListener && p.attachEvent && p.fireEvent && (p.attachEvent("onclick", d = function () {
            t.noCloneEvent = !1
        }), p.cloneNode(!0).fireEvent("onclick"), p.detachEvent("onclick", d)), o = W.createElement("input"), o.value = "t", o.setAttribute("type", "radio"), t.radioValue = "t" === o.value, o.setAttribute("checked", "checked"), o.setAttribute("name", "t"), p.appendChild(o), a = W.createDocumentFragment(), a.appendChild(p.lastChild), t.checkClone = a.cloneNode(!0).cloneNode(!0).lastChild.checked, t.appendChecked = o.checked, a.removeChild(o), a.appendChild(p), p.attachEvent)
            for (u in {
                submit: !0,
                change: !0,
                focusin: !0
            }) l = "on" + u, c = l in p, c || (p.setAttribute(l, "return;"), c = "function" == typeof p[l]), t[u + "Bubbles"] = c;
        return Z(function () {
            var n, i, r, s, o = "padding:0;margin:0;border:0;display:block;overflow:hidden;",
                a = W.getElementsByTagName("body")[0];
            a && (n = W.createElement("div"), n.style.cssText = "visibility:hidden;border:0;width:0;height:0;position:static;top:0;margin-top:1px", a.insertBefore(n, a.firstChild), i = W.createElement("div"), n.appendChild(i), i.innerHTML = "<table><tr><td></td><td>t</td></tr></table>", r = i.getElementsByTagName("td"), r[0].style.cssText = "padding:0;margin:0;border:0;display:none", c = 0 === r[0].offsetHeight, r[0].style.display = "", r[1].style.display = "none", t.reliableHiddenOffsets = c && 0 === r[0].offsetHeight, i.innerHTML = "", i.style.cssText = "box-sizing:border-box;-moz-box-sizing:border-box;-webkit-box-sizing:border-box;padding:1px;border:1px;display:block;width:4px;margin-top:1%;position:absolute;top:1%;", t.boxSizing = 4 === i.offsetWidth, t.doesNotIncludeMarginInBodyOffset = 1 !== a.offsetTop, e.getComputedStyle && (t.pixelPosition = "1%" !== (e.getComputedStyle(i, null) || {}).top, t.boxSizingReliable = "4px" === (e.getComputedStyle(i, null) || {
                width: "4px"
            }).width, s = W.createElement("div"), s.style.cssText = i.style.cssText = o, s.style.marginRight = s.style.width = "0", i.style.width = "1px", i.appendChild(s), t.reliableMarginRight = !parseFloat((e.getComputedStyle(s, null) || {}).marginRight)), "undefined" != typeof i.style.zoom && (i.innerHTML = "", i.style.cssText = o + "width:1px;padding:1px;display:inline;zoom:1", t.inlineBlockNeedsLayout = 3 === i.offsetWidth, i.style.display = "block", i.style.overflow = "visible", i.innerHTML = "<div></div>", i.firstChild.style.width = "5px", t.shrinkWrapBlocks = 3 !== i.offsetWidth, n.style.zoom = 1), a.removeChild(n), n = i = r = s = null)
        }), a.removeChild(p), n = i = r = s = o = a = p = null, t
    }();
    var ge = /(?:\{[\s\S]*\}|\[[\s\S]*\])$/,
        me = /([A-Z])/g;
    Z.extend({
        cache: {},
        deletedIds: [],
        uuid: 0,
        expando: "jQuery" + (Z.fn.jquery + Math.random()).replace(/\D/g, ""),
        noData: {
            embed: !0,
            object: "clsid:D27CDB6E-AE6D-11cf-96B8-444553540000",
            applet: !0
        },
        hasData: function (e) {
            return e = e.nodeType ? Z.cache[e[Z.expando]] : e[Z.expando], !!e && !r(e)
        },
        data: function (e, n, i, r) {
            if (Z.acceptData(e)) {
                var s, o, a = Z.expando,
                    l = "string" == typeof n,
                    u = e.nodeType,
                    c = u ? Z.cache : e,
                    d = u ? e[a] : e[a] && a;
                if (d && c[d] && (r || c[d].data) || !l || i !== t) return d || (u ? e[a] = d = Z.deletedIds.pop() || Z.guid++ : d = a), c[d] || (c[d] = {}, u || (c[d].toJSON = Z.noop)), "object" != typeof n && "function" != typeof n || (r ? c[d] = Z.extend(c[d], n) : c[d].data = Z.extend(c[d].data, n)), s = c[d], r || (s.data || (s.data = {}), s = s.data), i !== t && (s[Z.camelCase(n)] = i), l ? (o = s[n], null == o && (o = s[Z.camelCase(n)])) : o = s, o
            }
        },
        removeData: function (e, t, n) {
            if (Z.acceptData(e)) {
                var i, s, o, a = e.nodeType,
                    l = a ? Z.cache : e,
                    u = a ? e[Z.expando] : Z.expando;
                if (l[u]) {
                    if (t && (i = n ? l[u] : l[u].data)) {
                        Z.isArray(t) || (t in i ? t = [t] : (t = Z.camelCase(t), t = t in i ? [t] : t.split(" ")));
                        for (s = 0, o = t.length; o > s; s++) delete i[t[s]];
                        if (!(n ? r : Z.isEmptyObject)(i)) return
                    } (n || (delete l[u].data, r(l[u]))) && (a ? Z.cleanData([e], !0) : Z.support.deleteExpando || l != l.window ? delete l[u] : l[u] = null)
                }
            }
        },
        _data: function (e, t, n) {
            return Z.data(e, t, n, !0)
        },
        acceptData: function (e) {
            var t = e.nodeName && Z.noData[e.nodeName.toLowerCase()];
            return !t || t !== !0 && e.getAttribute("classid") === t
        }
    }), Z.fn.extend({
        data: function (e, n) {
            var r, s, o, a, l, u = this[0],
                c = 0,
                d = null;
            if (e === t) {
                if (this.length && (d = Z.data(u), 1 === u.nodeType && !Z._data(u, "parsedAttrs"))) {
                    for (o = u.attributes, l = o.length; l > c; c++) a = o[c].name, a.indexOf("data-") || (a = Z.camelCase(a.substring(5)), i(u, a, d[a]));
                    Z._data(u, "parsedAttrs", !0)
                }
                return d
            }
            return "object" == typeof e ? this.each(function () {
                Z.data(this, e)
            }) : (r = e.split(".", 2), r[1] = r[1] ? "." + r[1] : "", s = r[1] + "!", Z.access(this, function (n) {
                return n === t ? (d = this.triggerHandler("getData" + s, [r[0]]), d === t && u && (d = Z.data(u, e), d = i(u, e, d)), d === t && r[1] ? this.data(r[0]) : d) : (r[1] = n, void this.each(function () {
                    var t = Z(this);
                    t.triggerHandler("setData" + s, r), Z.data(this, e, n), t.triggerHandler("changeData" + s, r)
                }))
            }, null, n, arguments.length > 1, null, !1))
        },
        removeData: function (e) {
            return this.each(function () {
                Z.removeData(this, e)
            })
        }
    }), Z.extend({
        queue: function (e, t, n) {
            var i;
            return e ? (t = (t || "fx") + "queue", i = Z._data(e, t), n && (!i || Z.isArray(n) ? i = Z._data(e, t, Z.makeArray(n)) : i.push(n)), i || []) : void 0
        },
        dequeue: function (e, t) {
            t = t || "fx";
            var n = Z.queue(e, t),
                i = n.length,
                r = n.shift(),
                s = Z._queueHooks(e, t),
                o = function () {
                    Z.dequeue(e, t)
                };
            "inprogress" === r && (r = n.shift(), i--), r && ("fx" === t && n.unshift("inprogress"), delete s.stop, r.call(e, o, s)), !i && s && s.empty.fire()
        },
        _queueHooks: function (e, t) {
            var n = t + "queueHooks";
            return Z._data(e, n) || Z._data(e, n, {
                empty: Z.Callbacks("once memory").add(function () {
                    Z.removeData(e, t + "queue", !0), Z.removeData(e, n, !0)
                })
            })
        }
    }), Z.fn.extend({
        queue: function (e, n) {
            var i = 2;
            return "string" != typeof e && (n = e, e = "fx", i--), arguments.length < i ? Z.queue(this[0], e) : n === t ? this : this.each(function () {
                var t = Z.queue(this, e, n);
                Z._queueHooks(this, e), "fx" === e && "inprogress" !== t[0] && Z.dequeue(this, e)
            })
        },
        dequeue: function (e) {
            return this.each(function () {
                Z.dequeue(this, e)
            })
        },
        delay: function (e, t) {
            return e = Z.fx ? Z.fx.speeds[e] || e : e, t = t || "fx", this.queue(t, function (t, n) {
                var i = setTimeout(t, e);
                n.stop = function () {
                    clearTimeout(i)
                }
            })
        },
        clearQueue: function (e) {
            return this.queue(e || "fx", [])
        },
        promise: function (e, n) {
            var i, r = 1,
                s = Z.Deferred(),
                o = this,
                a = this.length,
                l = function () {
                    --r || s.resolveWith(o, [o])
                };
            for ("string" != typeof e && (n = e, e = t), e = e || "fx"; a--;) i = Z._data(o[a], e + "queueHooks"), i && i.empty && (r++ , i.empty.add(l));
            return l(), s.promise(n)
        }
    });
    var ye, ve, Ae, we = /[\t\r\n]/g,
        Ee = /\r/g,
        be = /^(?:button|input)$/i,
        xe = /^(?:button|input|object|select|textarea)$/i,
        _e = /^a(?:rea|)$/i,
        ke = /^(?:autofocus|autoplay|async|checked|controls|defer|disabled|hidden|loop|multiple|open|readonly|required|scoped|selected)$/i,
        Le = Z.support.getSetAttribute;
    Z.fn.extend({
        attr: function (e, t) {
            return Z.access(this, Z.attr, e, t, arguments.length > 1)
        },
        removeAttr: function (e) {
            return this.each(function () {
                Z.removeAttr(this, e)
            })
        },
        prop: function (e, t) {
            return Z.access(this, Z.prop, e, t, arguments.length > 1)
        },
        removeProp: function (e) {
            return e = Z.propFix[e] || e, this.each(function () {
                try {
                    this[e] = t, delete this[e]
                } catch (n) { }
            })
        },
        addClass: function (e) {
            var t, n, i, r, s, o, a;
            if (Z.isFunction(e)) return this.each(function (t) {
                Z(this).addClass(e.call(this, t, this.className))
            });
            if (e && "string" == typeof e)
                for (t = e.split(te), n = 0, i = this.length; i > n; n++)
                    if (r = this[n], 1 === r.nodeType)
                        if (r.className || 1 !== t.length) {
                            for (s = " " + r.className + " ", o = 0, a = t.length; a > o; o++) s.indexOf(" " + t[o] + " ") < 0 && (s += t[o] + " ");
                            r.className = Z.trim(s)
                        } else r.className = e;
            return this
        },
        removeClass: function (e) {
            var n, i, r, s, o, a, l;
            if (Z.isFunction(e)) return this.each(function (t) {
                Z(this).removeClass(e.call(this, t, this.className))
            });
            if (e && "string" == typeof e || e === t)
                for (n = (e || "").split(te), a = 0, l = this.length; l > a; a++)
                    if (r = this[a], 1 === r.nodeType && r.className) {
                        for (i = (" " + r.className + " ").replace(we, " "), s = 0, o = n.length; o > s; s++)
                            for (; i.indexOf(" " + n[s] + " ") >= 0;) i = i.replace(" " + n[s] + " ", " ");
                        r.className = e ? Z.trim(i) : ""
                    }
            return this
        },
        toggleClass: function (e, t) {
            var n = typeof e,
                i = "boolean" == typeof t;
            return Z.isFunction(e) ? this.each(function (n) {
                Z(this).toggleClass(e.call(this, n, this.className, t), t)
            }) : this.each(function () {
                if ("string" === n)
                    for (var r, s = 0, o = Z(this), a = t, l = e.split(te); r = l[s++];) a = i ? a : !o.hasClass(r), o[a ? "addClass" : "removeClass"](r);
                else "undefined" !== n && "boolean" !== n || (this.className && Z._data(this, "__className__", this.className), this.className = this.className || e === !1 ? "" : Z._data(this, "__className__") || "")
            })
        },
        hasClass: function (e) {
            for (var t = " " + e + " ", n = 0, i = this.length; i > n; n++)
                if (1 === this[n].nodeType && (" " + this[n].className + " ").replace(we, " ").indexOf(t) >= 0) return !0;
            return !1
        },
        val: function (e) {
            var n, i, r, s = this[0]; {
                if (arguments.length) return r = Z.isFunction(e), this.each(function (i) {
                    var s, o = Z(this);
                    1 === this.nodeType && (s = r ? e.call(this, i, o.val()) : e, null == s ? s = "" : "number" == typeof s ? s += "" : Z.isArray(s) && (s = Z.map(s, function (e) {
                        return null == e ? "" : e + ""
                    })), n = Z.valHooks[this.type] || Z.valHooks[this.nodeName.toLowerCase()], n && "set" in n && n.set(this, s, "value") !== t || (this.value = s))
                });
                if (s) return n = Z.valHooks[s.type] || Z.valHooks[s.nodeName.toLowerCase()], n && "get" in n && (i = n.get(s, "value")) !== t ? i : (i = s.value, "string" == typeof i ? i.replace(Ee, "") : null == i ? "" : i)
            }
        }
    }), Z.extend({
        valHooks: {
            option: {
                get: function (e) {
                    var t = e.attributes.value;
                    return !t || t.specified ? e.value : e.text
                }
            },
            select: {
                get: function (e) {
                    var t, n, i, r, s = e.selectedIndex,
                        o = [],
                        a = e.options,
                        l = "select-one" === e.type;
                    if (0 > s) return null;
                    for (n = l ? s : 0, i = l ? s + 1 : a.length; i > n; n++)
                        if (r = a[n], r.selected && (Z.support.optDisabled ? !r.disabled : null === r.getAttribute("disabled")) && (!r.parentNode.disabled || !Z.nodeName(r.parentNode, "optgroup"))) {
                            if (t = Z(r).val(), l) return t;
                            o.push(t)
                        }
                    return l && !o.length && a.length ? Z(a[s]).val() : o
                },
                set: function (e, t) {
                    var n = Z.makeArray(t);
                    return Z(e).find("option").each(function () {
                        this.selected = Z.inArray(Z(this).val(), n) >= 0
                    }), n.length || (e.selectedIndex = -1), n
                }
            }
        },
        attrFn: {},
        attr: function (e, n, i, r) {
            var s, o, a, l = e.nodeType;
            if (e && 3 !== l && 8 !== l && 2 !== l) return r && Z.isFunction(Z.fn[n]) ? Z(e)[n](i) : "undefined" == typeof e.getAttribute ? Z.prop(e, n, i) : (a = 1 !== l || !Z.isXMLDoc(e), a && (n = n.toLowerCase(), o = Z.attrHooks[n] || (ke.test(n) ? ve : ye)), i !== t ? null === i ? void Z.removeAttr(e, n) : o && "set" in o && a && (s = o.set(e, i, n)) !== t ? s : (e.setAttribute(n, i + ""), i) : o && "get" in o && a && null !== (s = o.get(e, n)) ? s : (s = e.getAttribute(n), null === s ? t : s))
        },
        removeAttr: function (e, t) {
            var n, i, r, s, o = 0;
            if (t && 1 === e.nodeType)
                for (i = t.split(te); o < i.length; o++) r = i[o], r && (n = Z.propFix[r] || r, s = ke.test(r), s || Z.attr(e, r, ""), e.removeAttribute(Le ? r : n), s && n in e && (e[n] = !1))
        },
        attrHooks: {
            type: {
                set: function (e, t) {
                    if (be.test(e.nodeName) && e.parentNode) Z.error("type property can't be changed");
                    else if (!Z.support.radioValue && "radio" === t && Z.nodeName(e, "input")) {
                        var n = e.value;
                        return e.setAttribute("type", t), n && (e.value = n), t
                    }
                }
            },
            value: {
                get: function (e, t) {
                    return ye && Z.nodeName(e, "button") ? ye.get(e, t) : t in e ? e.value : null
                },
                set: function (e, t, n) {
                    return ye && Z.nodeName(e, "button") ? ye.set(e, t, n) : void (e.value = t)
                }
            }
        },
        propFix: {
            tabindex: "tabIndex",
            readonly: "readOnly",
            "for": "htmlFor",
            "class": "className",
            maxlength: "maxLength",
            cellspacing: "cellSpacing",
            cellpadding: "cellPadding",
            rowspan: "rowSpan",
            colspan: "colSpan",
            usemap: "useMap",
            frameborder: "frameBorder",
            contenteditable: "contentEditable"
        },
        prop: function (e, n, i) {
            var r, s, o, a = e.nodeType;
            if (e && 3 !== a && 8 !== a && 2 !== a) return o = 1 !== a || !Z.isXMLDoc(e),
                o && (n = Z.propFix[n] || n, s = Z.propHooks[n]), i !== t ? s && "set" in s && (r = s.set(e, i, n)) !== t ? r : e[n] = i : s && "get" in s && null !== (r = s.get(e, n)) ? r : e[n]
        },
        propHooks: {
            tabIndex: {
                get: function (e) {
                    var n = e.getAttributeNode("tabindex");
                    return n && n.specified ? parseInt(n.value, 10) : xe.test(e.nodeName) || _e.test(e.nodeName) && e.href ? 0 : t
                }
            }
        }
    }), ve = {
        get: function (e, n) {
            var i, r = Z.prop(e, n);
            return r === !0 || "boolean" != typeof r && (i = e.getAttributeNode(n)) && i.nodeValue !== !1 ? n.toLowerCase() : t
        },
        set: function (e, t, n) {
            var i;
            return t === !1 ? Z.removeAttr(e, n) : (i = Z.propFix[n] || n, i in e && (e[i] = !0), e.setAttribute(n, n.toLowerCase())), n
        }
    }, Le || (Ae = {
        name: !0,
        id: !0,
        coords: !0
    }, ye = Z.valHooks.button = {
        get: function (e, n) {
            var i;
            return i = e.getAttributeNode(n), i && (Ae[n] ? "" !== i.value : i.specified) ? i.value : t
        },
        set: function (e, t, n) {
            var i = e.getAttributeNode(n);
            return i || (i = W.createAttribute(n), e.setAttributeNode(i)), i.value = t + ""
        }
    }, Z.each(["width", "height"], function (e, t) {
        Z.attrHooks[t] = Z.extend(Z.attrHooks[t], {
            set: function (e, n) {
                return "" === n ? (e.setAttribute(t, "auto"), n) : void 0
            }
        })
    }), Z.attrHooks.contenteditable = {
        get: ye.get,
        set: function (e, t, n) {
            "" === t && (t = "false"), ye.set(e, t, n)
        }
    }), Z.support.hrefNormalized || Z.each(["href", "src", "width", "height"], function (e, n) {
        Z.attrHooks[n] = Z.extend(Z.attrHooks[n], {
            get: function (e) {
                var i = e.getAttribute(n, 2);
                return null === i ? t : i
            }
        })
    }), Z.support.style || (Z.attrHooks.style = {
        get: function (e) {
            return e.style.cssText.toLowerCase() || t
        },
        set: function (e, t) {
            return e.style.cssText = t + ""
        }
    }), Z.support.optSelected || (Z.propHooks.selected = Z.extend(Z.propHooks.selected, {
        get: function (e) {
            var t = e.parentNode;
            return t && (t.selectedIndex, t.parentNode && t.parentNode.selectedIndex), null
        }
    })), Z.support.enctype || (Z.propFix.enctype = "encoding"), Z.support.checkOn || Z.each(["radio", "checkbox"], function () {
        Z.valHooks[this] = {
            get: function (e) {
                return null === e.getAttribute("value") ? "on" : e.value
            }
        }
    }), Z.each(["radio", "checkbox"], function () {
        Z.valHooks[this] = Z.extend(Z.valHooks[this], {
            set: function (e, t) {
                return Z.isArray(t) ? e.checked = Z.inArray(Z(e).val(), t) >= 0 : void 0
            }
        })
    });
    var Ie = /^(?:textarea|input|select)$/i,
        Se = /^([^\.]*|)(?:\.(.+)|)$/,
        je = /(?:^|\s)hover(\.\S+|)\b/,
        Ne = /^key/,
        Re = /^(?:mouse|contextmenu)|click/,
        Te = /^(?:focusinfocus|focusoutblur)$/,
        Pe = function (e) {
            return Z.event.special.hover ? e : e.replace(je, "mouseenter$1 mouseleave$1")
        };
    Z.event = {
        add: function (e, n, i, r, s) {
            var o, a, l, u, c, d, p, f, h, g, m;
            if (3 !== e.nodeType && 8 !== e.nodeType && n && i && (o = Z._data(e))) {
                for (i.handler && (h = i, i = h.handler, s = h.selector), i.guid || (i.guid = Z.guid++), l = o.events, l || (o.events = l = {}), a = o.handle, a || (o.handle = a = function (e) {
                    return "undefined" == typeof Z || e && Z.event.triggered === e.type ? t : Z.event.dispatch.apply(a.elem, arguments)
                }, a.elem = e), n = Z.trim(Pe(n)).split(" "), u = 0; u < n.length; u++) c = Se.exec(n[u]) || [], d = c[1], p = (c[2] || "").split(".").sort(), m = Z.event.special[d] || {}, d = (s ? m.delegateType : m.bindType) || d, m = Z.event.special[d] || {}, f = Z.extend({
                    type: d,
                    origType: c[1],
                    data: r,
                    handler: i,
                    guid: i.guid,
                    selector: s,
                    needsContext: s && Z.expr.match.needsContext.test(s),
                    namespace: p.join(".")
                }, h), g = l[d], g || (g = l[d] = [], g.delegateCount = 0, m.setup && m.setup.call(e, r, p, a) !== !1 || (e.addEventListener ? e.addEventListener(d, a, !1) : e.attachEvent && e.attachEvent("on" + d, a))), m.add && (m.add.call(e, f), f.handler.guid || (f.handler.guid = i.guid)), s ? g.splice(g.delegateCount++, 0, f) : g.push(f), Z.event.global[d] = !0;
                e = null
            }
        },
        global: {},
        remove: function (e, t, n, i, r) {
            var s, o, a, l, u, c, d, p, f, h, g, m = Z.hasData(e) && Z._data(e);
            if (m && (p = m.events)) {
                for (t = Z.trim(Pe(t || "")).split(" "), s = 0; s < t.length; s++)
                    if (o = Se.exec(t[s]) || [], a = l = o[1], u = o[2], a) {
                        for (f = Z.event.special[a] || {}, a = (i ? f.delegateType : f.bindType) || a, h = p[a] || [], c = h.length, u = u ? new RegExp("(^|\\.)" + u.split(".").sort().join("\\.(?:.*\\.|)") + "(\\.|$)") : null, d = 0; d < h.length; d++) g = h[d], (r || l === g.origType) && (!n || n.guid === g.guid) && (!u || u.test(g.namespace)) && (!i || i === g.selector || "**" === i && g.selector) && (h.splice(d--, 1), g.selector && h.delegateCount-- , f.remove && f.remove.call(e, g));
                        0 === h.length && c !== h.length && ((!f.teardown || f.teardown.call(e, u, m.handle) === !1) && Z.removeEvent(e, a, m.handle), delete p[a])
                    } else
                        for (a in p) Z.event.remove(e, a + t[s], n, i, !0);
                Z.isEmptyObject(p) && (delete m.handle, Z.removeData(e, "events", !0))
            }
        },
        customEvent: {
            getData: !0,
            setData: !0,
            changeData: !0
        },
        trigger: function (n, i, r, s) {
            if (!r || 3 !== r.nodeType && 8 !== r.nodeType) {
                var o, a, l, u, c, d, p, f, h, g, m = n.type || n,
                    y = [];
                if (Te.test(m + Z.event.triggered)) return;
                if (m.indexOf("!") >= 0 && (m = m.slice(0, -1), a = !0), m.indexOf(".") >= 0 && (y = m.split("."), m = y.shift(), y.sort()), (!r || Z.event.customEvent[m]) && !Z.event.global[m]) return;
                if (n = "object" == typeof n ? n[Z.expando] ? n : new Z.Event(m, n) : new Z.Event(m), n.type = m, n.isTrigger = !0, n.exclusive = a, n.namespace = y.join("."), n.namespace_re = n.namespace ? new RegExp("(^|\\.)" + y.join("\\.(?:.*\\.|)") + "(\\.|$)") : null, d = m.indexOf(":") < 0 ? "on" + m : "", !r) {
                    o = Z.cache;
                    for (l in o) o[l].events && o[l].events[m] && Z.event.trigger(n, i, o[l].handle.elem, !0);
                    return
                }
                if (n.result = t, n.target || (n.target = r), i = null != i ? Z.makeArray(i) : [], i.unshift(n), p = Z.event.special[m] || {}, p.trigger && p.trigger.apply(r, i) === !1) return;
                if (h = [
                    [r, p.bindType || m]
                ], !s && !p.noBubble && !Z.isWindow(r)) {
                    for (g = p.delegateType || m, u = Te.test(g + m) ? r : r.parentNode, c = r; u; u = u.parentNode) h.push([u, g]), c = u;
                    c === (r.ownerDocument || W) && h.push([c.defaultView || c.parentWindow || e, g])
                }
                for (l = 0; l < h.length && !n.isPropagationStopped(); l++) u = h[l][0], n.type = h[l][1], f = (Z._data(u, "events") || {})[n.type] && Z._data(u, "handle"), f && f.apply(u, i), f = d && u[d], f && Z.acceptData(u) && f.apply && f.apply(u, i) === !1 && n.preventDefault();
                return n.type = m, !s && !n.isDefaultPrevented() && (!p._default || p._default.apply(r.ownerDocument, i) === !1) && ("click" !== m || !Z.nodeName(r, "a")) && Z.acceptData(r) && d && r[m] && ("focus" !== m && "blur" !== m || 0 !== n.target.offsetWidth) && !Z.isWindow(r) && (c = r[d], c && (r[d] = null), Z.event.triggered = m, r[m](), Z.event.triggered = t, c && (r[d] = c)), n.result
            }
        },
        dispatch: function (n) {
            n = Z.event.fix(n || e.event);
            var i, r, s, o, a, l, u, c, d, p = (Z._data(this, "events") || {})[n.type] || [],
                f = p.delegateCount,
                h = z.call(arguments),
                g = !n.exclusive && !n.namespace,
                m = Z.event.special[n.type] || {},
                y = [];
            if (h[0] = n, n.delegateTarget = this, !m.preDispatch || m.preDispatch.call(this, n) !== !1) {
                if (f && (!n.button || "click" !== n.type))
                    for (s = n.target; s != this; s = s.parentNode || this)
                        if (s.disabled !== !0 || "click" !== n.type) {
                            for (a = {}, u = [], i = 0; f > i; i++) c = p[i], d = c.selector, a[d] === t && (a[d] = c.needsContext ? Z(d, this).index(s) >= 0 : Z.find(d, this, null, [s]).length), a[d] && u.push(c);
                            u.length && y.push({
                                elem: s,
                                matches: u
                            })
                        }
                for (p.length > f && y.push({
                    elem: this,
                    matches: p.slice(f)
                }), i = 0; i < y.length && !n.isPropagationStopped(); i++)
                    for (l = y[i], n.currentTarget = l.elem, r = 0; r < l.matches.length && !n.isImmediatePropagationStopped(); r++) c = l.matches[r], (g || !n.namespace && !c.namespace || n.namespace_re && n.namespace_re.test(c.namespace)) && (n.data = c.data, n.handleObj = c, o = ((Z.event.special[c.origType] || {}).handle || c.handler).apply(l.elem, h), o !== t && (n.result = o, o === !1 && (n.preventDefault(), n.stopPropagation())));
                return m.postDispatch && m.postDispatch.call(this, n), n.result
            }
        },
        props: "attrChange attrName relatedNode srcElement altKey bubbles cancelable ctrlKey currentTarget eventPhase metaKey relatedTarget shiftKey target timeStamp view which".split(" "),
        fixHooks: {},
        keyHooks: {
            props: "char charCode key keyCode".split(" "),
            filter: function (e, t) {
                return null == e.which && (e.which = null != t.charCode ? t.charCode : t.keyCode), e
            }
        },
        mouseHooks: {
            props: "button buttons clientX clientY fromElement offsetX offsetY pageX pageY screenX screenY toElement".split(" "),
            filter: function (e, n) {
                var i, r, s, o = n.button,
                    a = n.fromElement;
                return null == e.pageX && null != n.clientX && (i = e.target.ownerDocument || W, r = i.documentElement, s = i.body, e.pageX = n.clientX + (r && r.scrollLeft || s && s.scrollLeft || 0) - (r && r.clientLeft || s && s.clientLeft || 0), e.pageY = n.clientY + (r && r.scrollTop || s && s.scrollTop || 0) - (r && r.clientTop || s && s.clientTop || 0)), !e.relatedTarget && a && (e.relatedTarget = a === e.target ? n.toElement : a), !e.which && o !== t && (e.which = 1 & o ? 1 : 2 & o ? 3 : 4 & o ? 2 : 0), e
            }
        },
        fix: function (e) {
            if (e[Z.expando]) return e;
            var t, n, i = e,
                r = Z.event.fixHooks[e.type] || {},
                s = r.props ? this.props.concat(r.props) : this.props;
            for (e = Z.Event(i), t = s.length; t;) n = s[--t], e[n] = i[n];
            return e.target || (e.target = i.srcElement || W), 3 === e.target.nodeType && (e.target = e.target.parentNode), e.metaKey = !!e.metaKey, r.filter ? r.filter(e, i) : e
        },
        special: {
            load: {
                noBubble: !0
            },
            focus: {
                delegateType: "focusin"
            },
            blur: {
                delegateType: "focusout"
            },
            beforeunload: {
                setup: function (e, t, n) {
                    Z.isWindow(this) && (this.onbeforeunload = n)
                },
                teardown: function (e, t) {
                    this.onbeforeunload === t && (this.onbeforeunload = null)
                }
            }
        },
        simulate: function (e, t, n, i) {
            var r = Z.extend(new Z.Event, n, {
                type: e,
                isSimulated: !0,
                originalEvent: {}
            });
            i ? Z.event.trigger(r, null, t) : Z.event.dispatch.call(t, r), r.isDefaultPrevented() && n.preventDefault()
        }
    }, Z.event.handle = Z.event.dispatch, Z.removeEvent = W.removeEventListener ? function (e, t, n) {
        e.removeEventListener && e.removeEventListener(t, n, !1)
    } : function (e, t, n) {
        var i = "on" + t;
        e.detachEvent && ("undefined" == typeof e[i] && (e[i] = null), e.detachEvent(i, n))
    }, Z.Event = function (e, t) {
        return this instanceof Z.Event ? (e && e.type ? (this.originalEvent = e, this.type = e.type, this.isDefaultPrevented = e.defaultPrevented || e.returnValue === !1 || e.getPreventDefault && e.getPreventDefault() ? o : s) : this.type = e, t && Z.extend(this, t), this.timeStamp = e && e.timeStamp || Z.now(), this[Z.expando] = !0, void 0) : new Z.Event(e, t)
    }, Z.Event.prototype = {
        preventDefault: function () {
            this.isDefaultPrevented = o;
            var e = this.originalEvent;
            e && (e.preventDefault ? e.preventDefault() : e.returnValue = !1)
        },
        stopPropagation: function () {
            this.isPropagationStopped = o;
            var e = this.originalEvent;
            e && (e.stopPropagation && e.stopPropagation(), e.cancelBubble = !0)
        },
        stopImmediatePropagation: function () {
            this.isImmediatePropagationStopped = o, this.stopPropagation()
        },
        isDefaultPrevented: s,
        isPropagationStopped: s,
        isImmediatePropagationStopped: s
    }, Z.each({
        mouseenter: "mouseover",
        mouseleave: "mouseout"
    }, function (e, t) {
        Z.event.special[e] = {
            delegateType: t,
            bindType: t,
            handle: function (e) {
                var n, i = this,
                    r = e.relatedTarget,
                    s = e.handleObj;
                s.selector;
                return r && (r === i || Z.contains(i, r)) || (e.type = s.origType, n = s.handler.apply(this, arguments), e.type = t), n
            }
        }
    }), Z.support.submitBubbles || (Z.event.special.submit = {
        setup: function () {
            return Z.nodeName(this, "form") ? !1 : void Z.event.add(this, "click._submit keypress._submit", function (e) {
                var n = e.target,
                    i = Z.nodeName(n, "input") || Z.nodeName(n, "button") ? n.form : t;
                i && !Z._data(i, "_submit_attached") && (Z.event.add(i, "submit._submit", function (e) {
                    e._submit_bubble = !0
                }), Z._data(i, "_submit_attached", !0))
            })
        },
        postDispatch: function (e) {
            e._submit_bubble && (delete e._submit_bubble, this.parentNode && !e.isTrigger && Z.event.simulate("submit", this.parentNode, e, !0))
        },
        teardown: function () {
            return Z.nodeName(this, "form") ? !1 : void Z.event.remove(this, "._submit")
        }
    }), Z.support.changeBubbles || (Z.event.special.change = {
        setup: function () {
            return Ie.test(this.nodeName) ? ("checkbox" !== this.type && "radio" !== this.type || (Z.event.add(this, "propertychange._change", function (e) {
                "checked" === e.originalEvent.propertyName && (this._just_changed = !0)
            }), Z.event.add(this, "click._change", function (e) {
                this._just_changed && !e.isTrigger && (this._just_changed = !1), Z.event.simulate("change", this, e, !0)
            })), !1) : void Z.event.add(this, "beforeactivate._change", function (e) {
                var t = e.target;
                Ie.test(t.nodeName) && !Z._data(t, "_change_attached") && (Z.event.add(t, "change._change", function (e) {
                    this.parentNode && !e.isSimulated && !e.isTrigger && Z.event.simulate("change", this.parentNode, e, !0)
                }), Z._data(t, "_change_attached", !0))
            })
        },
        handle: function (e) {
            var t = e.target;
            return this !== t || e.isSimulated || e.isTrigger || "radio" !== t.type && "checkbox" !== t.type ? e.handleObj.handler.apply(this, arguments) : void 0
        },
        teardown: function () {
            return Z.event.remove(this, "._change"), !Ie.test(this.nodeName)
        }
    }), Z.support.focusinBubbles || Z.each({
        focus: "focusin",
        blur: "focusout"
    }, function (e, t) {
        var n = 0,
            i = function (e) {
                Z.event.simulate(t, e.target, Z.event.fix(e), !0)
            };
        Z.event.special[t] = {
            setup: function () {
                0 === n++ && W.addEventListener(e, i, !0)
            },
            teardown: function () {
                0 === --n && W.removeEventListener(e, i, !0)
            }
        }
    }), Z.fn.extend({
        on: function (e, n, i, r, o) {
            var a, l;
            if ("object" == typeof e) {
                "string" != typeof n && (i = i || n, n = t);
                for (l in e) this.on(l, n, i, e[l], o);
                return this
            }
            if (null == i && null == r ? (r = n, i = n = t) : null == r && ("string" == typeof n ? (r = i, i = t) : (r = i, i = n, n = t)), r === !1) r = s;
            else if (!r) return this;
            return 1 === o && (a = r, r = function (e) {
                return Z().off(e), a.apply(this, arguments)
            }, r.guid = a.guid || (a.guid = Z.guid++)), this.each(function () {
                Z.event.add(this, e, r, i, n)
            })
        },
        one: function (e, t, n, i) {
            return this.on(e, t, n, i, 1)
        },
        off: function (e, n, i) {
            var r, o;
            if (e && e.preventDefault && e.handleObj) return r = e.handleObj, Z(e.delegateTarget).off(r.namespace ? r.origType + "." + r.namespace : r.origType, r.selector, r.handler), this;
            if ("object" == typeof e) {
                for (o in e) this.off(o, n, e[o]);
                return this
            }
            return n !== !1 && "function" != typeof n || (i = n, n = t), i === !1 && (i = s), this.each(function () {
                Z.event.remove(this, e, i, n)
            })
        },
        bind: function (e, t, n) {
            return this.on(e, null, t, n)
        },
        unbind: function (e, t) {
            return this.off(e, null, t)
        },
        live: function (e, t, n) {
            return Z(this.context).on(e, this.selector, t, n), this
        },
        die: function (e, t) {
            return Z(this.context).off(e, this.selector || "**", t), this
        },
        delegate: function (e, t, n, i) {
            return this.on(t, e, n, i)
        },
        undelegate: function (e, t, n) {
            return 1 === arguments.length ? this.off(e, "**") : this.off(t, e || "**", n)
        },
        trigger: function (e, t) {
            return this.each(function () {
                Z.event.trigger(e, t, this)
            })
        },
        triggerHandler: function (e, t) {
            return this[0] ? Z.event.trigger(e, t, this[0], !0) : void 0
        },
        toggle: function (e) {
            var t = arguments,
                n = e.guid || Z.guid++,
                i = 0,
                r = function (n) {
                    var r = (Z._data(this, "lastToggle" + e.guid) || 0) % i;
                    return Z._data(this, "lastToggle" + e.guid, r + 1), n.preventDefault(), t[r].apply(this, arguments) || !1
                };
            for (r.guid = n; i < t.length;) t[i++].guid = n;
            return this.click(r)
        },
        hover: function (e, t) {
            return this.mouseenter(e).mouseleave(t || e)
        }
    }), Z.each("blur focus focusin focusout load resize scroll unload click dblclick mousedown mouseup mousemove mouseover mouseout mouseenter mouseleave change select submit keydown keypress keyup error contextmenu".split(" "), function (e, t) {
        Z.fn[t] = function (e, n) {
            return null == n && (n = e, e = null), arguments.length > 0 ? this.on(t, null, e, n) : this.trigger(t)
        }, Ne.test(t) && (Z.event.fixHooks[t] = Z.event.keyHooks), Re.test(t) && (Z.event.fixHooks[t] = Z.event.mouseHooks)
    }),
        function (e, t) {
            function n(e, t, n, i) {
                n = n || [], t = t || R;
                var r, s, o, a, l = t.nodeType;
                if (!e || "string" != typeof e) return n;
                if (1 !== l && 9 !== l) return [];
                if (o = E(t), !o && !i && (r = ne.exec(e)))
                    if (a = r[1]) {
                        if (9 === l) {
                            if (s = t.getElementById(a), !s || !s.parentNode) return n;
                            if (s.id === a) return n.push(s), n
                        } else if (t.ownerDocument && (s = t.ownerDocument.getElementById(a)) && b(t, s) && s.id === a) return n.push(s), n
                    } else {
                        if (r[2]) return M.apply(n, O.call(t.getElementsByTagName(e), 0)), n;
                        if ((a = r[3]) && pe && t.getElementsByClassName) return M.apply(n, O.call(t.getElementsByClassName(a), 0)), n
                    }
                return g(e.replace(K, "$1"), t, n, i, o)
            }

            function i(e) {
                return function (t) {
                    var n = t.nodeName.toLowerCase();
                    return "input" === n && t.type === e
                }
            }

            function r(e) {
                return function (t) {
                    var n = t.nodeName.toLowerCase();
                    return ("input" === n || "button" === n) && t.type === e
                }
            }

            function s(e) {
                return F(function (t) {
                    return t = +t, F(function (n, i) {
                        for (var r, s = e([], n.length, t), o = s.length; o--;) n[r = s[o]] && (n[r] = !(i[r] = n[r]))
                    })
                })
            }

            function o(e, t, n) {
                if (e === t) return n;
                for (var i = e.nextSibling; i;) {
                    if (i === t) return -1;
                    i = i.nextSibling
                }
                return 1
            }

            function a(e, t) {
                var i, r, s, o, a, l, u, c = G[j][e];
                if (c) return t ? 0 : c.slice(0);
                for (a = e, l = [], u = A.preFilter; a;) {
                    i && !(r = $.exec(a)) || (r && (a = a.slice(r[0].length)), l.push(s = [])), i = !1, (r = ee.exec(a)) && (s.push(i = new N(r.shift())), a = a.slice(i.length), i.type = r[0].replace(K, " "));
                    for (o in A.filter) (r = ae[o].exec(a)) && (!u[o] || (r = u[o](r, R, !0))) && (s.push(i = new N(r.shift())), a = a.slice(i.length), i.type = o, i.matches = r);
                    if (!i) break
                }
                return t ? a.length : a ? n.error(e) : G(e, l).slice(0)
            }

            function l(e, t, n) {
                var i = t.dir,
                    r = n && "parentNode" === t.dir,
                    s = C++;
                return t.first ? function (t, n, s) {
                    for (; t = t[i];)
                        if (r || 1 === t.nodeType) return e(t, n, s)
                } : function (t, n, o) {
                    if (o) {
                        for (; t = t[i];)
                            if ((r || 1 === t.nodeType) && e(t, n, o)) return t
                    } else
                        for (var a, l = P + " " + s + " ", u = l + y; t = t[i];)
                            if (r || 1 === t.nodeType) {
                                if ((a = t[j]) === u) return t.sizset;
                                if ("string" == typeof a && 0 === a.indexOf(l)) {
                                    if (t.sizset) return t
                                } else {
                                    if (t[j] = u, e(t, n, o)) return t.sizset = !0, t;
                                    t.sizset = !1
                                }
                            }
                }
            }

            function u(e) {
                return e.length > 1 ? function (t, n, i) {
                    for (var r = e.length; r--;)
                        if (!e[r](t, n, i)) return !1;
                    return !0
                } : e[0]
            }

            function c(e, t, n, i, r) {
                for (var s, o = [], a = 0, l = e.length, u = null != t; l > a; a++)(s = e[a]) && (n && !n(s, i, r) || (o.push(s), u && t.push(a)));
                return o
            }

            function d(e, t, n, i, r, s) {
                return i && !i[j] && (i = d(i)), r && !r[j] && (r = d(r, s)), F(function (s, o, a, l) {
                    if (!s || !r) {
                        var u, d, p, f = [],
                            g = [],
                            m = o.length,
                            y = s || h(t || "*", a.nodeType ? [a] : a, [], s),
                            v = !e || !s && t ? y : c(y, f, e, a, l),
                            A = n ? r || (s ? e : m || i) ? [] : o : v;
                        if (n && n(v, A, a, l), i)
                            for (p = c(A, g), i(p, [], a, l), u = p.length; u--;)(d = p[u]) && (A[g[u]] = !(v[g[u]] = d));
                        if (s)
                            for (u = e && A.length; u--;)(d = A[u]) && (s[f[u]] = !(o[f[u]] = d));
                        else A = c(A === o ? A.splice(m, A.length) : A), r ? r(null, o, A, l) : M.apply(o, A)
                    }
                })
            }

            function p(e) {
                for (var t, n, i, r = e.length, s = A.relative[e[0].type], o = s || A.relative[" "], a = s ? 1 : 0, c = l(function (e) {
                    return e === t
                }, o, !0), f = l(function (e) {
                    return B.call(t, e) > -1
                }, o, !0), h = [function (e, n, i) {
                    return !s && (i || n !== L) || ((t = n).nodeType ? c(e, n, i) : f(e, n, i))
                }]; r > a; a++)
                    if (n = A.relative[e[a].type]) h = [l(u(h), n)];
                    else {
                        if (n = A.filter[e[a].type].apply(null, e[a].matches), n[j]) {
                            for (i = ++a; r > i && !A.relative[e[i].type]; i++);
                            return d(a > 1 && u(h), a > 1 && e.slice(0, a - 1).join("").replace(K, "$1"), n, i > a && p(e.slice(a, i)), r > i && p(e = e.slice(i)), r > i && e.join(""))
                        }
                        h.push(n)
                    }
                return u(h)
            }

            function f(e, t) {
                var i = t.length > 0,
                    r = e.length > 0,
                    s = function (o, a, l, u, d) {
                        var p, f, h, g = [],
                            m = 0,
                            v = "0",
                            w = o && [],
                            E = null != d,
                            b = L,
                            x = o || r && A.find.TAG("*", d && a.parentNode || a),
                            _ = P += null == b ? 1 : Math.E;
                        for (E && (L = a !== R && a, y = s.el); null != (p = x[v]); v++) {
                            if (r && p) {
                                for (f = 0; h = e[f]; f++)
                                    if (h(p, a, l)) {
                                        u.push(p);
                                        break
                                    }
                                E && (P = _, y = ++s.el)
                            }
                            i && ((p = !h && p) && m-- , o && w.push(p))
                        }
                        if (m += v, i && v !== m) {
                            for (f = 0; h = t[f]; f++) h(w, g, a, l);
                            if (o) {
                                if (m > 0)
                                    for (; v--;) !w[v] && !g[v] && (g[v] = D.call(u));
                                g = c(g)
                            }
                            M.apply(u, g), E && !o && g.length > 0 && m + t.length > 1 && n.uniqueSort(u)
                        }
                        return E && (P = _, L = b), w
                    };
                return s.el = 0, i ? F(s) : s
            }

            function h(e, t, i, r) {
                for (var s = 0, o = t.length; o > s; s++) n(e, t[s], i, r);
                return i
            }

            function g(e, t, n, i, r) {
                var s, o, l, u, c, d = a(e);
                d.length;
                if (!i && 1 === d.length) {
                    if (o = d[0] = d[0].slice(0), o.length > 2 && "ID" === (l = o[0]).type && 9 === t.nodeType && !r && A.relative[o[1].type]) {
                        if (t = A.find.ID(l.matches[0].replace(oe, ""), t, r)[0], !t) return n;
                        e = e.slice(o.shift().length)
                    }
                    for (s = ae.POS.test(e) ? -1 : o.length - 1; s >= 0 && (l = o[s], !A.relative[u = l.type]); s--)
                        if ((c = A.find[u]) && (i = c(l.matches[0].replace(oe, ""), ie.test(o[0].type) && t.parentNode || t, r))) {
                            if (o.splice(s, 1), e = i.length && o.join(""), !e) return M.apply(n, O.call(i, 0)), n;
                            break
                        }
                }
                return x(e, d)(i, t, r, n, ie.test(e)), n
            }

            function m() { }
            var y, v, A, w, E, b, x, _, k, L, I = !0,
                S = "undefined",
                j = ("sizcache" + Math.random()).replace(".", ""),
                N = String,
                R = e.document,
                T = R.documentElement,
                P = 0,
                C = 0,
                D = [].pop,
                M = [].push,
                O = [].slice,
                B = [].indexOf || function (e) {
                    for (var t = 0, n = this.length; n > t; t++)
                        if (this[t] === e) return t;
                    return -1
                },
                F = function (e, t) {
                    return e[j] = null == t || t, e
                },
                Y = function () {
                    var e = {},
                        t = [];
                    return F(function (n, i) {
                        return t.push(n) > A.cacheLength && delete e[t.shift()], e[n] = i
                    }, e)
                },
                W = Y(),
                G = Y(),
                U = Y(),
                H = "[\\x20\\t\\r\\n\\f]",
                J = "(?:\\\\.|[-\\w]|[^\\x00-\\xa0])+",
                V = J.replace("w", "w#"),
                z = "([*^$|!~]?=)",
                Q = "\\[" + H + "*(" + J + ")" + H + "*(?:" + z + H + "*(?:(['\"])((?:\\\\.|[^\\\\])*?)\\3|(" + V + ")|)|)" + H + "*\\]",
                q = ":(" + J + ")(?:\\((?:(['\"])((?:\\\\.|[^\\\\])*?)\\2|([^()[\\]]*|(?:(?:" + Q + ")|[^:]|\\\\.)*|.*))\\)|)",
                X = ":(even|odd|eq|gt|lt|nth|first|last)(?:\\(" + H + "*((?:-\\d)?\\d*)" + H + "*\\)|)(?=[^-]|$)",
                K = new RegExp("^" + H + "+|((?:^|[^\\\\])(?:\\\\.)*)" + H + "+$", "g"),
                $ = new RegExp("^" + H + "*," + H + "*"),
                ee = new RegExp("^" + H + "*([\\x20\\t\\r\\n\\f>+~])" + H + "*"),
                te = new RegExp(q),
                ne = /^(?:#([\w\-]+)|(\w+)|\.([\w\-]+))$/,
                ie = /[\x20\t\r\n\f]*[+~]/,
                re = /h\d/i,
                se = /input|select|textarea|button/i,
                oe = /\\(?!\\)/g,
                ae = {
                    ID: new RegExp("^#(" + J + ")"),
                    CLASS: new RegExp("^\\.(" + J + ")"),
                    NAME: new RegExp("^\\[name=['\"]?(" + J + ")['\"]?\\]"),
                    TAG: new RegExp("^(" + J.replace("w", "w*") + ")"),
                    ATTR: new RegExp("^" + Q),
                    PSEUDO: new RegExp("^" + q),
                    POS: new RegExp(X, "i"),
                    CHILD: new RegExp("^:(only|nth|first|last)-child(?:\\(" + H + "*(even|odd|(([+-]|)(\\d*)n|)" + H + "*(?:([+-]|)" + H + "*(\\d+)|))" + H + "*\\)|)", "i"),
                    needsContext: new RegExp("^" + H + "*[>+~]|" + X, "i")
                },
                le = function (e) {
                    var t = R.createElement("div");
                    try {
                        return e(t)
                    } catch (n) {
                        return !1
                    } finally {
                        t = null
                    }
                },
                ue = le(function (e) {
                    return e.appendChild(R.createComment("")), !e.getElementsByTagName("*").length
                }),
                ce = le(function (e) {
                    return e.innerHTML = "<a href='#'></a>", e.firstChild && typeof e.firstChild.getAttribute !== S && "#" === e.firstChild.getAttribute("href")
                }),
                de = le(function (e) {
                    e.innerHTML = "<select></select>";
                    var t = typeof e.lastChild.getAttribute("multiple");
                    return "boolean" !== t && "string" !== t
                }),
                pe = le(function (e) {
                    return e.innerHTML = "<div class='hidden e'></div><div class='hidden'></div>", e.getElementsByClassName && e.getElementsByClassName("e").length ? (e.lastChild.className = "e", 2 === e.getElementsByClassName("e").length) : !1
                }),
                fe = le(function (e) {
                    e.id = j + 0, e.innerHTML = "<a name='" + j + "'></a><div name='" + j + "'></div>", T.insertBefore(e, T.firstChild);
                    var t = R.getElementsByName && R.getElementsByName(j).length === 2 + R.getElementsByName(j + 0).length;
                    return v = !R.getElementById(j), T.removeChild(e), t
                });
            try {
                O.call(T.childNodes, 0)[0].nodeType
            } catch (he) {
                O = function (e) {
                    for (var t, n = []; t = this[e]; e++) n.push(t);
                    return n
                }
            }
            n.matches = function (e, t) {
                return n(e, null, null, t)
            }, n.matchesSelector = function (e, t) {
                return n(t, null, null, [e]).length > 0
            }, w = n.getText = function (e) {
                var t, n = "",
                    i = 0,
                    r = e.nodeType;
                if (r) {
                    if (1 === r || 9 === r || 11 === r) {
                        if ("string" == typeof e.textContent) return e.textContent;
                        for (e = e.firstChild; e; e = e.nextSibling) n += w(e)
                    } else if (3 === r || 4 === r) return e.nodeValue
                } else
                    for (; t = e[i]; i++) n += w(t);
                return n
            }, E = n.isXML = function (e) {
                var t = e && (e.ownerDocument || e).documentElement;
                return t ? "HTML" !== t.nodeName : !1
            }, b = n.contains = T.contains ? function (e, t) {
                var n = 9 === e.nodeType ? e.documentElement : e,
                    i = t && t.parentNode;
                return e === i || !!(i && 1 === i.nodeType && n.contains && n.contains(i))
            } : T.compareDocumentPosition ? function (e, t) {
                return t && !!(16 & e.compareDocumentPosition(t))
            } : function (e, t) {
                for (; t = t.parentNode;)
                    if (t === e) return !0;
                return !1
            }, n.attr = function (e, t) {
                var n, i = E(e);
                return i || (t = t.toLowerCase()), (n = A.attrHandle[t]) ? n(e) : i || de ? e.getAttribute(t) : (n = e.getAttributeNode(t), n ? "boolean" == typeof e[t] ? e[t] ? t : null : n.specified ? n.value : null : null)
            }, A = n.selectors = {
                cacheLength: 50,
                createPseudo: F,
                match: ae,
                attrHandle: ce ? {} : {
                    href: function (e) {
                        return e.getAttribute("href", 2)
                    },
                    type: function (e) {
                        return e.getAttribute("type")
                    }
                },
                find: {
                    ID: v ? function (e, t, n) {
                        if (typeof t.getElementById !== S && !n) {
                            var i = t.getElementById(e);
                            return i && i.parentNode ? [i] : []
                        }
                    } : function (e, n, i) {
                        if (typeof n.getElementById !== S && !i) {
                            var r = n.getElementById(e);
                            return r ? r.id === e || typeof r.getAttributeNode !== S && r.getAttributeNode("id").value === e ? [r] : t : []
                        }
                    },
                    TAG: ue ? function (e, t) {
                        return typeof t.getElementsByTagName !== S ? t.getElementsByTagName(e) : void 0
                    } : function (e, t) {
                        var n = t.getElementsByTagName(e);
                        if ("*" === e) {
                            for (var i, r = [], s = 0; i = n[s]; s++) 1 === i.nodeType && r.push(i);
                            return r
                        }
                        return n
                    },
                    NAME: fe && function (e, t) {
                        return typeof t.getElementsByName !== S ? t.getElementsByName(name) : void 0
                    },
                    CLASS: pe && function (e, t, n) {
                        return typeof t.getElementsByClassName === S || n ? void 0 : t.getElementsByClassName(e)
                    }
                },
                relative: {
                    ">": {
                        dir: "parentNode",
                        first: !0
                    },
                    " ": {
                        dir: "parentNode"
                    },
                    "+": {
                        dir: "previousSibling",
                        first: !0
                    },
                    "~": {
                        dir: "previousSibling"
                    }
                },
                preFilter: {
                    ATTR: function (e) {
                        return e[1] = e[1].replace(oe, ""), e[3] = (e[4] || e[5] || "").replace(oe, ""), "~=" === e[2] && (e[3] = " " + e[3] + " "), e.slice(0, 4)
                    },
                    CHILD: function (e) {
                        return e[1] = e[1].toLowerCase(), "nth" === e[1] ? (e[2] || n.error(e[0]), e[3] = +(e[3] ? e[4] + (e[5] || 1) : 2 * ("even" === e[2] || "odd" === e[2])), e[4] = +(e[6] + e[7] || "odd" === e[2])) : e[2] && n.error(e[0]), e
                    },
                    PSEUDO: function (e) {
                        var t, n;
                        return ae.CHILD.test(e[0]) ? null : (e[3] ? e[2] = e[3] : (t = e[4]) && (te.test(t) && (n = a(t, !0)) && (n = t.indexOf(")", t.length - n) - t.length) && (t = t.slice(0, n), e[0] = e[0].slice(0, n)), e[2] = t), e.slice(0, 3))
                    }
                },
                filter: {
                    ID: v ? function (e) {
                        return e = e.replace(oe, ""),
                            function (t) {
                                return t.getAttribute("id") === e
                            }
                    } : function (e) {
                        return e = e.replace(oe, ""),
                            function (t) {
                                var n = typeof t.getAttributeNode !== S && t.getAttributeNode("id");
                                return n && n.value === e
                            }
                    },
                    TAG: function (e) {
                        return "*" === e ? function () {
                            return !0
                        } : (e = e.replace(oe, "").toLowerCase(), function (t) {
                            return t.nodeName && t.nodeName.toLowerCase() === e
                        })
                    },
                    CLASS: function (e) {
                        var t = W[j][e];
                        return t || (t = W(e, new RegExp("(^|" + H + ")" + e + "(" + H + "|$)"))),
                            function (e) {
                                return t.test(e.className || typeof e.getAttribute !== S && e.getAttribute("class") || "")
                            }
                    },
                    ATTR: function (e, t, i) {
                        return function (r) {
                            var s = n.attr(r, e);
                            return null == s ? "!=" === t : t ? (s += "", "=" === t ? s === i : "!=" === t ? s !== i : "^=" === t ? i && 0 === s.indexOf(i) : "*=" === t ? i && s.indexOf(i) > -1 : "$=" === t ? i && s.substr(s.length - i.length) === i : "~=" === t ? (" " + s + " ").indexOf(i) > -1 : "|=" === t ? s === i || s.substr(0, i.length + 1) === i + "-" : !1) : !0
                        }
                    },
                    CHILD: function (e, t, n, i) {
                        return "nth" === e ? function (e) {
                            var t, r, s = e.parentNode;
                            if (1 === n && 0 === i) return !0;
                            if (s)
                                for (r = 0, t = s.firstChild; t && (1 !== t.nodeType || (r++ , e !== t)); t = t.nextSibling);
                            return r -= i, r === n || r % n === 0 && r / n >= 0
                        } : function (t) {
                            var n = t;
                            switch (e) {
                                case "only":
                                case "first":
                                    for (; n = n.previousSibling;)
                                        if (1 === n.nodeType) return !1;
                                    if ("first" === e) return !0;
                                    n = t;
                                case "last":
                                    for (; n = n.nextSibling;)
                                        if (1 === n.nodeType) return !1;
                                    return !0
                            }
                        }
                    },
                    PSEUDO: function (e, t) {
                        var i, r = A.pseudos[e] || A.setFilters[e.toLowerCase()] || n.error("unsupported pseudo: " + e);
                        return r[j] ? r(t) : r.length > 1 ? (i = [e, e, "", t], A.setFilters.hasOwnProperty(e.toLowerCase()) ? F(function (e, n) {
                            for (var i, s = r(e, t), o = s.length; o--;) i = B.call(e, s[o]), e[i] = !(n[i] = s[o])
                        }) : function (e) {
                            return r(e, 0, i)
                        }) : r
                    }
                },
                pseudos: {
                    not: F(function (e) {
                        var t = [],
                            n = [],
                            i = x(e.replace(K, "$1"));
                        return i[j] ? F(function (e, t, n, r) {
                            for (var s, o = i(e, null, r, []), a = e.length; a--;)(s = o[a]) && (e[a] = !(t[a] = s))
                        }) : function (e, r, s) {
                            return t[0] = e, i(t, null, s, n), !n.pop()
                        }
                    }),
                    has: F(function (e) {
                        return function (t) {
                            return n(e, t).length > 0
                        }
                    }),
                    contains: F(function (e) {
                        return function (t) {
                            return (t.textContent || t.innerText || w(t)).indexOf(e) > -1
                        }
                    }),
                    enabled: function (e) {
                        return e.disabled === !1
                    },
                    disabled: function (e) {
                        return e.disabled === !0
                    },
                    checked: function (e) {
                        var t = e.nodeName.toLowerCase();
                        return "input" === t && !!e.checked || "option" === t && !!e.selected
                    },
                    selected: function (e) {
                        return e.parentNode && e.parentNode.selectedIndex, e.selected === !0
                    },
                    parent: function (e) {
                        return !A.pseudos.empty(e)
                    },
                    empty: function (e) {
                        var t;
                        for (e = e.firstChild; e;) {
                            if (e.nodeName > "@" || 3 === (t = e.nodeType) || 4 === t) return !1;
                            e = e.nextSibling
                        }
                        return !0
                    },
                    header: function (e) {
                        return re.test(e.nodeName)
                    },
                    text: function (e) {
                        var t, n;
                        return "input" === e.nodeName.toLowerCase() && "text" === (t = e.type) && (null == (n = e.getAttribute("type")) || n.toLowerCase() === t)
                    },
                    radio: i("radio"),
                    checkbox: i("checkbox"),
                    file: i("file"),
                    password: i("password"),
                    image: i("image"),
                    submit: r("submit"),
                    reset: r("reset"),
                    button: function (e) {
                        var t = e.nodeName.toLowerCase();
                        return "input" === t && "button" === e.type || "button" === t
                    },
                    input: function (e) {
                        return se.test(e.nodeName)
                    },
                    focus: function (e) {
                        var t = e.ownerDocument;
                        return e === t.activeElement && (!t.hasFocus || t.hasFocus()) && (!!e.type || !!e.href)
                    },
                    active: function (e) {
                        return e === e.ownerDocument.activeElement
                    },
                    first: s(function () {
                        return [0]
                    }),
                    last: s(function (e, t) {
                        return [t - 1]
                    }),
                    eq: s(function (e, t, n) {
                        return [0 > n ? n + t : n]
                    }),
                    even: s(function (e, t) {
                        for (var n = 0; t > n; n += 2) e.push(n);
                        return e
                    }),
                    odd: s(function (e, t) {
                        for (var n = 1; t > n; n += 2) e.push(n);
                        return e
                    }),
                    lt: s(function (e, t, n) {
                        for (var i = 0 > n ? n + t : n; --i >= 0;) e.push(i);
                        return e
                    }),
                    gt: s(function (e, t, n) {
                        for (var i = 0 > n ? n + t : n; ++i < t;) e.push(i);
                        return e
                    })
                }
            }, _ = T.compareDocumentPosition ? function (e, t) {
                return e === t ? (k = !0, 0) : (e.compareDocumentPosition && t.compareDocumentPosition ? 4 & e.compareDocumentPosition(t) : e.compareDocumentPosition) ? -1 : 1
            } : function (e, t) {
                if (e === t) return k = !0, 0;
                if (e.sourceIndex && t.sourceIndex) return e.sourceIndex - t.sourceIndex;
                var n, i, r = [],
                    s = [],
                    a = e.parentNode,
                    l = t.parentNode,
                    u = a;
                if (a === l) return o(e, t);
                if (!a) return -1;
                if (!l) return 1;
                for (; u;) r.unshift(u), u = u.parentNode;
                for (u = l; u;) s.unshift(u), u = u.parentNode;
                n = r.length, i = s.length;
                for (var c = 0; n > c && i > c; c++)
                    if (r[c] !== s[c]) return o(r[c], s[c]);
                return c === n ? o(e, s[c], -1) : o(r[c], t, 1)
            }, [0, 0].sort(_), I = !k, n.uniqueSort = function (e) {
                var t, n = 1;
                if (k = I, e.sort(_), k)
                    for (; t = e[n]; n++) t === e[n - 1] && e.splice(n--, 1);
                return e
            }, n.error = function (e) {
                throw new Error("Syntax error, unrecognized expression: " + e)
            }, x = n.compile = function (e, t) {
                var n, i = [],
                    r = [],
                    s = U[j][e];
                if (!s) {
                    for (t || (t = a(e)), n = t.length; n--;) s = p(t[n]), s[j] ? i.push(s) : r.push(s);
                    s = U(e, f(r, i))
                }
                return s
            }, R.querySelectorAll && function () {
                var e, t = g,
                    i = /'|\\/g,
                    r = /\=[\x20\t\r\n\f]*([^'"\]]*)[\x20\t\r\n\f]*\]/g,
                    s = [":focus"],
                    o = [":active", ":focus"],
                    l = T.matchesSelector || T.mozMatchesSelector || T.webkitMatchesSelector || T.oMatchesSelector || T.msMatchesSelector;
                le(function (e) {
                    e.innerHTML = "<select><option selected=''></option></select>", e.querySelectorAll("[selected]").length || s.push("\\[" + H + "*(?:checked|disabled|ismap|multiple|readonly|selected|value)"), e.querySelectorAll(":checked").length || s.push(":checked")
                }), le(function (e) {
                    e.innerHTML = "<p test=''></p>", e.querySelectorAll("[test^='']").length && s.push("[*^$]=" + H + "*(?:\"\"|'')"), e.innerHTML = "<input type='hidden'/>", e.querySelectorAll(":enabled").length || s.push(":enabled", ":disabled")
                }), s = new RegExp(s.join("|")), g = function (e, n, r, o, l) {
                    if (!(o || l || s && s.test(e))) {
                        var u, c, d = !0,
                            p = j,
                            f = n,
                            h = 9 === n.nodeType && e;
                        if (1 === n.nodeType && "object" !== n.nodeName.toLowerCase()) {
                            for (u = a(e), (d = n.getAttribute("id")) ? p = d.replace(i, "\\$&") : n.setAttribute("id", p), p = "[id='" + p + "'] ", c = u.length; c--;) u[c] = p + u[c].join("");
                            f = ie.test(e) && n.parentNode || n, h = u.join(",")
                        }
                        if (h) try {
                            return M.apply(r, O.call(f.querySelectorAll(h), 0)), r
                        } catch (g) { } finally {
                                d || n.removeAttribute("id")
                            }
                    }
                    return t(e, n, r, o, l)
                }, l && (le(function (t) {
                    e = l.call(t, "div");
                    try {
                        l.call(t, "[test!='']:sizzle"), o.push("!=", q)
                    } catch (n) { }
                }), o = new RegExp(o.join("|")), n.matchesSelector = function (t, i) {
                    if (i = i.replace(r, "='$1']"), !(E(t) || o.test(i) || s && s.test(i))) try {
                        var a = l.call(t, i);
                        if (a || e || t.document && 11 !== t.document.nodeType) return a
                    } catch (u) { }
                    return n(i, null, null, [t]).length > 0
                })
            }(), A.pseudos.nth = A.pseudos.eq, A.filters = m.prototype = A.pseudos, A.setFilters = new m, n.attr = Z.attr, Z.find = n, Z.expr = n.selectors, Z.expr[":"] = Z.expr.pseudos, Z.unique = n.uniqueSort, Z.text = n.getText, Z.isXMLDoc = n.isXML, Z.contains = n.contains
        }(e);
    var Ce = /Until$/,
        De = /^(?:parents|prev(?:Until|All))/,
        Me = /^.[^:#\[\.,]*$/,
        Oe = Z.expr.match.needsContext,
        Be = {
            children: !0,
            contents: !0,
            next: !0,
            prev: !0
        };
    Z.fn.extend({
        find: function (e) {
            var t, n, i, r, s, o, a = this;
            if ("string" != typeof e) return Z(e).filter(function () {
                for (t = 0, n = a.length; n > t; t++)
                    if (Z.contains(a[t], this)) return !0
            });
            for (o = this.pushStack("", "find", e), t = 0, n = this.length; n > t; t++)
                if (i = o.length, Z.find(e, this[t], o), t > 0)
                    for (r = i; r < o.length; r++)
                        for (s = 0; i > s; s++)
                            if (o[s] === o[r]) {
                                o.splice(r--, 1);
                                break
                            }
            return o
        },
        has: function (e) {
            var t, n = Z(e, this),
                i = n.length;
            return this.filter(function () {
                for (t = 0; i > t; t++)
                    if (Z.contains(this, n[t])) return !0
            })
        },
        not: function (e) {
            return this.pushStack(u(this, e, !1), "not", e)
        },
        filter: function (e) {
            return this.pushStack(u(this, e, !0), "filter", e)
        },
        is: function (e) {
            return !!e && ("string" == typeof e ? Oe.test(e) ? Z(e, this.context).index(this[0]) >= 0 : Z.filter(e, this).length > 0 : this.filter(e).length > 0)
        },
        closest: function (e, t) {
            for (var n, i = 0, r = this.length, s = [], o = Oe.test(e) || "string" != typeof e ? Z(e, t || this.context) : 0; r > i; i++)
                for (n = this[i]; n && n.ownerDocument && n !== t && 11 !== n.nodeType;) {
                    if (o ? o.index(n) > -1 : Z.find.matchesSelector(n, e)) {
                        s.push(n);
                        break
                    }
                    n = n.parentNode
                }
            return s = s.length > 1 ? Z.unique(s) : s, this.pushStack(s, "closest", e)
        },
        index: function (e) {
            return e ? "string" == typeof e ? Z.inArray(this[0], Z(e)) : Z.inArray(e.jquery ? e[0] : e, this) : this[0] && this[0].parentNode ? this.prevAll().length : -1
        },
        add: function (e, t) {
            var n = "string" == typeof e ? Z(e, t) : Z.makeArray(e && e.nodeType ? [e] : e),
                i = Z.merge(this.get(), n);
            return this.pushStack(a(n[0]) || a(i[0]) ? i : Z.unique(i))
        },
        addBack: function (e) {
            return this.add(null == e ? this.prevObject : this.prevObject.filter(e))
        }
    }), Z.fn.andSelf = Z.fn.addBack, Z.each({
        parent: function (e) {
            var t = e.parentNode;
            return t && 11 !== t.nodeType ? t : null
        },
        parents: function (e) {
            return Z.dir(e, "parentNode")
        },
        parentsUntil: function (e, t, n) {
            return Z.dir(e, "parentNode", n)
        },
        next: function (e) {
            return l(e, "nextSibling")
        },
        prev: function (e) {
            return l(e, "previousSibling")
        },
        nextAll: function (e) {
            return Z.dir(e, "nextSibling")
        },
        prevAll: function (e) {
            return Z.dir(e, "previousSibling")
        },
        nextUntil: function (e, t, n) {
            return Z.dir(e, "nextSibling", n)
        },
        prevUntil: function (e, t, n) {
            return Z.dir(e, "previousSibling", n)
        },
        siblings: function (e) {
            return Z.sibling((e.parentNode || {}).firstChild, e)
        },
        children: function (e) {
            return Z.sibling(e.firstChild);
        },
        contents: function (e) {
            return Z.nodeName(e, "iframe") ? e.contentDocument || e.contentWindow.document : Z.merge([], e.childNodes)
        }
    }, function (e, t) {
        Z.fn[e] = function (n, i) {
            var r = Z.map(this, t, n);
            return Ce.test(e) || (i = n), i && "string" == typeof i && (r = Z.filter(i, r)), r = this.length > 1 && !Be[e] ? Z.unique(r) : r, this.length > 1 && De.test(e) && (r = r.reverse()), this.pushStack(r, e, z.call(arguments).join(","))
        }
    }), Z.extend({
        filter: function (e, t, n) {
            return n && (e = ":not(" + e + ")"), 1 === t.length ? Z.find.matchesSelector(t[0], e) ? [t[0]] : [] : Z.find.matches(e, t)
        },
        dir: function (e, n, i) {
            for (var r = [], s = e[n]; s && 9 !== s.nodeType && (i === t || 1 !== s.nodeType || !Z(s).is(i));) 1 === s.nodeType && r.push(s), s = s[n];
            return r
        },
        sibling: function (e, t) {
            for (var n = []; e; e = e.nextSibling) 1 === e.nodeType && e !== t && n.push(e);
            return n
        }
    });
    var Fe = "abbr|article|aside|audio|bdi|canvas|data|datalist|details|figcaption|figure|footer|header|hgroup|mark|meter|nav|output|progress|section|summary|time|video",
        Ye = / jQuery\d+="(?:null|\d+)"/g,
        We = /^\s+/,
        Ge = /<(?!area|br|col|embed|hr|img|input|link|meta|param)(([\w:]+)[^>]*)\/>/gi,
        Ue = /<([\w:]+)/,
        He = /<tbody/i,
        Je = /<|&#?\w+;/,
        Ve = /<(?:script|style|link)/i,
        ze = /<(?:script|object|embed|option|style)/i,
        Qe = new RegExp("<(?:" + Fe + ")[\\s/>]", "i"),
        qe = /^(?:checkbox|radio)$/,
        Xe = /checked\s*(?:[^=]|=\s*.checked.)/i,
        Ke = /\/(java|ecma)script/i,
        Ze = /^\s*<!(?:\[CDATA\[|\-\-)|[\]\-]{2}>\s*$/g,
        $e = {
            option: [1, "<select multiple='multiple'>", "</select>"],
            legend: [1, "<fieldset>", "</fieldset>"],
            thead: [1, "<table>", "</table>"],
            tr: [2, "<table><tbody>", "</tbody></table>"],
            td: [3, "<table><tbody><tr>", "</tr></tbody></table>"],
            col: [2, "<table><tbody></tbody><colgroup>", "</colgroup></table>"],
            area: [1, "<map>", "</map>"],
            _default: [0, "", ""]
        },
        et = c(W),
        tt = et.appendChild(W.createElement("div"));
    $e.optgroup = $e.option, $e.tbody = $e.tfoot = $e.colgroup = $e.caption = $e.thead, $e.th = $e.td, Z.support.htmlSerialize || ($e._default = [1, "X<div>", "</div>"]), Z.fn.extend({
        text: function (e) {
            return Z.access(this, function (e) {
                return e === t ? Z.text(this) : this.empty().append((this[0] && this[0].ownerDocument || W).createTextNode(e))
            }, null, e, arguments.length)
        },
        wrapAll: function (e) {
            if (Z.isFunction(e)) return this.each(function (t) {
                Z(this).wrapAll(e.call(this, t))
            });
            if (this[0]) {
                var t = Z(e, this[0].ownerDocument).eq(0).clone(!0);
                this[0].parentNode && t.insertBefore(this[0]), t.map(function () {
                    for (var e = this; e.firstChild && 1 === e.firstChild.nodeType;) e = e.firstChild;
                    return e
                }).append(this)
            }
            return this
        },
        wrapInner: function (e) {
            return Z.isFunction(e) ? this.each(function (t) {
                Z(this).wrapInner(e.call(this, t))
            }) : this.each(function () {
                var t = Z(this),
                    n = t.contents();
                n.length ? n.wrapAll(e) : t.append(e)
            })
        },
        wrap: function (e) {
            var t = Z.isFunction(e);
            return this.each(function (n) {
                Z(this).wrapAll(t ? e.call(this, n) : e)
            })
        },
        unwrap: function () {
            return this.parent().each(function () {
                Z.nodeName(this, "body") || Z(this).replaceWith(this.childNodes)
            }).end()
        },
        append: function () {
            return this.domManip(arguments, !0, function (e) {
                (1 === this.nodeType || 11 === this.nodeType) && this.appendChild(e)
            })
        },
        prepend: function () {
            return this.domManip(arguments, !0, function (e) {
                (1 === this.nodeType || 11 === this.nodeType) && this.insertBefore(e, this.firstChild)
            })
        },
        before: function () {
            if (!a(this[0])) return this.domManip(arguments, !1, function (e) {
                this.parentNode.insertBefore(e, this)
            });
            if (arguments.length) {
                var e = Z.clean(arguments);
                return this.pushStack(Z.merge(e, this), "before", this.selector)
            }
        },
        after: function () {
            if (!a(this[0])) return this.domManip(arguments, !1, function (e) {
                this.parentNode.insertBefore(e, this.nextSibling)
            });
            if (arguments.length) {
                var e = Z.clean(arguments);
                return this.pushStack(Z.merge(this, e), "after", this.selector)
            }
        },
        remove: function (e, t) {
            for (var n, i = 0; null != (n = this[i]); i++) e && !Z.filter(e, [n]).length || (!t && 1 === n.nodeType && (Z.cleanData(n.getElementsByTagName("*")), Z.cleanData([n])), n.parentNode && n.parentNode.removeChild(n));
            return this
        },
        empty: function () {
            for (var e, t = 0; null != (e = this[t]); t++)
                for (1 === e.nodeType && Z.cleanData(e.getElementsByTagName("*")); e.firstChild;) e.removeChild(e.firstChild);
            return this
        },
        clone: function (e, t) {
            return e = null == e ? !1 : e, t = null == t ? e : t, this.map(function () {
                return Z.clone(this, e, t)
            })
        },
        html: function (e) {
            return Z.access(this, function (e) {
                var n = this[0] || {},
                    i = 0,
                    r = this.length;
                if (e === t) return 1 === n.nodeType ? n.innerHTML.replace(Ye, "") : t;
                if ("string" == typeof e && !Ve.test(e) && (Z.support.htmlSerialize || !Qe.test(e)) && (Z.support.leadingWhitespace || !We.test(e)) && !$e[(Ue.exec(e) || ["", ""])[1].toLowerCase()]) {
                    e = e.replace(Ge, "<$1></$2>");
                    try {
                        for (; r > i; i++) n = this[i] || {}, 1 === n.nodeType && (Z.cleanData(n.getElementsByTagName("*")), n.innerHTML = e);
                        n = 0
                    } catch (s) { }
                }
                n && this.empty().append(e)
            }, null, e, arguments.length)
        },
        replaceWith: function (e) {
            return a(this[0]) ? this.length ? this.pushStack(Z(Z.isFunction(e) ? e() : e), "replaceWith", e) : this : Z.isFunction(e) ? this.each(function (t) {
                var n = Z(this),
                    i = n.html();
                n.replaceWith(e.call(this, t, i))
            }) : ("string" != typeof e && (e = Z(e).detach()), this.each(function () {
                var t = this.nextSibling,
                    n = this.parentNode;
                Z(this).remove(), t ? Z(t).before(e) : Z(n).append(e)
            }))
        },
        detach: function (e) {
            return this.remove(e, !0)
        },
        domManip: function (e, n, i) {
            e = [].concat.apply([], e);
            var r, s, o, a, l = 0,
                u = e[0],
                c = [],
                p = this.length;
            if (!Z.support.checkClone && p > 1 && "string" == typeof u && Xe.test(u)) return this.each(function () {
                Z(this).domManip(e, n, i)
            });
            if (Z.isFunction(u)) return this.each(function (r) {
                var s = Z(this);
                e[0] = u.call(this, r, n ? s.html() : t), s.domManip(e, n, i)
            });
            if (this[0]) {
                if (r = Z.buildFragment(e, this, c), o = r.fragment, s = o.firstChild, 1 === o.childNodes.length && (o = s), s)
                    for (n = n && Z.nodeName(s, "tr"), a = r.cacheable || p - 1; p > l; l++) i.call(n && Z.nodeName(this[l], "table") ? d(this[l], "tbody") : this[l], l === a ? o : Z.clone(o, !0, !0));
                o = s = null, c.length && Z.each(c, function (e, t) {
                    t.src ? Z.ajax ? Z.ajax({
                        url: t.src,
                        type: "GET",
                        dataType: "script",
                        async: !1,
                        global: !1,
                        "throws": !0
                    }) : Z.error("no ajax") : Z.globalEval((t.text || t.textContent || t.innerHTML || "").replace(Ze, "")), t.parentNode && t.parentNode.removeChild(t)
                })
            }
            return this
        }
    }), Z.buildFragment = function (e, n, i) {
        var r, s, o, a = e[0];
        return n = n || W, n = !n.nodeType && n[0] || n, n = n.ownerDocument || n, 1 === e.length && "string" == typeof a && a.length < 512 && n === W && "<" === a.charAt(0) && !ze.test(a) && (Z.support.checkClone || !Xe.test(a)) && (Z.support.html5Clone || !Qe.test(a)) && (s = !0, r = Z.fragments[a], o = r !== t), r || (r = n.createDocumentFragment(), Z.clean(e, n, r, i), s && (Z.fragments[a] = o && r)), {
            fragment: r,
            cacheable: s
        }
    }, Z.fragments = {}, Z.each({
        appendTo: "append",
        prependTo: "prepend",
        insertBefore: "before",
        insertAfter: "after",
        replaceAll: "replaceWith"
    }, function (e, t) {
        Z.fn[e] = function (n) {
            var i, r = 0,
                s = [],
                o = Z(n),
                a = o.length,
                l = 1 === this.length && this[0].parentNode;
            if ((null == l || l && 11 === l.nodeType && 1 === l.childNodes.length) && 1 === a) return o[t](this[0]), this;
            for (; a > r; r++) i = (r > 0 ? this.clone(!0) : this).get(), Z(o[r])[t](i), s = s.concat(i);
            return this.pushStack(s, e, o.selector)
        }
    }), Z.extend({
        clone: function (e, t, n) {
            var i, r, s, o;
            if (Z.support.html5Clone || Z.isXMLDoc(e) || !Qe.test("<" + e.nodeName + ">") ? o = e.cloneNode(!0) : (tt.innerHTML = e.outerHTML, tt.removeChild(o = tt.firstChild)), !(Z.support.noCloneEvent && Z.support.noCloneChecked || 1 !== e.nodeType && 11 !== e.nodeType || Z.isXMLDoc(e)))
                for (f(e, o), i = h(e), r = h(o), s = 0; i[s]; ++s) r[s] && f(i[s], r[s]);
            if (t && (p(e, o), n))
                for (i = h(e), r = h(o), s = 0; i[s]; ++s) p(i[s], r[s]);
            return i = r = null, o
        },
        clean: function (e, t, n, i) {
            var r, s, o, a, l, u, d, p, f, h, m, y = t === W && et,
                v = [];
            for (t && "undefined" != typeof t.createDocumentFragment || (t = W), r = 0; null != (o = e[r]); r++)
                if ("number" == typeof o && (o += ""), o) {
                    if ("string" == typeof o)
                        if (Je.test(o)) {
                            for (y = y || c(t), d = t.createElement("div"), y.appendChild(d), o = o.replace(Ge, "<$1></$2>"), a = (Ue.exec(o) || ["", ""])[1].toLowerCase(), l = $e[a] || $e._default, u = l[0], d.innerHTML = l[1] + o + l[2]; u--;) d = d.lastChild;
                            if (!Z.support.tbody)
                                for (p = He.test(o), f = "table" !== a || p ? "<table>" !== l[1] || p ? [] : d.childNodes : d.firstChild && d.firstChild.childNodes, s = f.length - 1; s >= 0; --s) Z.nodeName(f[s], "tbody") && !f[s].childNodes.length && f[s].parentNode.removeChild(f[s]);
                            !Z.support.leadingWhitespace && We.test(o) && d.insertBefore(t.createTextNode(We.exec(o)[0]), d.firstChild), o = d.childNodes, d.parentNode.removeChild(d)
                        } else o = t.createTextNode(o);
                    o.nodeType ? v.push(o) : Z.merge(v, o)
                }
            if (d && (o = d = y = null), !Z.support.appendChecked)
                for (r = 0; null != (o = v[r]); r++) Z.nodeName(o, "input") ? g(o) : "undefined" != typeof o.getElementsByTagName && Z.grep(o.getElementsByTagName("input"), g);
            if (n)
                for (h = function (e) {
                    return !e.type || Ke.test(e.type) ? i ? i.push(e.parentNode ? e.parentNode.removeChild(e) : e) : n.appendChild(e) : void 0
                }, r = 0; null != (o = v[r]); r++) Z.nodeName(o, "script") && h(o) || (n.appendChild(o), "undefined" != typeof o.getElementsByTagName && (m = Z.grep(Z.merge([], o.getElementsByTagName("script")), h), v.splice.apply(v, [r + 1, 0].concat(m)), r += m.length));
            return v
        },
        cleanData: function (e, t) {
            for (var n, i, r, s, o = 0, a = Z.expando, l = Z.cache, u = Z.support.deleteExpando, c = Z.event.special; null != (r = e[o]); o++)
                if ((t || Z.acceptData(r)) && (i = r[a], n = i && l[i])) {
                    if (n.events)
                        for (s in n.events) c[s] ? Z.event.remove(r, s) : Z.removeEvent(r, s, n.handle);
                    l[i] && (delete l[i], u ? delete r[a] : r.removeAttribute ? r.removeAttribute(a) : r[a] = null, Z.deletedIds.push(i))
                }
        }
    }),
        function () {
            var e, t;
            Z.uaMatch = function (e) {
                e = e.toLowerCase();
                var t = /(chrome)[ \/]([\w.]+)/.exec(e) || /(webkit)[ \/]([\w.]+)/.exec(e) || /(opera)(?:.*version|)[ \/]([\w.]+)/.exec(e) || /(msie) ([\w.]+)/.exec(e) || e.indexOf("compatible") < 0 && /(mozilla)(?:.*? rv:([\w.]+)|)/.exec(e) || [];
                return {
                    browser: t[1] || "",
                    version: t[2] || "0"
                }
            }, e = Z.uaMatch(U.userAgent), t = {}, e.browser && (t[e.browser] = !0, t.version = e.version), t.chrome ? t.webkit = !0 : t.webkit && (t.safari = !0), Z.browser = t, Z.sub = function () {
                function e(t, n) {
                    return new e.fn.init(t, n)
                }
                Z.extend(!0, e, this), e.superclass = this, e.fn = e.prototype = this(), e.fn.constructor = e, e.sub = this.sub, e.fn.init = function n(n, i) {
                    return i && i instanceof Z && !(i instanceof e) && (i = e(i)), Z.fn.init.call(this, n, i, t)
                }, e.fn.init.prototype = e.fn;
                var t = e(W);
                return e
            }
        }();
    var nt, it, rt, st = /alpha\([^)]*\)/i,
        ot = /opacity=([^)]*)/,
        at = /^(top|right|bottom|left)$/,
        lt = /^(none|table(?!-c[ea]).+)/,
        ut = /^margin/,
        ct = new RegExp("^(" + $ + ")(.*)$", "i"),
        dt = new RegExp("^(" + $ + ")(?!px)[a-z%]+$", "i"),
        pt = new RegExp("^([-+])=(" + $ + ")", "i"),
        ft = {},
        ht = {
            position: "absolute",
            visibility: "hidden",
            display: "block"
        },
        gt = {
            letterSpacing: 0,
            fontWeight: 400
        },
        mt = ["Top", "Right", "Bottom", "Left"],
        yt = ["Webkit", "O", "Moz", "ms"],
        vt = Z.fn.toggle;
    Z.fn.extend({
        css: function (e, n) {
            return Z.access(this, function (e, n, i) {
                return i !== t ? Z.style(e, n, i) : Z.css(e, n)
            }, e, n, arguments.length > 1)
        },
        show: function () {
            return v(this, !0)
        },
        hide: function () {
            return v(this)
        },
        toggle: function (e, t) {
            var n = "boolean" == typeof e;
            return Z.isFunction(e) && Z.isFunction(t) ? vt.apply(this, arguments) : this.each(function () {
                (n ? e : y(this)) ? Z(this).show() : Z(this).hide()
            })
        }
    }), Z.extend({
        cssHooks: {
            opacity: {
                get: function (e, t) {
                    if (t) {
                        var n = nt(e, "opacity");
                        return "" === n ? "1" : n
                    }
                }
            }
        },
        cssNumber: {
            fillOpacity: !0,
            fontWeight: !0,
            lineHeight: !0,
            opacity: !0,
            orphans: !0,
            widows: !0,
            zIndex: !0,
            zoom: !0
        },
        cssProps: {
            "float": Z.support.cssFloat ? "cssFloat" : "styleFloat"
        },
        style: function (e, n, i, r) {
            if (e && 3 !== e.nodeType && 8 !== e.nodeType && e.style) {
                var s, o, a, l = Z.camelCase(n),
                    u = e.style;
                if (n = Z.cssProps[l] || (Z.cssProps[l] = m(u, l)), a = Z.cssHooks[n] || Z.cssHooks[l], i === t) return a && "get" in a && (s = a.get(e, !1, r)) !== t ? s : u[n];
                if (o = typeof i, "string" === o && (s = pt.exec(i)) && (i = (s[1] + 1) * s[2] + parseFloat(Z.css(e, n)), o = "number"), !(null == i || "number" === o && isNaN(i) || ("number" === o && !Z.cssNumber[l] && (i += "px"), a && "set" in a && (i = a.set(e, i, r)) === t))) try {
                    u[n] = i
                } catch (c) { }
            }
        },
        css: function (e, n, i, r) {
            var s, o, a, l = Z.camelCase(n);
            return n = Z.cssProps[l] || (Z.cssProps[l] = m(e.style, l)), a = Z.cssHooks[n] || Z.cssHooks[l], a && "get" in a && (s = a.get(e, !0, r)), s === t && (s = nt(e, n)), "normal" === s && n in gt && (s = gt[n]), i || r !== t ? (o = parseFloat(s), i || Z.isNumeric(o) ? o || 0 : s) : s
        },
        swap: function (e, t, n) {
            var i, r, s = {};
            for (r in t) s[r] = e.style[r], e.style[r] = t[r];
            i = n.call(e);
            for (r in t) e.style[r] = s[r];
            return i
        }
    }), e.getComputedStyle ? nt = function (t, n) {
        var i, r, s, o, a = e.getComputedStyle(t, null),
            l = t.style;
        return a && (i = a[n], "" === i && !Z.contains(t.ownerDocument, t) && (i = Z.style(t, n)), dt.test(i) && ut.test(n) && (r = l.width, s = l.minWidth, o = l.maxWidth, l.minWidth = l.maxWidth = l.width = i, i = a.width, l.width = r, l.minWidth = s, l.maxWidth = o)), i
    } : W.documentElement.currentStyle && (nt = function (e, t) {
        var n, i, r = e.currentStyle && e.currentStyle[t],
            s = e.style;
        return null == r && s && s[t] && (r = s[t]), dt.test(r) && !at.test(t) && (n = s.left, i = e.runtimeStyle && e.runtimeStyle.left, i && (e.runtimeStyle.left = e.currentStyle.left), s.left = "fontSize" === t ? "1em" : r, r = s.pixelLeft + "px", s.left = n, i && (e.runtimeStyle.left = i)), "" === r ? "auto" : r
    }), Z.each(["height", "width"], function (e, t) {
        Z.cssHooks[t] = {
            get: function (e, n, i) {
                return n ? 0 === e.offsetWidth && lt.test(nt(e, "display")) ? Z.swap(e, ht, function () {
                    return E(e, t, i)
                }) : E(e, t, i) : void 0
            },
            set: function (e, n, i) {
                return A(e, n, i ? w(e, t, i, Z.support.boxSizing && "border-box" === Z.css(e, "boxSizing")) : 0)
            }
        }
    }), Z.support.opacity || (Z.cssHooks.opacity = {
        get: function (e, t) {
            return ot.test((t && e.currentStyle ? e.currentStyle.filter : e.style.filter) || "") ? .01 * parseFloat(RegExp.$1) + "" : t ? "1" : ""
        },
        set: function (e, t) {
            var n = e.style,
                i = e.currentStyle,
                r = Z.isNumeric(t) ? "alpha(opacity=" + 100 * t + ")" : "",
                s = i && i.filter || n.filter || "";
            n.zoom = 1, t >= 1 && "" === Z.trim(s.replace(st, "")) && n.removeAttribute && (n.removeAttribute("filter"), i && !i.filter) || (n.filter = st.test(s) ? s.replace(st, r) : s + " " + r)
        }
    }), Z(function () {
        Z.support.reliableMarginRight || (Z.cssHooks.marginRight = {
            get: function (e, t) {
                return Z.swap(e, {
                    display: "inline-block"
                }, function () {
                    return t ? nt(e, "marginRight") : void 0
                })
            }
        }), !Z.support.pixelPosition && Z.fn.position && Z.each(["top", "left"], function (e, t) {
            Z.cssHooks[t] = {
                get: function (e, n) {
                    if (n) {
                        var i = nt(e, t);
                        return dt.test(i) ? Z(e).position()[t] + "px" : i
                    }
                }
            }
        })
    }), Z.expr && Z.expr.filters && (Z.expr.filters.hidden = function (e) {
        return 0 === e.offsetWidth && 0 === e.offsetHeight || !Z.support.reliableHiddenOffsets && "none" === (e.style && e.style.display || nt(e, "display"))
    }, Z.expr.filters.visible = function (e) {
        return !Z.expr.filters.hidden(e)
    }), Z.each({
        margin: "",
        padding: "",
        border: "Width"
    }, function (e, t) {
        Z.cssHooks[e + t] = {
            expand: function (n) {
                var i, r = "string" == typeof n ? n.split(" ") : [n],
                    s = {};
                for (i = 0; 4 > i; i++) s[e + mt[i] + t] = r[i] || r[i - 2] || r[0];
                return s
            }
        }, ut.test(e) || (Z.cssHooks[e + t].set = A)
    });
    var At = /%20/g,
        wt = /\[\]$/,
        Et = /\r?\n/g,
        bt = /^(?:color|date|datetime|datetime-local|email|hidden|month|number|password|range|search|tel|text|time|url|week)$/i,
        xt = /^(?:select|textarea)/i;
    Z.fn.extend({
        serialize: function () {
            return Z.param(this.serializeArray())
        },
        serializeArray: function () {
            return this.map(function () {
                return this.elements ? Z.makeArray(this.elements) : this
            }).filter(function () {
                return this.name && !this.disabled && (this.checked || xt.test(this.nodeName) || bt.test(this.type))
            }).map(function (e, t) {
                var n = Z(this).val();
                return null == n ? null : Z.isArray(n) ? Z.map(n, function (e) {
                    return {
                        name: t.name,
                        value: e.replace(Et, "\r\n")
                    }
                }) : {
                        name: t.name,
                        value: n.replace(Et, "\r\n")
                    }
            }).get()
        }
    }), Z.param = function (e, n) {
        var i, r = [],
            s = function (e, t) {
                t = Z.isFunction(t) ? t() : null == t ? "" : t, r[r.length] = encodeURIComponent(e) + "=" + encodeURIComponent(t)
            };
        if (n === t && (n = Z.ajaxSettings && Z.ajaxSettings.traditional), Z.isArray(e) || e.jquery && !Z.isPlainObject(e)) Z.each(e, function () {
            s(this.name, this.value)
        });
        else
            for (i in e) x(i, e[i], n, s);
        return r.join("&").replace(At, "+")
    };
    var _t, kt, Lt = /#.*$/,
        It = /^(.*?):[ \t]*([^\r\n]*)\r?$/gm,
        St = /^(?:about|app|app\-storage|.+\-extension|file|res|widget):$/,
        jt = /^(?:GET|HEAD)$/,
        Nt = /^\/\//,
        Rt = /\?/,
        Tt = /<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi,
        Pt = /([?&])_=[^&]*/,
        Ct = /^([\w\+\.\-]+:)(?:\/\/([^\/?#:]*)(?::(\d+)|)|)/,
        Dt = Z.fn.load,
        Mt = {},
        Ot = {},
        Bt = ["*/"] + ["*"];
    try {
        kt = G.href
    } catch (Ft) {
        kt = W.createElement("a"), kt.href = "", kt = kt.href
    }
    _t = Ct.exec(kt.toLowerCase()) || [], Z.fn.load = function (e, n, i) {
        if ("string" != typeof e && Dt) return Dt.apply(this, arguments);
        if (!this.length) return this;
        var r, s, o, a = this,
            l = e.indexOf(" ");
        return l >= 0 && (r = e.slice(l, e.length), e = e.slice(0, l)), Z.isFunction(n) ? (i = n, n = t) : n && "object" == typeof n && (s = "POST"), Z.ajax({
            url: e,
            type: s,
            dataType: "html",
            data: n,
            complete: function (e, t) {
                i && a.each(i, o || [e.responseText, t, e])
            }
        }).done(function (e) {
            o = arguments, a.html(r ? Z("<div>").append(e.replace(Tt, "")).find(r) : e)
        }), this
    }, Z.each("ajaxStart ajaxStop ajaxComplete ajaxError ajaxSuccess ajaxSend".split(" "), function (e, t) {
        Z.fn[t] = function (e) {
            return this.on(t, e)
        }
    }), Z.each(["get", "post"], function (e, n) {
        Z[n] = function (e, i, r, s) {
            return Z.isFunction(i) && (s = s || r, r = i, i = t), Z.ajax({
                type: n,
                url: e,
                data: i,
                success: r,
                dataType: s
            })
        }
    }), Z.extend({
        getScript: function (e, n) {
            return Z.get(e, t, n, "script")
        },
        getJSON: function (e, t, n) {
            return Z.get(e, t, n, "json")
        },
        ajaxSetup: function (e, t) {
            return t ? L(e, Z.ajaxSettings) : (t = e, e = Z.ajaxSettings), L(e, t), e
        },
        ajaxSettings: {
            url: kt,
            isLocal: St.test(_t[1]),
            global: !0,
            type: "GET",
            contentType: "application/x-www-form-urlencoded; charset=UTF-8",
            processData: !0,
            async: !0,
            accepts: {
                xml: "application/xml, text/xml",
                html: "text/html",
                text: "text/plain",
                json: "application/json, text/javascript",
                "*": Bt
            },
            contents: {
                xml: /xml/,
                html: /html/,
                json: /json/
            },
            responseFields: {
                xml: "responseXML",
                text: "responseText"
            },
            converters: {
                "* text": e.String,
                "text html": !0,
                "text json": Z.parseJSON,
                "text xml": Z.parseXML
            },
            flatOptions: {
                context: !0,
                url: !0
            }
        },
        ajaxPrefilter: _(Mt),
        ajaxTransport: _(Ot),
        ajax: function (e, n) {
            function i(e, n, i, o) {
                var u, d, v, A, E, x = n;
                2 !== w && (w = 2, l && clearTimeout(l), a = t, s = o || "", b.readyState = e > 0 ? 4 : 0, i && (A = I(p, b, i)), e >= 200 && 300 > e || 304 === e ? (p.ifModified && (E = b.getResponseHeader("Last-Modified"), E && (Z.lastModified[r] = E), E = b.getResponseHeader("Etag"), E && (Z.etag[r] = E)), 304 === e ? (x = "notmodified", u = !0) : (u = S(p, A), x = u.state, d = u.data, v = u.error, u = !v)) : (v = x, x && !e || (x = "error", 0 > e && (e = 0))), b.status = e, b.statusText = (n || x) + "", u ? g.resolveWith(f, [d, x, b]) : g.rejectWith(f, [b, x, v]), b.statusCode(y), y = t, c && h.trigger("ajax" + (u ? "Success" : "Error"), [b, p, u ? d : v]), m.fireWith(f, [b, x]), c && (h.trigger("ajaxComplete", [b, p]), --Z.active || Z.event.trigger("ajaxStop")))
            }
            "object" == typeof e && (n = e, e = t), n = n || {};
            var r, s, o, a, l, u, c, d, p = Z.ajaxSetup({}, n),
                f = p.context || p,
                h = f !== p && (f.nodeType || f instanceof Z) ? Z(f) : Z.event,
                g = Z.Deferred(),
                m = Z.Callbacks("once memory"),
                y = p.statusCode || {},
                v = {},
                A = {},
                w = 0,
                E = "canceled",
                b = {
                    readyState: 0,
                    setRequestHeader: function (e, t) {
                        if (!w) {
                            var n = e.toLowerCase();
                            e = A[n] = A[n] || e, v[e] = t
                        }
                        return this
                    },
                    getAllResponseHeaders: function () {
                        return 2 === w ? s : null
                    },
                    getResponseHeader: function (e) {
                        var n;
                        if (2 === w) {
                            if (!o)
                                for (o = {}; n = It.exec(s);) o[n[1].toLowerCase()] = n[2];
                            n = o[e.toLowerCase()]
                        }
                        return n === t ? null : n
                    },
                    overrideMimeType: function (e) {
                        return w || (p.mimeType = e), this
                    },
                    abort: function (e) {
                        return e = e || E, a && a.abort(e), i(0, e), this
                    }
                };
            if (g.promise(b), b.success = b.done, b.error = b.fail, b.complete = m.add, b.statusCode = function (e) {
                if (e) {
                    var t;
                    if (2 > w)
                        for (t in e) y[t] = [y[t], e[t]];
                    else t = e[b.status], b.always(t)
                }
                return this
            }, p.url = ((e || p.url) + "").replace(Lt, "").replace(Nt, _t[1] + "//"), p.dataTypes = Z.trim(p.dataType || "*").toLowerCase().split(te), null == p.crossDomain && (u = Ct.exec(p.url.toLowerCase()) || !1, p.crossDomain = u && u.join(":") + (u[3] ? "" : "http:" === u[1] ? 80 : 443) !== _t.join(":") + (_t[3] ? "" : "http:" === _t[1] ? 80 : 443)), p.data && p.processData && "string" != typeof p.data && (p.data = Z.param(p.data, p.traditional)), k(Mt, p, n, b), 2 === w) return b;
            if (c = p.global, p.type = p.type.toUpperCase(), p.hasContent = !jt.test(p.type), c && 0 === Z.active++ && Z.event.trigger("ajaxStart"), !p.hasContent && (p.data && (p.url += (Rt.test(p.url) ? "&" : "?") + p.data, delete p.data), r = p.url, p.cache === !1)) {
                var x = Z.now(),
                    _ = p.url.replace(Pt, "$1_=" + x);
                p.url = _ + (_ === p.url ? (Rt.test(p.url) ? "&" : "?") + "_=" + x : "")
            } (p.data && p.hasContent && p.contentType !== !1 || n.contentType) && b.setRequestHeader("Content-Type", p.contentType), p.ifModified && (r = r || p.url, Z.lastModified[r] && b.setRequestHeader("If-Modified-Since", Z.lastModified[r]), Z.etag[r] && b.setRequestHeader("If-None-Match", Z.etag[r])), b.setRequestHeader("Accept", p.dataTypes[0] && p.accepts[p.dataTypes[0]] ? p.accepts[p.dataTypes[0]] + ("*" !== p.dataTypes[0] ? ", " + Bt + "; q=0.01" : "") : p.accepts["*"]);
            for (d in p.headers) b.setRequestHeader(d, p.headers[d]);
            if (!p.beforeSend || p.beforeSend.call(f, b, p) !== !1 && 2 !== w) {
                E = "abort";
                for (d in {
                    success: 1,
                    error: 1,
                    complete: 1
                }) b[d](p[d]);
                if (a = k(Ot, p, n, b)) {
                    b.readyState = 1, c && h.trigger("ajaxSend", [b, p]), p.async && p.timeout > 0 && (l = setTimeout(function () {
                        b.abort("timeout")
                    }, p.timeout));
                    try {
                        w = 1, a.send(v, i)
                    } catch (L) {
                        if (!(2 > w)) throw L;
                        i(-1, L)
                    }
                } else i(-1, "No Transport");
                return b
            }
            return b.abort()
        },
        active: 0,
        lastModified: {},
        etag: {}
    });
    var Yt = [],
        Wt = /\?/,
        Gt = /(=)\?(?=&|$)|\?\?/,
        Ut = Z.now();
    Z.ajaxSetup({
        jsonp: "callback",
        jsonpCallback: function () {
            var e = Yt.pop() || Z.expando + "_" + Ut++;
            return this[e] = !0, e
        }
    }), Z.ajaxPrefilter("json jsonp", function (n, i, r) {
        var s, o, a, l = n.data,
            u = n.url,
            c = n.jsonp !== !1,
            d = c && Gt.test(u),
            p = c && !d && "string" == typeof l && !(n.contentType || "").indexOf("application/x-www-form-urlencoded") && Gt.test(l);
        return "jsonp" === n.dataTypes[0] || d || p ? (s = n.jsonpCallback = Z.isFunction(n.jsonpCallback) ? n.jsonpCallback() : n.jsonpCallback, o = e[s], d ? n.url = u.replace(Gt, "$1" + s) : p ? n.data = l.replace(Gt, "$1" + s) : c && (n.url += (Wt.test(u) ? "&" : "?") + n.jsonp + "=" + s), n.converters["script json"] = function () {
            return a || Z.error(s + " was not called"), a[0]
        }, n.dataTypes[0] = "json", e[s] = function () {
            a = arguments
        }, r.always(function () {
            e[s] = o, n[s] && (n.jsonpCallback = i.jsonpCallback, Yt.push(s)), a && Z.isFunction(o) && o(a[0]), a = o = t
        }), "script") : void 0
    }), Z.ajaxSetup({
        accepts: {
            script: "text/javascript, application/javascript, application/ecmascript, application/x-ecmascript"
        },
        contents: {
            script: /javascript|ecmascript/
        },
        converters: {
            "text script": function (e) {
                return Z.globalEval(e), e
            }
        }
    }), Z.ajaxPrefilter("script", function (e) {
        e.cache === t && (e.cache = !1), e.crossDomain && (e.type = "GET", e.global = !1)
    }), Z.ajaxTransport("script", function (e) {
        if (e.crossDomain) {
            var n, i = W.head || W.getElementsByTagName("head")[0] || W.documentElement;
            return {
                send: function (r, s) {
                    n = W.createElement("script"), n.async = "async", e.scriptCharset && (n.charset = e.scriptCharset), n.src = e.url, n.onload = n.onreadystatechange = function (e, r) {
                        (r || !n.readyState || /loaded|complete/.test(n.readyState)) && (n.onload = n.onreadystatechange = null, i && n.parentNode && i.removeChild(n), n = t, r || s(200, "success"))
                    }, i.insertBefore(n, i.firstChild)
                },
                abort: function () {
                    n && n.onload(0, 1)
                }
            }
        }
    });
    var Ht, Jt = e.ActiveXObject ? function () {
        for (var e in Ht) Ht[e](0, 1)
    } : !1,
        Vt = 0;
    Z.ajaxSettings.xhr = e.ActiveXObject ? function () {
        return !this.isLocal && j() || N()
    } : j,
        function (e) {
            Z.extend(Z.support, {
                ajax: !!e,
                cors: !!e && "withCredentials" in e
            })
        }(Z.ajaxSettings.xhr()), Z.support.ajax && Z.ajaxTransport(function (n) {
            if (!n.crossDomain || Z.support.cors) {
                var i;
                return {
                    send: function (r, s) {
                        var o, a, l = n.xhr();
                        if (n.username ? l.open(n.type, n.url, n.async, n.username, n.password) : l.open(n.type, n.url, n.async), n.xhrFields)
                            for (a in n.xhrFields) l[a] = n.xhrFields[a];
                        n.mimeType && l.overrideMimeType && l.overrideMimeType(n.mimeType), !n.crossDomain && !r["X-Requested-With"] && (r["X-Requested-With"] = "XMLHttpRequest");
                        try {
                            for (a in r) l.setRequestHeader(a, r[a])
                        } catch (u) { }
                        l.send(n.hasContent && n.data || null), i = function (e, r) {
                            var a, u, c, d, p;
                            try {
                                if (i && (r || 4 === l.readyState))
                                    if (i = t, o && (l.onreadystatechange = Z.noop, Jt && delete Ht[o]), r) 4 !== l.readyState && l.abort();
                                    else {
                                        a = l.status, c = l.getAllResponseHeaders(), d = {}, p = l.responseXML, p && p.documentElement && (d.xml = p);
                                        try {
                                            d.text = l.responseText
                                        } catch (e) { }
                                        try {
                                            u = l.statusText
                                        } catch (f) {
                                            u = ""
                                        }
                                        a || !n.isLocal || n.crossDomain ? 1223 === a && (a = 204) : a = d.text ? 200 : 404
                                    }
                            } catch (h) {
                                r || s(-1, h)
                            }
                            d && s(a, u, d, c)
                        }, n.async ? 4 === l.readyState ? setTimeout(i, 0) : (o = ++Vt, Jt && (Ht || (Ht = {}, Z(e).unload(Jt)), Ht[o] = i), l.onreadystatechange = i) : i()
                    },
                    abort: function () {
                        i && i(0, 1)
                    }
                }
            }
        });
    var zt, Qt, qt = /^(?:toggle|show|hide)$/,
        Xt = new RegExp("^(?:([-+])=|)(" + $ + ")([a-z%]*)$", "i"),
        Kt = /queueHooks$/,
        Zt = [D],
        $t = {
            "*": [function (e, t) {
                var n, i, r = this.createTween(e, t),
                    s = Xt.exec(t),
                    o = r.cur(),
                    a = +o || 0,
                    l = 1,
                    u = 20;
                if (s) {
                    if (n = +s[2], i = s[3] || (Z.cssNumber[e] ? "" : "px"), "px" !== i && a) {
                        a = Z.css(r.elem, e, !0) || n || 1;
                        do l = l || ".5", a /= l, Z.style(r.elem, e, a + i); while (l !== (l = r.cur() / o) && 1 !== l && --u)
                    }
                    r.unit = i, r.start = a, r.end = s[1] ? a + (s[1] + 1) * n : n
                }
                return r
            }]
        };
    Z.Animation = Z.extend(P, {
        tweener: function (e, t) {
            Z.isFunction(e) ? (t = e, e = ["*"]) : e = e.split(" ");
            for (var n, i = 0, r = e.length; r > i; i++) n = e[i], $t[n] = $t[n] || [], $t[n].unshift(t)
        },
        prefilter: function (e, t) {
            t ? Zt.unshift(e) : Zt.push(e)
        }
    }), Z.Tween = M, M.prototype = {
        constructor: M,
        init: function (e, t, n, i, r, s) {
            this.elem = e, this.prop = n, this.easing = r || "swing", this.options = t, this.start = this.now = this.cur(), this.end = i, this.unit = s || (Z.cssNumber[n] ? "" : "px")
        },
        cur: function () {
            var e = M.propHooks[this.prop];
            return e && e.get ? e.get(this) : M.propHooks._default.get(this)
        },
        run: function (e) {
            var t, n = M.propHooks[this.prop];
            return this.options.duration ? this.pos = t = Z.easing[this.easing](e, this.options.duration * e, 0, 1, this.options.duration) : this.pos = t = e, this.now = (this.end - this.start) * t + this.start, this.options.step && this.options.step.call(this.elem, this.now, this), n && n.set ? n.set(this) : M.propHooks._default.set(this), this
        }
    }, M.prototype.init.prototype = M.prototype, M.propHooks = {
        _default: {
            get: function (e) {
                var t;
                return null == e.elem[e.prop] || e.elem.style && null != e.elem.style[e.prop] ? (t = Z.css(e.elem, e.prop, !1, ""), t && "auto" !== t ? t : 0) : e.elem[e.prop]
            },
            set: function (e) {
                Z.fx.step[e.prop] ? Z.fx.step[e.prop](e) : e.elem.style && (null != e.elem.style[Z.cssProps[e.prop]] || Z.cssHooks[e.prop]) ? Z.style(e.elem, e.prop, e.now + e.unit) : e.elem[e.prop] = e.now
            }
        }
    }, M.propHooks.scrollTop = M.propHooks.scrollLeft = {
        set: function (e) {
            e.elem.nodeType && e.elem.parentNode && (e.elem[e.prop] = e.now)
        }
    }, Z.each(["toggle", "show", "hide"], function (e, t) {
        var n = Z.fn[t];
        Z.fn[t] = function (i, r, s) {
            return null == i || "boolean" == typeof i || !e && Z.isFunction(i) && Z.isFunction(r) ? n.apply(this, arguments) : this.animate(O(t, !0), i, r, s)
        }
    }), Z.fn.extend({
        fadeTo: function (e, t, n, i) {
            return this.filter(y).css("opacity", 0).show().end().animate({
                opacity: t
            }, e, n, i)
        },
        animate: function (e, t, n, i) {
            var r = Z.isEmptyObject(e),
                s = Z.speed(t, n, i),
                o = function () {
                    var t = P(this, Z.extend({}, e), s);
                    r && t.stop(!0)
                };
            return r || s.queue === !1 ? this.each(o) : this.queue(s.queue, o)
        },
        stop: function (e, n, i) {
            var r = function (e) {
                var t = e.stop;
                delete e.stop, t(i)
            };
            return "string" != typeof e && (i = n, n = e, e = t), n && e !== !1 && this.queue(e || "fx", []), this.each(function () {
                var t = !0,
                    n = null != e && e + "queueHooks",
                    s = Z.timers,
                    o = Z._data(this);
                if (n) o[n] && o[n].stop && r(o[n]);
                else
                    for (n in o) o[n] && o[n].stop && Kt.test(n) && r(o[n]);
                for (n = s.length; n--;) s[n].elem === this && (null == e || s[n].queue === e) && (s[n].anim.stop(i), t = !1, s.splice(n, 1));
                (t || !i) && Z.dequeue(this, e)
            })
        }
    }), Z.each({
        slideDown: O("show"),
        slideUp: O("hide"),
        slideToggle: O("toggle"),
        fadeIn: {
            opacity: "show"
        },
        fadeOut: {
            opacity: "hide"
        },
        fadeToggle: {
            opacity: "toggle"
        }
    }, function (e, t) {
        Z.fn[e] = function (e, n, i) {
            return this.animate(t, e, n, i)
        }
    }), Z.speed = function (e, t, n) {
        var i = e && "object" == typeof e ? Z.extend({}, e) : {
            complete: n || !n && t || Z.isFunction(e) && e,
            duration: e,
            easing: n && t || t && !Z.isFunction(t) && t
        };
        return i.duration = Z.fx.off ? 0 : "number" == typeof i.duration ? i.duration : i.duration in Z.fx.speeds ? Z.fx.speeds[i.duration] : Z.fx.speeds._default, null != i.queue && i.queue !== !0 || (i.queue = "fx"), i.old = i.complete, i.complete = function () {
            Z.isFunction(i.old) && i.old.call(this), i.queue && Z.dequeue(this, i.queue)
        }, i
    }, Z.easing = {
        linear: function (e) {
            return e
        },
        swing: function (e) {
            return .5 - Math.cos(e * Math.PI) / 2
        }
    }, Z.timers = [], Z.fx = M.prototype.init, Z.fx.tick = function () {
        for (var e, t = Z.timers, n = 0; n < t.length; n++) e = t[n], !e() && t[n] === e && t.splice(n--, 1);
        t.length || Z.fx.stop()
    }, Z.fx.timer = function (e) {
        e() && Z.timers.push(e) && !Qt && (Qt = setInterval(Z.fx.tick, Z.fx.interval))
    }, Z.fx.interval = 13, Z.fx.stop = function () {
        clearInterval(Qt), Qt = null
    }, Z.fx.speeds = {
        slow: 600,
        fast: 200,
        _default: 400
    }, Z.fx.step = {}, Z.expr && Z.expr.filters && (Z.expr.filters.animated = function (e) {
        return Z.grep(Z.timers, function (t) {
            return e === t.elem
        }).length
    });
    var en = /^(?:body|html)$/i;
    Z.fn.offset = function (e) {
        if (arguments.length) return e === t ? this : this.each(function (t) {
            Z.offset.setOffset(this, e, t)
        });
        var n, i, r, s, o, a, l, u = {
            top: 0,
            left: 0
        },
            c = this[0],
            d = c && c.ownerDocument;
        if (d) return (i = d.body) === c ? Z.offset.bodyOffset(c) : (n = d.documentElement, Z.contains(n, c) ? ("undefined" != typeof c.getBoundingClientRect && (u = c.getBoundingClientRect()), r = B(d), s = n.clientTop || i.clientTop || 0, o = n.clientLeft || i.clientLeft || 0, a = r.pageYOffset || n.scrollTop, l = r.pageXOffset || n.scrollLeft, {
            top: u.top + a - s,
            left: u.left + l - o
        }) : u)
    }, Z.offset = {
        bodyOffset: function (e) {
            var t = e.offsetTop,
                n = e.offsetLeft;
            return Z.support.doesNotIncludeMarginInBodyOffset && (t += parseFloat(Z.css(e, "marginTop")) || 0, n += parseFloat(Z.css(e, "marginLeft")) || 0), {
                top: t,
                left: n
            }
        },
        setOffset: function (e, t, n) {
            var i = Z.css(e, "position");
            "static" === i && (e.style.position = "relative");
            var r, s, o = Z(e),
                a = o.offset(),
                l = Z.css(e, "top"),
                u = Z.css(e, "left"),
                c = ("absolute" === i || "fixed" === i) && Z.inArray("auto", [l, u]) > -1,
                d = {},
                p = {};
            c ? (p = o.position(), r = p.top, s = p.left) : (r = parseFloat(l) || 0, s = parseFloat(u) || 0), Z.isFunction(t) && (t = t.call(e, n, a)), null != t.top && (d.top = t.top - a.top + r), null != t.left && (d.left = t.left - a.left + s), "using" in t ? t.using.call(e, d) : o.css(d)
        }
    }, Z.fn.extend({
        position: function () {
            if (this[0]) {
                var e = this[0],
                    t = this.offsetParent(),
                    n = this.offset(),
                    i = en.test(t[0].nodeName) ? {
                        top: 0,
                        left: 0
                    } : t.offset();
                return n.top -= parseFloat(Z.css(e, "marginTop")) || 0, n.left -= parseFloat(Z.css(e, "marginLeft")) || 0, i.top += parseFloat(Z.css(t[0], "borderTopWidth")) || 0, i.left += parseFloat(Z.css(t[0], "borderLeftWidth")) || 0, {
                    top: n.top - i.top,
                    left: n.left - i.left
                }
            }
        },
        offsetParent: function () {
            return this.map(function () {
                for (var e = this.offsetParent || W.body; e && !en.test(e.nodeName) && "static" === Z.css(e, "position");) e = e.offsetParent;
                return e || W.body
            })
        }
    }), Z.each({
        scrollLeft: "pageXOffset",
        scrollTop: "pageYOffset"
    }, function (e, n) {
        var i = /Y/.test(n);
        Z.fn[e] = function (r) {
            return Z.access(this, function (e, r, s) {
                var o = B(e);
                return s === t ? o ? n in o ? o[n] : o.document.documentElement[r] : e[r] : void (o ? o.scrollTo(i ? Z(o).scrollLeft() : s, i ? s : Z(o).scrollTop()) : e[r] = s)
            }, e, r, arguments.length, null)
        }
    }), Z.each({
        Height: "height",
        Width: "width"
    }, function (e, n) {
        Z.each({
            padding: "inner" + e,
            content: n,
            "": "outer" + e
        }, function (i, r) {
            Z.fn[r] = function (r, s) {
                var o = arguments.length && (i || "boolean" != typeof r),
                    a = i || (r === !0 || s === !0 ? "margin" : "border");
                return Z.access(this, function (n, i, r) {
                    var s;
                    return Z.isWindow(n) ? n.document.documentElement["client" + e] : 9 === n.nodeType ? (s = n.documentElement, Math.max(n.body["scroll" + e], s["scroll" + e], n.body["offset" + e], s["offset" + e], s["client" + e])) : r === t ? Z.css(n, i, r, a) : Z.style(n, i, r, a)
                }, n, o ? r : t, o, null)
            }
        })
    }), e.jQuery = e.$ = Z, "function" == typeof define && define.amd && define.amd.jQuery && define("jquery", [], function () {
        return Z
    })
}(window), "undefined" == typeof jwplayer) {
    var jwplayer = function (e) {
        return jwplayer.api ? jwplayer.api.selectPlayer(e) : void 0
    },
        $jw = jwplayer;
    jwplayer.version = "5.10.2295 (Licensed version)", jwplayer.vid = document.createElement("video"), jwplayer.audio = document.createElement("audio"), jwplayer.source = document.createElement("source"),
        function (e) {
            function t(t) {
                if (e.utils.exists(t)) {
                    var n = t.indexOf("://"),
                        i = t.indexOf("?");
                    return n > 0 && (0 > i || i > n)
                }
            }
            e.utils = function () { }, e.utils.typeOf = function (e) {
                var t = typeof e;
                return "object" === t && (e ? e instanceof Array && (t = "array") : t = "null"), t
            }, e.utils.extend = function () {
                var t = e.utils.extend.arguments;
                if (t.length > 1) {
                    for (var n = 1; n < t.length; n++)
                        for (var i in t[n]) t[0][i] = t[n][i];
                    return t[0]
                }
                return null
            }, e.utils.clone = function () {
                var t, n = e.utils.clone.arguments;
                if (1 == n.length) switch (e.utils.typeOf(n[0])) {
                    case "object":
                        t = {};
                        for (var i in n[0]) t[i] = e.utils.clone(n[0][i]);
                        break;
                    case "array":
                        t = [];
                        for (var i in n[0]) t[i] = e.utils.clone(n[0][i]);
                        break;
                    default:
                        return n[0]
                }
                return t
            }, e.utils.extension = function (e) {
                return e ? (e = e.substring(e.lastIndexOf("/") + 1, e.length), e = e.split("?")[0], e.lastIndexOf(".") > -1 ? e.substr(e.lastIndexOf(".") + 1, e.length).toLowerCase() : void 0) : ""
            }, e.utils.html = function (e, t) {
                e.innerHTML = t
            }, e.utils.wrap = function (e, t) {
                e.parentNode && e.parentNode.replaceChild(t, e), t.appendChild(e)
            }, e.utils.ajax = function (t, n, i) {
                var r;
                r = window.XMLHttpRequest ? new XMLHttpRequest : new ActiveXObject("Microsoft.XMLHTTP"), r.onreadystatechange = function () {
                    if (4 === r.readyState)
                        if (200 === r.status) {
                            if (n) {
                                if (!e.utils.exists(r.responseXML)) try {
                                    if (window.DOMParser) {
                                        var s = (new DOMParser).parseFromString(r.responseText, "text/xml");
                                        s && (r = e.utils.extend({}, r, {
                                            responseXML: s
                                        }))
                                    } else s = new ActiveXObject("Microsoft.XMLDOM"), s.async = "false", s.loadXML(r.responseText), r = e.utils.extend({}, r, {
                                        responseXML: s
                                    })
                                } catch (o) {
                                    i && i(t)
                                }
                                n(r)
                            }
                        } else i && i(t)
                };
                try {
                    r.open("GET", t, !0), r.send(null)
                } catch (s) {
                    i && i(t)
                }
                return r
            }, e.utils.load = function (e, t, n) {
                e.onreadystatechange = function () {
                    4 === e.readyState && (200 === e.status ? t && t() : n && n())
                }
            }, e.utils.find = function (e, t) {
                return e.getElementsByTagName(t)
            }, e.utils.append = function (e, t) {
                e.appendChild(t)
            }, e.utils.isIE = function () {
                return "undefined" != typeof window.ActiveXObject
            }, e.utils.userAgentMatch = function (e) {
                var t = navigator.userAgent.toLowerCase();
                return null !== t.match(e)
            }, e.utils.isIOS = function () {
                return e.utils.userAgentMatch(/iP(hone|ad|od)/i)
            }, e.utils.isIPad = function () {
                return e.utils.userAgentMatch(/iPad/i)
            }, e.utils.isIPod = function () {
                return e.utils.userAgentMatch(/iP(hone|od)/i)
            }, e.utils.isAndroid = function () {
                return e.utils.userAgentMatch(/android/i)
            }, e.utils.isLegacyAndroid = function () {
                return e.utils.userAgentMatch(/android 2.[012]/i)
            }, e.utils.isBlackberry = function () {
                return e.utils.userAgentMatch(/blackberry/i)
            }, e.utils.isMobile = function () {
                return e.utils.userAgentMatch(/(iP(hone|ad|od))|android/i)
            }, e.utils.getFirstPlaylistItemFromConfig = function (e) {
                var t, n = {};
                return t = e.playlist && e.playlist.length ? e.playlist[0] : e, n.file = t.file, n.levels = t.levels, n.streamer = t.streamer, n.playlistfile = t.playlistfile, n.provider = t.provider, n.provider || (n.file && (n.file.toLowerCase().indexOf("youtube.com") > -1 || n.file.toLowerCase().indexOf("youtu.be") > -1) && (n.provider = "youtube"), n.streamer && 0 == n.streamer.toLowerCase().indexOf("rtmp://") && (n.provider = "rtmp"), t.type && (n.provider = t.type.toLowerCase())), "audio" == n.provider && (n.provider = "sound"), n
            }, e.utils.getOuterHTML = function (e) {
                if (e.outerHTML) return e.outerHTML;
                try {
                    return (new XMLSerializer).serializeToString(e)
                } catch (t) {
                    return ""
                }
            }, e.utils.setOuterHTML = function (e, t) {
                if (e.outerHTML) e.outerHTML = t;
                else {
                    var n = document.createElement("div");
                    n.innerHTML = t;
                    var i = document.createRange();
                    i.selectNodeContents(n);
                    var r = i.extractContents();
                    e.parentNode.insertBefore(r, e), e.parentNode.removeChild(e)
                }
            }, e.utils.hasFlash = function () {
                if ("undefined" != typeof navigator.plugins && "undefined" != typeof navigator.plugins["Shockwave Flash"]) return !0;
                if ("undefined" != typeof window.ActiveXObject) try {
                    return new ActiveXObject("ShockwaveFlash.ShockwaveFlash"), !0
                } catch (e) { }
                return !1
            }, e.utils.getPluginName = function (e) {
                return e.lastIndexOf("/") >= 0 && (e = e.substring(e.lastIndexOf("/") + 1, e.length)), e.lastIndexOf("-") >= 0 && (e = e.substring(0, e.lastIndexOf("-"))), e.lastIndexOf(".swf") >= 0 && (e = e.substring(0, e.lastIndexOf(".swf"))), e.lastIndexOf(".js") >= 0 && (e = e.substring(0, e.lastIndexOf(".js"))), e
            }, e.utils.getPluginVersion = function (e) {
                return e.lastIndexOf("-") >= 0 ? e.lastIndexOf(".js") >= 0 ? e.substring(e.lastIndexOf("-") + 1, e.lastIndexOf(".js")) : e.lastIndexOf(".swf") >= 0 ? e.substring(e.lastIndexOf("-") + 1, e.lastIndexOf(".swf")) : e.substring(e.lastIndexOf("-") + 1) : ""
            }, e.utils.getAbsolutePath = function (n, i) {
                if (e.utils.exists(i) || (i = document.location.href), e.utils.exists(n)) {
                    if (t(n)) return n;
                    var r, s = i.substring(0, i.indexOf("://") + 3),
                        o = i.substring(s.length, i.indexOf("/", s.length + 1));
                    if (0 === n.indexOf("/")) r = n.split("/");
                    else {
                        var a = i.split("?")[0];
                        a = a.substring(s.length + o.length + 1, a.lastIndexOf("/")), r = a.split("/").concat(n.split("/"))
                    }
                    for (var l = [], u = 0; u < r.length; u++) r[u] && e.utils.exists(r[u]) && "." != r[u] && (".." == r[u] ? l.pop() : l.push(r[u]));
                    return s + o + "/" + l.join("/")
                }
            }, e.utils.pluginPathType = {
                ABSOLUTE: "ABSOLUTE",
                RELATIVE: "RELATIVE",
                CDN: "CDN"
            }, e.utils.getPluginPathType = function (t) {
                if ("string" == typeof t) {
                    t = t.split("?")[0];
                    var n = t.indexOf("://");
                    if (n > 0) return e.utils.pluginPathType.ABSOLUTE;
                    var i = t.indexOf("/"),
                        r = e.utils.extension(t);
                    return !(0 > n && 0 > i) || r && isNaN(r) ? e.utils.pluginPathType.RELATIVE : e.utils.pluginPathType.CDN
                }
            }, e.utils.mapEmpty = function (e) {
                for (var t in e) return !1;
                return !0
            }, e.utils.mapLength = function (e) {
                var t = 0;
                for (var n in e) t++;
                return t
            }, e.utils.log = function (e, t) {
                "undefined" != typeof console && "undefined" != typeof console.log && (t ? console.log(e, t) : console.log(e))
            }, e.utils.css = function (t, n) {
                if (e.utils.exists(t))
                    for (var i in n) try {
                        if ("undefined" == typeof n[i]) continue;
                        if ("number" == typeof n[i] && "zIndex" != i && "opacity" != i) {
                            if (isNaN(n[i])) continue;
                            i.match(/color/i) ? n[i] = "#" + e.utils.strings.pad(n[i].toString(16), 6) : n[i] = Math.ceil(n[i]) + "px"
                        }
                        t.style[i] = n[i]
                    } catch (r) { }
            }, e.utils.isYouTube = function (e) {
                return e.indexOf("youtube.com") > -1 || e.indexOf("youtu.be") > -1
            }, e.utils.transform = function (t, n, i, r, s) {
                if (e.utils.exists(n) || (n = 1), e.utils.exists(i) || (i = 1), e.utils.exists(r) || (r = 0), e.utils.exists(s) || (s = 0), 1 == n && 1 == i && 0 == r && 0 == s) t.style.webkitTransform = "", t.style.MozTransform = "", t.style.OTransform = "";
                else {
                    var o = "scale(" + n + "," + i + ") translate(" + r + "px," + s + "px)";
                    t.style.webkitTransform = o, t.style.MozTransform = o, t.style.OTransform = o
                }
            }, e.utils.stretch = function (t, n, i, r, s, o) {
                if ("undefined" != typeof i && "undefined" != typeof r && "undefined" != typeof s && "undefined" != typeof o) {
                    var a = i / s,
                        l = r / o,
                        u = !1,
                        c = {};
                    switch (n.parentElement && (n.parentElement.style.overflow = "hidden"), e.utils.transform(n), t.toUpperCase()) {
                        case e.utils.stretching.NONE:
                            c.width = s, c.height = o, c.top = (r - c.height) / 2, c.left = (i - c.width) / 2;
                            break;
                        case e.utils.stretching.UNIFORM:
                            a > l ? (c.width = s * l, c.height = o * l, c.width / i > .95 && (u = !0, a = Math.ceil(100 * i / c.width) / 100, l = 1, c.width = i)) : (c.width = s * a, c.height = o * a, c.height / r > .95 && (u = !0, a = 1, l = Math.ceil(100 * r / c.height) / 100, c.height = r)), c.top = (r - c.height) / 2, c.left = (i - c.width) / 2;
                            break;
                        case e.utils.stretching.FILL:
                            a > l ? (c.width = s * a, c.height = o * a) : (c.width = s * l, c.height = o * l), c.top = (r - c.height) / 2, c.left = (i - c.width) / 2;
                            break;
                        case e.utils.stretching.EXACTFIT:
                            c.width = s, c.height = o;
                            var d = Math.round(s / 2 * (1 - 1 / a)),
                                p = Math.round(o / 2 * (1 - 1 / l));
                            u = !0, c.top = c.left = 0
                    }
                    u && e.utils.transform(n, a, l, d, p), e.utils.css(n, c)
                }
            }, e.utils.stretching = {
                NONE: "NONE",
                FILL: "FILL",
                UNIFORM: "UNIFORM",
                EXACTFIT: "EXACTFIT"
            }, e.utils.deepReplaceKeyName = function (t, n, i) {
                switch (e.utils.typeOf(t)) {
                    case "array":
                        for (var r = 0; r < t.length; r++) t[r] = e.utils.deepReplaceKeyName(t[r], n, i);
                        break;
                    case "object":
                        for (var s in t) {
                            var o, a;
                            if (n instanceof Array && i instanceof Array) {
                                if (n.length != i.length) continue;
                                o = n, a = i
                            } else o = [n], a = [i];
                            for (var l = s, r = 0; r < o.length; r++) l = l.replace(new RegExp(n[r], "g"), i[r]);
                            t[l] = e.utils.deepReplaceKeyName(t[s], n, i), s != l && delete t[s]
                        }
                }
                return t
            }, e.utils.isInArray = function (e, t) {
                if (!(e && e instanceof Array)) return !1;
                for (var n = 0; n < e.length; n++)
                    if (t === e[n]) return !0;
                return !1
            }, e.utils.exists = function (e) {
                switch (typeof e) {
                    case "string":
                        return e.length > 0;
                    case "object":
                        return null !== e;
                    case "undefined":
                        return !1
                }
                return !0
            }, e.utils.empty = function (e) {
                if ("function" == typeof e.hasChildNodes)
                    for (; e.hasChildNodes();) e.removeChild(e.firstChild)
            }, e.utils.parseDimension = function (e) {
                return "string" == typeof e ? "" === e ? 0 : e.lastIndexOf("%") > -1 ? e : parseInt(e.replace("px", ""), 10) : e
            }, e.utils.getDimensions = function (t) {
                return t && t.style ? {
                    x: e.utils.parseDimension(t.style.left),
                    y: e.utils.parseDimension(t.style.top),
                    width: e.utils.parseDimension(t.style.width),
                    height: e.utils.parseDimension(t.style.height)
                } : {}
            }, e.utils.getElementWidth = function (t) {
                return t ? t == document.body ? e.utils.parentNode(t).clientWidth : t.clientWidth > 0 ? t.clientWidth : t.style ? e.utils.parseDimension(t.style.width) : null : null
            }, e.utils.getElementHeight = function (t) {
                return t ? t == document.body ? e.utils.parentNode(t).clientHeight : t.clientHeight > 0 ? t.clientHeight : t.style ? e.utils.parseDimension(t.style.height) : null : null
            }, e.utils.timeFormat = function (e) {
                return str = "00:00", e > 0 && (str = Math.floor(e / 60) < 10 ? "0" + Math.floor(e / 60) + ":" : Math.floor(e / 60) + ":", str += Math.floor(e % 60) < 10 ? "0" + Math.floor(e % 60) : Math.floor(e % 60)), str
            }, e.utils.useNativeFullscreen = function () {
                return navigator && navigator.vendor && 0 == navigator.vendor.indexOf("Apple")
            }, e.utils.parentNode = function (e) {
                return e ? e.parentNode ? e.parentNode : e.parentElement ? e.parentElement : e : document.body
            }, e.utils.getBoundingClientRect = function (e) {
                return "function" == typeof e.getBoundingClientRect ? e.getBoundingClientRect() : {
                    left: e.offsetLeft + document.body.scrollLeft,
                    top: e.offsetTop + document.body.scrollTop,
                    width: e.offsetWidth,
                    height: e.offsetHeight
                }
            }, e.utils.translateEventResponse = function (t, n) {
                var i = e.utils.extend({}, n);
                t != e.api.events.JWPLAYER_FULLSCREEN || i.fullscreen ? "object" == typeof i.data ? (i = e.utils.extend(i, i.data), delete i.data) : "object" == typeof i.metadata && e.utils.deepReplaceKeyName(i.metadata, ["__dot__", "__spc__", "__dsh__"], [".", " ", "-"]) : (i.fullscreen = "true" == i.message, delete i.message);
                var r = ["position", "duration", "offset"];
                for (var s in r) i[r[s]] && (i[r[s]] = Math.round(1e3 * i[r[s]]) / 1e3);
                return i
            }, e.utils.saveCookie = function (e, t) {
                document.cookie = "jwplayer." + e + "=" + t + "; path=/"
            }, e.utils.getCookies = function () {
                for (var e = {}, t = document.cookie.split("; "), n = 0; n < t.length; n++) {
                    var i = t[n].split("=");
                    0 == i[0].indexOf("jwplayer.") && (e[i[0].substring(9, i[0].length)] = i[1])
                }
                return e
            }, e.utils.readCookie = function (t) {
                return e.utils.getCookies()[t]
            }
        }(jwplayer),
        function (e) {
            e.events = function () { }, e.events.COMPLETE = "COMPLETE", e.events.ERROR = "ERROR"
        }(jwplayer),
        function (jwplayer) {
            jwplayer.events.eventdispatcher = function (debug) {
                var _debug = debug,
                    _listeners, _globallisteners;
                this.resetEventListeners = function () {
                    _listeners = {}, _globallisteners = []
                }, this.resetEventListeners(), this.addEventListener = function (type, listener, count) {
                    try {
                        jwplayer.utils.exists(_listeners[type]) || (_listeners[type] = []), "string" == typeof listener && eval("listener = " + listener), _listeners[type].push({
                            listener: listener,
                            count: count
                        })
                    } catch (err) {
                        jwplayer.utils.log("error", err)
                    }
                    return !1
                }, this.removeEventListener = function (e, t) {
                    if (_listeners[e]) {
                        try {
                            for (var n = 0; n < _listeners[e].length; n++)
                                if (_listeners[e][n].listener.toString() == t.toString()) {
                                    _listeners[e].splice(n, 1);
                                    break
                                }
                        } catch (i) {
                            jwplayer.utils.log("error", i)
                        }
                        return !1
                    }
                }, this.addGlobalListener = function (listener, count) {
                    try {
                        "string" == typeof listener && eval("listener = " + listener), _globallisteners.push({
                            listener: listener,
                            count: count
                        })
                    } catch (err) {
                        jwplayer.utils.log("error", err)
                    }
                    return !1
                }, this.removeGlobalListener = function (e) {
                    if (e) {
                        try {
                            for (var t = 0; t < _globallisteners.length; t++)
                                if (_globallisteners[t].listener.toString() == e.toString()) {
                                    _globallisteners.splice(t, 1);
                                    break
                                }
                        } catch (n) {
                            jwplayer.utils.log("error", n)
                        }
                        return !1
                    }
                }, this.sendEvent = function (e, t) {
                    if (jwplayer.utils.exists(t) || (t = {}), _debug && jwplayer.utils.log(e, t), "undefined" != typeof _listeners[e])
                        for (var n = 0; n < _listeners[e].length; n++) {
                            try {
                                _listeners[e][n].listener(t)
                            } catch (i) {
                                jwplayer.utils.log("There was an error while handling a listener: " + i.toString(), _listeners[e][n].listener)
                            }
                            _listeners[e][n] && (1 === _listeners[e][n].count ? delete _listeners[e][n] : _listeners[e][n].count > 0 && (_listeners[e][n].count = _listeners[e][n].count - 1))
                        }
                    for (var r = 0; r < _globallisteners.length; r++) {
                        try {
                            _globallisteners[r].listener(t)
                        } catch (i) {
                            jwplayer.utils.log("There was an error while handling a listener: " + i.toString(), _globallisteners[r].listener)
                        }
                        _globallisteners[r] && (1 === _globallisteners[r].count ? delete _globallisteners[r] : _globallisteners[r].count > 0 && (_globallisteners[r].count = _globallisteners[r].count - 1))
                    }
                }
            }
        }(jwplayer),
        function (e) {
            var t = {};
            e.utils.animations = function () { }, e.utils.animations.transform = function (e, t) {
                e.style.webkitTransform = t, e.style.MozTransform = t, e.style.OTransform = t, e.style.msTransform = t
            }, e.utils.animations.transformOrigin = function (e, t) {
                e.style.webkitTransformOrigin = t, e.style.MozTransformOrigin = t, e.style.OTransformOrigin = t, e.style.msTransformOrigin = t
            }, e.utils.animations.rotate = function (t, n) {
                e.utils.animations.transform(t, ["rotate(", n, "deg)"].join(""))
            }, e.utils.cancelAnimation = function (e) {
                delete t[e.id]
            }, e.utils.fadeTo = function (n, i, r, s, o, a) {
                if ((t[n.id] == a || !e.utils.exists(a)) && n.style.opacity != i) {
                    var l = (new Date).getTime();
                    if (a > l && setTimeout(function () {
                        e.utils.fadeTo(n, i, r, s, 0, a)
                    }, a - l), "none" == n.style.display && (n.style.display = "block"), e.utils.exists(s) || (s = "" === n.style.opacity ? 1 : n.style.opacity), n.style.opacity == i && "" !== n.style.opacity && e.utils.exists(a)) return void (0 === i && (n.style.display = "none"));
                    e.utils.exists(a) || (a = l, t[n.id] = a), e.utils.exists(o) || (o = 0);
                    var u = r > 0 ? (l - a) / (1e3 * r) : 0;
                    u = u > 1 ? 1 : u;
                    var c = i - s,
                        d = s + u * c;
                    return d > 1 ? d = 1 : 0 > d && (d = 0), n.style.opacity = d, o > 0 ? (t[n.id] = a + 1e3 * o, void e.utils.fadeTo(n, i, r, s, 0, t[n.id])) : void setTimeout(function () {
                        e.utils.fadeTo(n, i, r, s, 0, a)
                    }, 10)
                }
            }
        }(jwplayer),
        function (e) {
            e.utils.arrays = function () { }, e.utils.arrays.indexOf = function (e, t) {
                for (var n = 0; n < e.length; n++)
                    if (e[n] == t) return n;
                return -1
            }, e.utils.arrays.remove = function (t, n) {
                var i = e.utils.arrays.indexOf(t, n);
                i > -1 && t.splice(i, 1)
            }
        }(jwplayer),
        function (e) {
            e.utils.extensionmap = {
                "3gp": {
                    html5: "video/3gpp",
                    flash: "video"
                },
                "3gpp": {
                    html5: "video/3gpp"
                },
                "3g2": {
                    html5: "video/3gpp2",
                    flash: "video"
                },
                "3gpp2": {
                    html5: "video/3gpp2"
                },
                flv: {
                    flash: "video"
                },
                f4a: {
                    html5: "audio/mp4"
                },
                f4b: {
                    html5: "audio/mp4",
                    flash: "video"
                },
                f4v: {
                    html5: "video/mp4",
                    flash: "video"
                },
                mov: {
                    html5: "video/quicktime",
                    flash: "video"
                },
                m4a: {
                    html5: "audio/mp4",
                    flash: "video"
                },
                m4b: {
                    html5: "audio/mp4"
                },
                m4p: {
                    html5: "audio/mp4"
                },
                m4v: {
                    html5: "video/mp4",
                    flash: "video"
                },
                mp4: {
                    html5: "video/mp4",
                    flash: "video"
                },
                rbs: {
                    flash: "sound"
                },
                aac: {
                    html5: "audio/aac",
                    flash: "video"
                },
                mp3: {
                    html5: "audio/mp3",
                    flash: "sound"
                },
                ogg: {
                    html5: "audio/ogg"
                },
                oga: {
                    html5: "audio/ogg"
                },
                ogv: {
                    html5: "video/ogg"
                },
                webm: {
                    html5: "video/webm"
                },
                m3u8: {
                    html5: "audio/x-mpegurl"
                },
                gif: {
                    flash: "image"
                },
                jpeg: {
                    flash: "image"
                },
                jpg: {
                    flash: "image"
                },
                swf: {
                    flash: "image"
                },
                png: {
                    flash: "image"
                },
                wav: {
                    html5: "audio/x-wav"
                }
            }
        }(jwplayer),
        function (e) {
            function t(t, n) {
                return e.utils.exists(n) ? e.utils.extend(n, o[t]) : n = o[t], n
            }

            function n(n, i) {
                if (a[n.tagName.toLowerCase()] && !e.utils.exists(i)) return a[n.tagName.toLowerCase()](n);
                i = t("element", i);
                var r = {};
                for (var s in i)
                    if ("length" != s) {
                        var o = n.getAttribute(s);
                        e.utils.exists(o) && (r[i[s]] = o)
                    }
                var l = n.style["#background-color"];
                return l && "transparent" != l && "rgba(0, 0, 0, 0)" != l && (r.screencolor = l), r
            }

            function i(i, s) {
                s = t("media", s);
                var o = [],
                    a = e.utils.selectors("source", i);
                for (var l in a) isNaN(l) || o.push(r(a[l]));
                var u = n(i, s);
                return e.utils.exists(u.file) && (o[0] = {
                    file: u.file
                }), u.levels = o, u
            }

            function r(e, i) {
                i = t("source", i);
                var r = n(e, i);
                return r.width = r.width ? r.width : 0, r.bitrate = r.bitrate ? r.bitrate : 0, r
            }

            function s(e, n) {
                n = t("video", n);
                var r = i(e, n);
                return r
            }
            e.utils.mediaparser = function () { };
            var o = {
                element: {
                    width: "width",
                    height: "height",
                    id: "id",
                    "class": "className",
                    name: "name"
                },
                media: {
                    src: "file",
                    preload: "preload",
                    autoplay: "autostart",
                    loop: "repeat",
                    controls: "controls"
                },
                source: {
                    src: "file",
                    type: "type",
                    media: "media",
                    "data-jw-width": "width",
                    "data-jw-bitrate": "bitrate"
                },
                video: {
                    poster: "image"
                }
            },
                a = {};
            e.utils.mediaparser.parseMedia = function (e) {
                return n(e)
            }, a.media = i, a.audio = i, a.source = r, a.video = s
        }(jwplayer),
        function (e) {
            e.utils.loaderstatus = {
                NEW: "NEW",
                LOADING: "LOADING",
                ERROR: "ERROR",
                COMPLETE: "COMPLETE"
            }, e.utils.scriptloader = function (t) {
                var n = e.utils.loaderstatus.NEW,
                    i = new e.events.eventdispatcher;
                e.utils.extend(this, i), this.load = function () {
                    if (n == e.utils.loaderstatus.NEW) {
                        n = e.utils.loaderstatus.LOADING;
                        var r = document.createElement("script");
                        r.onload = function () {
                            n = e.utils.loaderstatus.COMPLETE, i.sendEvent(e.events.COMPLETE)
                        }, r.onerror = function () {
                            n = e.utils.loaderstatus.ERROR, i.sendEvent(e.events.ERROR)
                        }, r.onreadystatechange = function () {
                            "loaded" != r.readyState && "complete" != r.readyState || (n = e.utils.loaderstatus.COMPLETE, i.sendEvent(e.events.COMPLETE))
                        }, document.getElementsByTagName("head")[0].appendChild(r), r.src = t
                    }
                }, this.getStatus = function () {
                    return n
                }
            }
        }(jwplayer),
        function (e) {
            e.utils.selectors = function (t, n) {
                e.utils.exists(n) || (n = document), t = e.utils.strings.trim(t);
                var i = t.charAt(0);
                if ("#" == i) return n.getElementById(t.substr(1));
                if ("." == i) return n.getElementsByClassName ? n.getElementsByClassName(t.substr(1)) : e.utils.selectors.getElementsByTagAndClass("*", t.substr(1));
                if (t.indexOf(".") > 0) {
                    var r = t.split(".");
                    return e.utils.selectors.getElementsByTagAndClass(r[0], r[1])
                }
                return n.getElementsByTagName(t)
            }, e.utils.selectors.getElementsByTagAndClass = function (t, n, i) {
                var r = [];
                e.utils.exists(i) || (i = document);
                for (var s = i.getElementsByTagName(t), o = 0; o < s.length; o++)
                    if (e.utils.exists(s[o].className))
                        for (var a = s[o].className.split(" "), l = 0; l < a.length; l++) a[l] == n && r.push(s[o]);
                return r
            }
        }(jwplayer),
        function (e) {
            e.utils.strings = function () { }, e.utils.strings.trim = function (e) {
                return e.replace(/^\s*/, "").replace(/\s*$/, "")
            }, e.utils.strings.pad = function (e, t, n) {
                for (n || (n = "0"); e.length < t;) e = n + e;
                return e
            }, e.utils.strings.serialize = function (e) {
                return null == e ? null : "true" == e ? !0 : "false" == e ? !1 : isNaN(Number(e)) || e.length > 5 || 0 == e.length ? e : Number(e)
            }, e.utils.strings.seconds = function (e) {
                e = e.replace(",", ".");
                var t = e.split(":"),
                    n = 0;
                return "s" == e.substr(-1) ? n = Number(e.substr(0, e.length - 1)) : "m" == e.substr(-1) ? n = 60 * Number(e.substr(0, e.length - 1)) : "h" == e.substr(-1) ? n = 3600 * Number(e.substr(0, e.length - 1)) : t.length > 1 ? (n = Number(t[t.length - 1]), n += 60 * Number(t[t.length - 2]), 3 == t.length && (n += 3600 * Number(t[t.length - 3]))) : n = Number(e), n
            }, e.utils.strings.xmlAttribute = function (e, t) {
                for (var n = 0; n < e.attributes.length; n++)
                    if (e.attributes[n].name && e.attributes[n].name.toLowerCase() == t.toLowerCase()) return e.attributes[n].value.toString();
                return ""
            }, e.utils.strings.jsonToString = function (t) {
                var n = n || {};
                if (n && n.stringify) return n.stringify(t);
                var i = typeof t;
                if ("object" == i && null !== t) {
                    var r = [],
                        s = t && t.constructor == Array;
                    for (var o in t) {
                        var a = t[o];
                        switch (typeof a) {
                            case "string":
                                a = '"' + a.replace(/"/g, '\\"') + '"';
                                break;
                            case "object":
                                e.utils.exists(a) && (a = e.utils.strings.jsonToString(a))
                        }
                        s ? "function" != typeof a && r.push(String(a)) : "function" != typeof a && r.push('"' + o + '":' + String(a))
                    }
                    return s ? "[" + String(r) + "]" : "{" + String(r) + "}"
                }
                return "string" != i ? String(t) : void (t = '"' + t.replace(/"/g, '\\"') + '"')
            }
        }(jwplayer),
        function (e) {
            function t(e) {
                var t = ["true", "false", "t", "f"];
                return t.toString().indexOf(e.toLowerCase().replace(" ", "")) >= 0 ? "boolean" : r.test(e) ? "color" : isNaN(parseInt(e, 10)) || parseInt(e, 10).toString().length != e.length ? isNaN(parseFloat(e)) || parseFloat(e).toString().length != e.length ? "string" : "float" : "integer"
            }

            function n(t, n) {
                if (!e.utils.exists(n)) return t;
                switch (n) {
                    case "color":
                        return t.length > 0 ? i(t) : null;
                    case "integer":
                        return parseInt(t, 10);
                    case "float":
                        return parseFloat(t);
                    case "boolean":
                        return "true" == t.toLowerCase() ? !0 : "1" == t
                }
                return t
            }

            function i(e) {
                switch (e.toLowerCase()) {
                    case "blue":
                        return parseInt("0000FF", 16);
                    case "green":
                        return parseInt("00FF00", 16);
                    case "red":
                        return parseInt("FF0000", 16);
                    case "cyan":
                        return parseInt("00FFFF", 16);
                    case "magenta":
                        return parseInt("FF00FF", 16);
                    case "yellow":
                        return parseInt("FFFF00", 16);
                    case "black":
                        return parseInt("000000", 16);
                    case "white":
                        return parseInt("FFFFFF", 16);
                    default:
                        return e = e.replace(/(#|0x)?([0-9A-F]{3,6})$/gi, "$2"), 3 == e.length && (e = e.charAt(0) + e.charAt(0) + e.charAt(1) + e.charAt(1) + e.charAt(2) + e.charAt(2)), parseInt(e, 16)
                }
                return parseInt("000000", 16)
            }
            var r = new RegExp(/^(#|0x)[0-9a-fA-F]{3,6}/);
            e.utils.typechecker = function (i, r) {
                return r = e.utils.exists(r) ? r : t(i), n(i, r)
            }
        }(jwplayer),
        function (e) {
            e.utils.parsers = function () { }, e.utils.parsers.localName = function (e) {
                return e ? e.localName ? e.localName : e.baseName ? e.baseName : "" : ""
            }, e.utils.parsers.textContent = function (e) {
                return e ? e.textContent ? e.textContent : e.text ? e.text : "" : ""
            }
        }(jwplayer),
        function (e) {
            e.utils.parsers.jwparser = function () { }, e.utils.parsers.jwparser.PREFIX = "jwplayer", e.utils.parsers.jwparser.parseEntry = function (t, n) {
                for (var i = 0; i < t.childNodes.length; i++) t.childNodes[i].prefix == e.utils.parsers.jwparser.PREFIX && (n[e.utils.parsers.localName(t.childNodes[i])] = e.utils.strings.serialize(e.utils.parsers.textContent(t.childNodes[i])), "file" == e.utils.parsers.localName(t.childNodes[i]) && n.levels && delete n.levels), !n.file && String(n.link).toLowerCase().indexOf("youtube") > -1 && (n.file = n.link);
                return n
            }, e.utils.parsers.jwparser.getProvider = function (t) {
                if (t.type) return t.type;
                if (t.file.indexOf("youtube.com/w") > -1 || t.file.indexOf("youtube.com/v") > -1 || t.file.indexOf("youtu.be/") > -1) return "youtube";
                if (t.streamer && 0 == t.streamer.indexOf("rtmp")) return "rtmp";
                if (t.streamer && 0 == t.streamer.indexOf("http")) return "http";
                var n = e.utils.strings.extension(t.file);
                return extensions.hasOwnProperty(n) ? extensions[n] : ""
            }
        }(jwplayer),
        function (e) {
            e.utils.parsers.mediaparser = function () { }, e.utils.parsers.mediaparser.PREFIX = "media", e.utils.parsers.mediaparser.parseGroup = function (t, n) {
                for (var i = !1, r = 0; r < t.childNodes.length; r++)
                    if (t.childNodes[r].prefix == e.utils.parsers.mediaparser.PREFIX) {
                        if (!e.utils.parsers.localName(t.childNodes[r])) continue;
                        switch (e.utils.parsers.localName(t.childNodes[r]).toLowerCase()) {
                            case "content":
                                i || (n.file = e.utils.strings.xmlAttribute(t.childNodes[r], "url")), e.utils.strings.xmlAttribute(t.childNodes[r], "duration") && (n.duration = e.utils.strings.seconds(e.utils.strings.xmlAttribute(t.childNodes[r], "duration"))), e.utils.strings.xmlAttribute(t.childNodes[r], "start") && (n.start = e.utils.strings.seconds(e.utils.strings.xmlAttribute(t.childNodes[r], "start"))), t.childNodes[r].childNodes && t.childNodes[r].childNodes.length > 0 && (n = e.utils.parsers.mediaparser.parseGroup(t.childNodes[r], n)), (e.utils.strings.xmlAttribute(t.childNodes[r], "width") || e.utils.strings.xmlAttribute(t.childNodes[r], "bitrate") || e.utils.strings.xmlAttribute(t.childNodes[r], "url")) && (n.levels || (n.levels = []), n.levels.push({
                                    width: e.utils.strings.xmlAttribute(t.childNodes[r], "width"),
                                    bitrate: e.utils.strings.xmlAttribute(t.childNodes[r], "bitrate"),
                                    file: e.utils.strings.xmlAttribute(t.childNodes[r], "url")
                                }));
                                break;
                            case "title":
                                n.title = e.utils.parsers.textContent(t.childNodes[r]);
                                break;
                            case "description":
                                n.description = e.utils.parsers.textContent(t.childNodes[r]);
                                break;
                            case "keywords":
                                n.tags = e.utils.parsers.textContent(t.childNodes[r]);
                                break;
                            case "thumbnail":
                                n.image = e.utils.strings.xmlAttribute(t.childNodes[r], "url");
                                break;
                            case "credit":
                                n.author = e.utils.parsers.textContent(t.childNodes[r]);
                                break;
                            case "player":
                                var s = t.childNodes[r].url;
                                (s.indexOf("youtube.com") >= 0 || s.indexOf("youtu.be") >= 0) && (i = !0, n.file = e.utils.strings.xmlAttribute(t.childNodes[r], "url"));
                                break;
                            case "group":
                                e.utils.parsers.mediaparser.parseGroup(t.childNodes[r], n)
                        }
                    }
                return n
            }
        }(jwplayer),
        function (e) {
            function t(t) {
                for (var n = {}, i = 0; i < t.childNodes.length; i++)
                    if (e.utils.parsers.localName(t.childNodes[i])) switch (e.utils.parsers.localName(t.childNodes[i]).toLowerCase()) {
                        case "enclosure":
                            n.file = e.utils.strings.xmlAttribute(t.childNodes[i], "url");
                            break;
                        case "title":
                            n.title = e.utils.parsers.textContent(t.childNodes[i]);
                            break;
                        case "pubdate":
                            n.date = e.utils.parsers.textContent(t.childNodes[i]);
                            break;
                        case "description":
                            n.description = e.utils.parsers.textContent(t.childNodes[i]);
                            break;
                        case "link":
                            n.link = e.utils.parsers.textContent(t.childNodes[i]);
                            break;
                        case "category":
                            n.tags ? n.tags += e.utils.parsers.textContent(t.childNodes[i]) : n.tags = e.utils.parsers.textContent(t.childNodes[i])
                    }
                return n = e.utils.parsers.mediaparser.parseGroup(t, n), n = e.utils.parsers.jwparser.parseEntry(t, n), new e.html5.playlistitem(n)
            }
            e.utils.parsers.rssparser = function () { }, e.utils.parsers.rssparser.parse = function (n) {
                for (var i = [], r = 0; r < n.childNodes.length; r++)
                    if ("channel" == e.utils.parsers.localName(n.childNodes[r]).toLowerCase())
                        for (var s = 0; s < n.childNodes[r].childNodes.length; s++) "item" == e.utils.parsers.localName(n.childNodes[r].childNodes[s]).toLowerCase() && i.push(t(n.childNodes[r].childNodes[s]));
                return i
            }
        }(jwplayer),
        function (e) {
            var t = {},
                n = {};
            e.plugins = function () { }, e.plugins.loadPlugins = function (i, r) {
                return n[i] = new e.plugins.pluginloader(new e.plugins.model(t), r), n[i]
            }, e.plugins.registerPlugin = function (i, r, s) {
                var o = e.utils.getPluginName(i);
                if (t[o]) t[o].registerPlugin(i, r, s);
                else {
                    e.utils.log("A plugin (" + i + ") was registered with the player that was not loaded. Please check your configuration.");
                    for (var a in n) n[a].pluginFailed()
                }
            }
        }(jwplayer),
        function (e) {
            e.plugins.model = function (t) {
                this.addPlugin = function (n) {
                    var i = e.utils.getPluginName(n);
                    return t[i] || (t[i] = new e.plugins.plugin(n)), t[i]
                }
            }
        }(jwplayer),
        function (e) {
            e.plugins.pluginmodes = {
                FLASH: "FLASH",
                JAVASCRIPT: "JAVASCRIPT",
                HYBRID: "HYBRID"
            }, e.plugins.plugin = function (t) {
                function n() {
                    switch (e.utils.getPluginPathType(t)) {
                        case e.utils.pluginPathType.ABSOLUTE:
                            return t;
                        case e.utils.pluginPathType.RELATIVE:
                            return e.utils.getAbsolutePath(t, window.location.href);
                        case e.utils.pluginPathType.CDN:
                            var n = e.utils.getPluginName(t),
                                i = e.utils.getPluginVersion(t),
                                r = 0 == window.location.href.indexOf("https://") ? l.replace("http://", "https://secure") : l;
                            return r + "/" + e.version.split(".")[0] + "/" + n + "/" + n + ("" !== i ? "-" + i : "") + ".js"
                    }
                }

                function i() {
                    a = setTimeout(function () {
                        u = e.utils.loaderstatus.COMPLETE, c.sendEvent(e.events.COMPLETE)
                    }, 1e3)
                }

                function r() {
                    u = e.utils.loaderstatus.ERROR, c.sendEvent(e.events.ERROR)
                }
                var s, o, a, l = "http://plugins.longtailvideo.com",
                    u = e.utils.loaderstatus.NEW,
                    c = new e.events.eventdispatcher;
                e.utils.extend(this, c), this.load = function () {
                    if (u == e.utils.loaderstatus.NEW) {
                        if (t.lastIndexOf(".swf") > 0) return s = t, u = e.utils.loaderstatus.COMPLETE, void c.sendEvent(e.events.COMPLETE);
                        u = e.utils.loaderstatus.LOADING;
                        var o = new e.utils.scriptloader(n());
                        o.addEventListener(e.events.COMPLETE, i), o.addEventListener(e.events.ERROR, r), o.load()
                    }
                }, this.registerPlugin = function (t, n, i) {
                    a && (clearTimeout(a), a = void 0), n && i ? (s = i, o = n) : "string" == typeof n ? s = n : "function" == typeof n ? o = n : n || i || (s = t), u = e.utils.loaderstatus.COMPLETE, c.sendEvent(e.events.COMPLETE)
                }, this.getStatus = function () {
                    return u
                }, this.getPluginName = function () {
                    return e.utils.getPluginName(t)
                }, this.getFlashPath = function () {
                    if (s) switch (e.utils.getPluginPathType(s)) {
                        case e.utils.pluginPathType.ABSOLUTE:
                            return s;
                        case e.utils.pluginPathType.RELATIVE:
                            return t.lastIndexOf(".swf") > 0 ? e.utils.getAbsolutePath(s, window.location.href) : e.utils.getAbsolutePath(s, n());
                        case e.utils.pluginPathType.CDN:
                            return s.indexOf("-") > -1 ? s + "h" : s + "-h"
                    }
                    return null
                }, this.getJS = function () {
                    return o
                }, this.getPluginmode = function () {
                    return "undefined" != typeof s && "undefined" != typeof o ? e.plugins.pluginmodes.HYBRID : "undefined" != typeof s ? e.plugins.pluginmodes.FLASH : "undefined" != typeof o ? e.plugins.pluginmodes.JAVASCRIPT : void 0
                }, this.getNewInstance = function (e, t, n) {
                    return new o(e, t, n)
                }, this.getURL = function () {
                    return t
                }
            }
        }(jwplayer),
        function (e) {
            e.plugins.pluginloader = function (t, n) {
                function i() {
                    l || (l = !0, o = e.utils.loaderstatus.COMPLETE, u.sendEvent(e.events.COMPLETE))
                }

                function r() {
                    if (!l) {
                        var t = 0;
                        for (plugin in s) {
                            var n = s[plugin].getStatus();
                            n != e.utils.loaderstatus.LOADING && n != e.utils.loaderstatus.NEW || t++
                        }
                        0 == t && i()
                    }
                }
                var s = {},
                    o = e.utils.loaderstatus.NEW,
                    a = !1,
                    l = !1,
                    u = new e.events.eventdispatcher;
                e.utils.extend(this, u), this.setupPlugins = function (e, t, n) {
                    var i = {
                        length: 0,
                        plugins: {}
                    },
                        r = {
                            length: 0,
                            plugins: {}
                        };
                    for (var o in s) {
                        var a = s[o].getPluginName();
                        if (s[o].getFlashPath() && (i.plugins[s[o].getFlashPath()] = t.plugins[o], i.plugins[s[o].getFlashPath()].pluginmode = s[o].getPluginmode(), i.length++), s[o].getJS()) {
                            var l = document.createElement("div");
                            l.id = e.id + "_" + a, l.style.position = "absolute", l.style.zIndex = r.length + 10, r.plugins[a] = s[o].getNewInstance(e, t.plugins[o], l), r.length++ , "undefined" != typeof r.plugins[a].resize && (e.onReady(n(r.plugins[a], l, !0)), e.onResize(n(r.plugins[a], l)))
                        }
                    }
                    return e.plugins = r.plugins, i
                }, this.load = function () {
                    o = e.utils.loaderstatus.LOADING, a = !0;
                    for (var i in n) e.utils.exists(i) && (s[i] = t.addPlugin(i), s[i].addEventListener(e.events.COMPLETE, r), s[i].addEventListener(e.events.ERROR, r));
                    for (i in s) s[i].load();
                    a = !1, r()
                }, this.pluginFailed = function () {
                    i()
                }, this.getStatus = function () {
                    return o
                }
            }
        }(jwplayer),
        function (e) {
            var t = [];
            e.api = function (t) {
                function n(e, t) {
                    return function (n, i, r, s) {
                        if ("flash" == e.renderingMode || "html5" == e.renderingMode) {
                            var o;
                            i ? (g[n] = i, o = "jwplayer('" + e.id + "').callback('" + n + "')") : !i && g[n] && delete g[n], u.jwDockSetButton(n, o, r, s)
                        }
                        return t
                    }
                }

                function i(t) {
                    d = [], e.utils.getOuterHTML(t.container) != f && e.api.destroyPlayer(t.id, f)
                }

                function r(e) {
                    return function (t) {
                        var n = t.newstate,
                            i = t.oldstate;
                        if (n == e) {
                            var r = a[n];
                            if (r)
                                for (var s = 0; s < r.length; s++) "function" == typeof r[s] && r[s].call(this, {
                                    oldstate: i,
                                    newstate: n
                                })
                        }
                    }
                }

                function s(e, t) {
                    return function (n) {
                        if (e == n.component) {
                            var i = l[e][t];
                            if (i)
                                for (var r = 0; r < i.length; r++) "function" == typeof i[r] && i[r].call(this, n)
                        }
                    }
                }
                this.container = t, this.id = t.id;
                var o = {},
                    a = {},
                    l = {},
                    u = void 0,
                    c = !1,
                    d = [],
                    p = void 0,
                    f = e.utils.getOuterHTML(t),
                    h = {},
                    g = {};
                return this.getBuffer = function () {
                    return this.callInternal("jwGetBuffer")
                }, this.getContainer = function () {
                    return this.container
                }, this.getPlugin = function (t) {
                    var i = this,
                        r = {};
                    return "dock" == t ? e.utils.extend(r, {
                        setButton: n(i, r),
                        show: function () {
                            return i.callInternal("jwDockShow"), r
                        },
                        hide: function () {
                            return i.callInternal("jwDockHide"), r
                        },
                        onShow: function (t) {
                            return i.componentListener("dock", e.api.events.JWPLAYER_COMPONENT_SHOW, t), r
                        },
                        onHide: function (t) {
                            return i.componentListener("dock", e.api.events.JWPLAYER_COMPONENT_HIDE, t), r
                        }
                    }) : "controlbar" == t ? e.utils.extend(r, {
                        show: function () {
                            return i.callInternal("jwControlbarShow"), r
                        },
                        hide: function () {
                            return i.callInternal("jwControlbarHide"), r
                        },
                        onShow: function (t) {
                            return i.componentListener("controlbar", e.api.events.JWPLAYER_COMPONENT_SHOW, t), r
                        },
                        onHide: function (t) {
                            return i.componentListener("controlbar", e.api.events.JWPLAYER_COMPONENT_HIDE, t), r
                        }
                    }) : "display" == t ? e.utils.extend(r, {
                        show: function () {
                            return i.callInternal("jwDisplayShow"), r
                        },
                        hide: function () {
                            return i.callInternal("jwDisplayHide"), r
                        },
                        onShow: function (t) {
                            return i.componentListener("display", e.api.events.JWPLAYER_COMPONENT_SHOW, t), r
                        },
                        onHide: function (t) {
                            return i.componentListener("display", e.api.events.JWPLAYER_COMPONENT_HIDE, t), r
                        }
                    }) : this.plugins[t]
                }, this.callback = function (e) {
                    return g[e] ? g[e]() : void 0
                }, this.getDuration = function () {
                    return this.callInternal("jwGetDuration")
                }, this.getFullscreen = function () {
                    return this.callInternal("jwGetFullscreen")
                }, this.getHeight = function () {
                    return this.callInternal("jwGetHeight")
                }, this.getLockState = function () {
                    return this.callInternal("jwGetLockState")
                }, this.getMeta = function () {
                    return this.getItemMeta()
                }, this.getMute = function () {
                    return this.callInternal("jwGetMute")
                }, this.getPlaylist = function () {
                    var t = this.callInternal("jwGetPlaylist");
                    "flash" == this.renderingMode && e.utils.deepReplaceKeyName(t, ["__dot__", "__spc__", "__dsh__"], [".", " ", "-"]);
                    for (var n = 0; n < t.length; n++) e.utils.exists(t[n].index) || (t[n].index = n);
                    return t
                }, this.getPlaylistItem = function (t) {
                    return e.utils.exists(t) || (t = this.getCurrentItem()), this.getPlaylist()[t]
                }, this.getPosition = function () {
                    return this.callInternal("jwGetPosition")
                }, this.getRenderingMode = function () {
                    return this.renderingMode
                }, this.getState = function () {
                    return this.callInternal("jwGetState")
                }, this.getVolume = function () {
                    return this.callInternal("jwGetVolume")
                }, this.getWidth = function () {
                    return this.callInternal("jwGetWidth")
                }, this.setFullscreen = function (t) {
                    return e.utils.exists(t) ? this.callInternal("jwSetFullscreen", t) : this.callInternal("jwSetFullscreen", !this.callInternal("jwGetFullscreen")), this
                }, this.setMute = function (t) {
                    return e.utils.exists(t) ? this.callInternal("jwSetMute", t) : this.callInternal("jwSetMute", !this.callInternal("jwGetMute")), this
                }, this.lock = function () {
                    return this
                }, this.unlock = function () {
                    return this
                }, this.load = function (e) {
                    return this.callInternal("jwLoad", e), this
                }, this.playlistItem = function (e) {
                    return this.callInternal("jwPlaylistItem", e), this
                }, this.playlistPrev = function () {
                    return this.callInternal("jwPlaylistPrev"), this
                }, this.playlistNext = function () {
                    return this.callInternal("jwPlaylistNext"), this
                }, this.resize = function (e, t) {
                    if ("html5" == this.renderingMode) u.jwResize(e, t);
                    else {
                        this.container.width = e, this.container.height = t;
                        var n = document.getElementById(this.id + "_wrapper");
                        n && (n.style.width = e + "px", n.style.height = t + "px")
                    }
                    return this
                }, this.play = function (t) {
                    return "undefined" == typeof t ? (t = this.getState(), t == e.api.events.state.PLAYING || t == e.api.events.state.BUFFERING ? this.callInternal("jwPause") : this.callInternal("jwPlay")) : this.callInternal("jwPlay", t), this
                }, this.pause = function (t) {
                    return "undefined" == typeof t ? (t = this.getState(), t == e.api.events.state.PLAYING || t == e.api.events.state.BUFFERING ? this.callInternal("jwPause") : this.callInternal("jwPlay")) : this.callInternal("jwPause", t), this
                }, this.stop = function () {
                    return this.callInternal("jwStop"), this
                }, this.seek = function (e) {
                    return this.callInternal("jwSeek", e), this
                }, this.setVolume = function (e) {
                    return this.callInternal("jwSetVolume", e), this
                }, this.loadInstream = function (t, n) {
                    return p = new e.api.instream(this, u, t, n)
                }, this.onBufferChange = function (t) {
                    return this.eventListener(e.api.events.JWPLAYER_MEDIA_BUFFER, t)
                }, this.onBufferFull = function (t) {
                    return this.eventListener(e.api.events.JWPLAYER_MEDIA_BUFFER_FULL, t)
                }, this.onError = function (t) {
                    return this.eventListener(e.api.events.JWPLAYER_ERROR, t)
                }, this.onFullscreen = function (t) {
                    return this.eventListener(e.api.events.JWPLAYER_FULLSCREEN, t)
                }, this.onMeta = function (t) {
                    return this.eventListener(e.api.events.JWPLAYER_MEDIA_META, t)
                }, this.onMute = function (t) {
                    return this.eventListener(e.api.events.JWPLAYER_MEDIA_MUTE, t)
                }, this.onPlaylist = function (t) {
                    return this.eventListener(e.api.events.JWPLAYER_PLAYLIST_LOADED, t)
                }, this.onPlaylistItem = function (t) {
                    return this.eventListener(e.api.events.JWPLAYER_PLAYLIST_ITEM, t);
                }, this.onReady = function (t) {
                    return this.eventListener(e.api.events.API_READY, t)
                }, this.onResize = function (t) {
                    return this.eventListener(e.api.events.JWPLAYER_RESIZE, t)
                }, this.onComplete = function (t) {
                    return this.eventListener(e.api.events.JWPLAYER_MEDIA_COMPLETE, t)
                }, this.onSeek = function (t) {
                    return this.eventListener(e.api.events.JWPLAYER_MEDIA_SEEK, t)
                }, this.onTime = function (t) {
                    return this.eventListener(e.api.events.JWPLAYER_MEDIA_TIME, t)
                }, this.onVolume = function (t) {
                    return this.eventListener(e.api.events.JWPLAYER_MEDIA_VOLUME, t)
                }, this.onBeforePlay = function (t) {
                    return this.eventListener(e.api.events.JWPLAYER_MEDIA_BEFOREPLAY, t)
                }, this.onBeforeComplete = function (t) {
                    return this.eventListener(e.api.events.JWPLAYER_MEDIA_BEFORECOMPLETE, t)
                }, this.onBuffer = function (t) {
                    return this.stateListener(e.api.events.state.BUFFERING, t)
                }, this.onPause = function (t) {
                    return this.stateListener(e.api.events.state.PAUSED, t)
                }, this.onPlay = function (t) {
                    return this.stateListener(e.api.events.state.PLAYING, t)
                }, this.onIdle = function (t) {
                    return this.stateListener(e.api.events.state.IDLE, t)
                }, this.remove = function () {
                    if (!c) throw "Cannot call remove() before player is ready";
                    i(this)
                }, this.setup = function (t) {
                    if (e.embed) {
                        var n = this.id;
                        i(this);
                        var r = e(n);
                        return r.config = t, new e.embed(r)
                    }
                    return this
                }, this.registerPlugin = function (t, n, i) {
                    e.plugins.registerPlugin(t, n, i)
                }, this.setPlayer = function (e, t) {
                    u = e, this.renderingMode = t
                }, this.stateListener = function (t, n) {
                    return a[t] || (a[t] = [], this.eventListener(e.api.events.JWPLAYER_PLAYER_STATE, r(t))), a[t].push(n), this
                }, this.detachMedia = function () {
                    return "html5" == this.renderingMode ? this.callInternal("jwDetachMedia") : void 0
                }, this.attachMedia = function () {
                    return "html5" == this.renderingMode ? this.callInternal("jwAttachMedia") : void 0
                }, this.componentListener = function (e, t, n) {
                    return l[e] || (l[e] = {}), l[e][t] || (l[e][t] = [], this.eventListener(t, s(e, t))), l[e][t].push(n), this
                }, this.addInternalListener = function (t, n) {
                    try {
                        t.jwAddEventListener(n, 'function(dat) { jwplayer("' + this.id + '").dispatchEvent("' + n + '", dat); }')
                    } catch (i) {
                        e.utils.log("Could not add internal listener")
                    }
                }, this.eventListener = function (e, t) {
                    return o[e] || (o[e] = [], u && c && this.addInternalListener(u, e)), o[e].push(t), this
                }, this.dispatchEvent = function (e) {
                    if (o[e])
                        for (var t = _utils.translateEventResponse(e, arguments[1]), n = 0; n < o[e].length; n++) "function" == typeof o[e][n] && o[e][n].call(this, t)
                }, this.dispatchInstreamEvent = function (e) {
                    p && p.dispatchEvent(e, arguments)
                }, this.callInternal = function () {
                    if (c) {
                        for (var e = arguments[0], t = [], n = 1; n < arguments.length; n++) t.push(arguments[n]);
                        return "undefined" != typeof u && "function" == typeof u[e] ? 2 == t.length ? u[e](t[0], t[1]) : 1 == t.length ? u[e](t[0]) : u[e]() : null
                    }
                    d.push(arguments)
                }, this.playerReady = function (t) {
                    c = !0, u || this.setPlayer(document.getElementById(t.id)), this.container = document.getElementById(this.id);
                    for (var n in o) this.addInternalListener(u, n);
                    for (this.eventListener(e.api.events.JWPLAYER_PLAYLIST_ITEM, function () {
                        h = {}
                    }), this.eventListener(e.api.events.JWPLAYER_MEDIA_META, function (t) {
                        e.utils.extend(h, t.metadata)
                    }), this.dispatchEvent(e.api.events.API_READY); d.length > 0;) this.callInternal.apply(this, d.shift())
                }, this.getItemMeta = function () {
                    return h
                }, this.getCurrentItem = function () {
                    return this.callInternal("jwGetPlaylistIndex")
                }, this
            }, e.api.selectPlayer = function (t) {
                var n;
                if (e.utils.exists(t) || (t = 0), t.nodeType ? n = t : "string" == typeof t && (n = document.getElementById(t)), n) {
                    var i = e.api.playerById(n.id);
                    return i ? i : e.api.addPlayer(new e.api(n))
                }
                return "number" == typeof t ? e.getPlayers()[t] : null
            }, e.api.events = {
                API_READY: "jwplayerAPIReady",
                JWPLAYER_READY: "jwplayerReady",
                JWPLAYER_FULLSCREEN: "jwplayerFullscreen",
                JWPLAYER_RESIZE: "jwplayerResize",
                JWPLAYER_ERROR: "jwplayerError",
                JWPLAYER_MEDIA_BEFOREPLAY: "jwplayerMediaBeforePlay",
                JWPLAYER_MEDIA_BEFORECOMPLETE: "jwplayerMediaBeforeComplete",
                JWPLAYER_COMPONENT_SHOW: "jwplayerComponentShow",
                JWPLAYER_COMPONENT_HIDE: "jwplayerComponentHide",
                JWPLAYER_MEDIA_BUFFER: "jwplayerMediaBuffer",
                JWPLAYER_MEDIA_BUFFER_FULL: "jwplayerMediaBufferFull",
                JWPLAYER_MEDIA_ERROR: "jwplayerMediaError",
                JWPLAYER_MEDIA_LOADED: "jwplayerMediaLoaded",
                JWPLAYER_MEDIA_COMPLETE: "jwplayerMediaComplete",
                JWPLAYER_MEDIA_SEEK: "jwplayerMediaSeek",
                JWPLAYER_MEDIA_TIME: "jwplayerMediaTime",
                JWPLAYER_MEDIA_VOLUME: "jwplayerMediaVolume",
                JWPLAYER_MEDIA_META: "jwplayerMediaMeta",
                JWPLAYER_MEDIA_MUTE: "jwplayerMediaMute",
                JWPLAYER_PLAYER_STATE: "jwplayerPlayerState",
                JWPLAYER_PLAYLIST_LOADED: "jwplayerPlaylistLoaded",
                JWPLAYER_PLAYLIST_ITEM: "jwplayerPlaylistItem",
                JWPLAYER_INSTREAM_CLICK: "jwplayerInstreamClicked",
                JWPLAYER_INSTREAM_DESTROYED: "jwplayerInstreamDestroyed"
            }, e.api.events.state = {
                BUFFERING: "BUFFERING",
                IDLE: "IDLE",
                PAUSED: "PAUSED",
                PLAYING: "PLAYING"
            }, e.api.playerById = function (e) {
                for (var n = 0; n < t.length; n++)
                    if (t[n].id == e) return t[n];
                return null
            }, e.api.addPlayer = function (e) {
                for (var n = 0; n < t.length; n++)
                    if (t[n] == e) return e;
                return t.push(e), e
            }, e.api.destroyPlayer = function (n, i) {
                for (var r = -1, s = 0; s < t.length; s++) t[s].id != n || (r = s);
                if (r >= 0) {
                    try {
                        t[r].callInternal("jwDestroy")
                    } catch (o) { }
                    var a = document.getElementById(t[r].id);
                    if (document.getElementById(t[r].id + "_wrapper") && (a = document.getElementById(t[r].id + "_wrapper")), a)
                        if (i) e.utils.setOuterHTML(a, i);
                        else {
                            var l = document.createElement("div"),
                                u = a.id;
                            a.id.indexOf("_wrapper") == a.id.length - 8 && (newID = a.id.substring(0, a.id.length - 8)), l.setAttribute("id", u), a.parentNode.replaceChild(l, a)
                        }
                    t.splice(r, 1)
                }
                return null
            }, e.getPlayers = function () {
                return t.slice(0)
            }
        }(jwplayer);
    var _userPlayerReady = "function" == typeof playerReady ? playerReady : void 0;
    playerReady = function (e) {
        var t = jwplayer.api.playerById(e.id);
        t ? t.playerReady(e) : jwplayer.api.selectPlayer(e.id).playerReady(e), _userPlayerReady && _userPlayerReady.call(this, e)
    },
        function (e) {
            e.api.instream = function (t, n, i, r) {
                function s() {
                    c.callInternal("jwLoadInstream", i, r)
                }

                function o(e, t) {
                    d.jwInstreamAddEventListener(t, 'function(dat) { jwplayer("' + c.id + '").dispatchInstreamEvent("' + t + '", dat); }')
                }

                function a(e, t) {
                    return p[e] || (p[e] = [], o(d, e)), p[e].push(t), this
                }

                function l(t, n) {
                    return f[t] || (f[t] = [], a(e.api.events.JWPLAYER_PLAYER_STATE, u(t))), f[t].push(n), this
                }

                function u(e) {
                    return function (t) {
                        var n = t.newstate,
                            i = t.oldstate;
                        if (n == e) {
                            var r = f[n];
                            if (r)
                                for (var s = 0; s < r.length; s++) "function" == typeof r[s] && r[s].call(this, {
                                    oldstate: i,
                                    newstate: n,
                                    type: t.type
                                })
                        }
                    }
                }
                var c = t,
                    d = n,
                    p = {},
                    f = {};
                this.dispatchEvent = function (e, t) {
                    if (p[e])
                        for (var n = _utils.translateEventResponse(e, t[1]), i = 0; i < p[e].length; i++) "function" == typeof p[e][i] && p[e][i].call(this, n)
                }, this.onError = function (t) {
                    return a(e.api.events.JWPLAYER_ERROR, t)
                }, this.onFullscreen = function (t) {
                    return a(e.api.events.JWPLAYER_FULLSCREEN, t)
                }, this.onMeta = function (t) {
                    return a(e.api.events.JWPLAYER_MEDIA_META, t)
                }, this.onMute = function (t) {
                    return a(e.api.events.JWPLAYER_MEDIA_MUTE, t)
                }, this.onComplete = function (t) {
                    return a(e.api.events.JWPLAYER_MEDIA_COMPLETE, t)
                }, this.onSeek = function (t) {
                    return a(e.api.events.JWPLAYER_MEDIA_SEEK, t)
                }, this.onTime = function (t) {
                    return a(e.api.events.JWPLAYER_MEDIA_TIME, t)
                }, this.onVolume = function (t) {
                    return a(e.api.events.JWPLAYER_MEDIA_VOLUME, t)
                }, this.onBuffer = function (t) {
                    return l(e.api.events.state.BUFFERING, t)
                }, this.onPause = function (t) {
                    return l(e.api.events.state.PAUSED, t)
                }, this.onPlay = function (t) {
                    return l(e.api.events.state.PLAYING, t)
                }, this.onIdle = function (t) {
                    return l(e.api.events.state.IDLE, t)
                }, this.onInstreamClick = function (t) {
                    return a(e.api.events.JWPLAYER_INSTREAM_CLICK, t)
                }, this.onInstreamDestroyed = function (t) {
                    return a(e.api.events.JWPLAYER_INSTREAM_DESTROYED, t)
                }, this.play = function (e) {
                    d.jwInstreamPlay(e)
                }, this.pause = function (e) {
                    d.jwInstreamPause(e)
                }, this.seek = function (e) {
                    d.jwInstreamSeek(e)
                }, this.destroy = function () {
                    d.jwInstreamDestroy()
                }, this.getState = function () {
                    return d.jwInstreamGetState()
                }, this.getDuration = function () {
                    return d.jwInstreamGetDuration()
                }, this.getPosition = function () {
                    return d.jwInstreamGetPosition()
                }, s()
            }
        }(jwplayer),
        function (e) {
            function t() {
                if (!document.body) return setTimeout(t, 15);
                for (var i = n.selectors.getElementsByTagAndClass("video", "jwplayer"), r = 0; r < i.length; r++) {
                    var s = i[r];
                    "" == s.id && (s.id = "jwplayer_" + Math.round(1e5 * Math.random())), e(s.id).setup({})
                }
            }
            var n = e.utils;
            e.embed = function (t) {
                function i(e, t) {
                    for (var n in t) "function" == typeof e[n] && e[n].call(e, t[n])
                }

                function r() {
                    if (l.getStatus() == n.loaderstatus.COMPLETE) {
                        for (var r = 0; r < a.modes.length; r++)
                            if (a.modes[r].type && e.embed[a.modes[r].type]) {
                                var s = a.modes[r].config,
                                    o = a;
                                if (s) {
                                    o = n.extend(n.clone(a), s);
                                    for (var u = ["file", "levels", "playlist"], c = 0; c < u.length; c++) {
                                        var d = u[c];
                                        if (n.exists(s[d]))
                                            for (var p = 0; p < u.length; p++)
                                                if (p != c) {
                                                    var f = u[p];
                                                    n.exists(o[f]) && !n.exists(s[f]) && delete o[f]
                                                }
                                    }
                                }
                                var h = new e.embed[a.modes[r].type](document.getElementById(t.id), a.modes[r], o, l, t);
                                if (h.supportsConfig()) return h.embed(), i(t, a.events), t
                            }
                        n.log("No suitable players found"), new e.embed.logo(n.extend({
                            hide: !0
                        }, a.components.logo), "none", t.id)
                    }
                }
                var s = {
                    width: 400,
                    height: 300,
                    components: {
                        controlbar: {
                            position: "over"
                        }
                    }
                },
                    o = n.mediaparser.parseMedia(t.container),
                    a = new e.embed.config(n.extend(s, o, t.config), this),
                    l = e.plugins.loadPlugins(t.id, a.plugins);
                return l.addEventListener(e.events.COMPLETE, r), l.addEventListener(e.events.ERROR, r), l.load(), t
            }, t()
        }(jwplayer),
        function (e) {
            function t(e) {
                var t = [{
                    type: "flash",
                    src: e ? e : "/jwplayer/player.swf"
                }, {
                    type: "html5"
                }, {
                    type: "download"
                }];
                return o.isAndroid() && (t[0] = t.splice(1, 1, t[0])[0]), t
            }

            function n(e) {
                var t = !1;
                return t = e instanceof Array || "object" == typeof e && !e.position && !e.size
            }

            function i(e) {
                return "string" == typeof e && (parseInt(e).toString() == e || e.toLowerCase().indexOf("px") > -1) ? parseInt(e) : e
            }

            function r(e) {
                var t = {};
                switch (o.typeOf(e.plugins)) {
                    case "object":
                        for (var n in e.plugins) t[o.getPluginName(n)] = n;
                        break;
                    case "string":
                        for (var i = e.plugins.split(","), r = 0; r < i.length; r++) t[o.getPluginName(i[r])] = i[r]
                }
                return t
            }

            function s(e, t, n, i) {
                "object" != o.typeOf(e[t]) && (e[t] = {});
                var r = e[t][n];
                if ("object" != o.typeOf(r) && (e[t][n] = r = {}), i)
                    if ("plugins" == t) {
                        var s = o.getPluginName(n);
                        r[i] = e[s + "." + i], delete e[s + "." + i]
                    } else r[i] = e[n + "." + i], delete e[n + "." + i]
            }
            var o = e.utils,
                a = {
                    players: "modes",
                    autoplay: "autostart"
                },
                l = ["playlist", "dock", "controlbar", "logo", "display"];
            e.embed.deserialize = function (e) {
                var t = r(e);
                for (var n in t) s(e, "plugins", t[n]);
                for (var i in e)
                    if (i.indexOf(".") > -1) {
                        var a = i.split("."),
                            u = a[0],
                            i = a[1];
                        o.isInArray(l, u) ? s(e, "components", u, i) : t[u] && s(e, "plugins", t[u], i)
                    }
                return e
            }, e.embed.config = function (r) {
                var s, u = o.extend({}, r);
                if (n(u.playlist) && (s = u.playlist, delete u.playlist), u = e.embed.deserialize(u), u.height = i(u.height), u.width = i(u.width), "string" == typeof u.plugins) {
                    var c = u.plugins.split(",");
                    "object" != typeof u.plugins && (u.plugins = {});
                    for (var d = 0; d < c.length; d++) {
                        var p = o.getPluginName(c[d]);
                        "object" == typeof u[p] ? (u.plugins[c[d]] = u[p], delete u[p]) : u.plugins[c[d]] = {}
                    }
                }
                for (var f = 0; f < l.length; f++) {
                    var h = l[f];
                    o.exists(u[h]) && ("object" != typeof u[h] ? (u.components[h] || (u.components[h] = {}), "logo" == h ? u.components[h].file = u[h] : u.components[h].position = u[h], delete u[h]) : (u.components[h] || (u.components[h] = {}), o.extend(u.components[h], u[h]), delete u[h])), "undefined" != typeof u[h + "size"] && (u.components[h] || (u.components[h] = {}), u.components[h].size = u[h + "size"], delete u[h + "size"])
                }
                "undefined" != typeof u.icons && (u.components.display || (u.components.display = {}), u.components.display.icons = u.icons, delete u.icons);
                for (var g in a) u[g] && (u[a[g]] || (u[a[g]] = u[g]), delete u[g]);
                var m;
                return u.flashplayer && !u.modes ? (m = t(u.flashplayer), delete u.flashplayer) : u.modes ? ("string" == typeof u.modes ? m = t(u.modes) : u.modes instanceof Array ? m = u.modes : "object" == typeof u.modes && u.modes.type && (m = [u.modes]), delete u.modes) : m = t(), u.modes = m, s && (u.playlist = s), u
            }
        }(jwplayer),
        function (e) {
            e.embed.download = function (t, n, i, r, s) {
                function o(t, n, i) {
                    if (i) return !1;
                    var r = ["image", "sound", "youtube", "http"];
                    if (n && r.toString().indexOf(n) > -1) return !0;
                    if (!n || n && "video" == n) {
                        var s = e.utils.extension(t);
                        if (s && e.utils.extensionmap[s]) return !0
                    }
                    return !1
                }
                this.embed = function () {
                    function n() {
                        _imageWidth = o.display_image.naturalWidth, _imageHeight = o.display_image.naturalHeight, r()
                    }

                    function r() {
                        e.utils.stretch(e.utils.stretching.UNIFORM, o.display_image, a, l, _imageWidth, _imageHeight)
                    }
                    var o = (e.utils.extend({}, i), {}),
                        a = i.width ? i.width : 480;
                    "number" != typeof a && (a = parseInt(a, 10));
                    var l = i.height ? i.height : 320;
                    "number" != typeof l && (l = parseInt(l, 10));
                    var u, c, d, p = {};
                    i.playlist && i.playlist.length ? (p.file = i.playlist[0].file, c = i.playlist[0].image, p.levels = i.playlist[0].levels) : (p.file = i.file, c = i.image, p.levels = i.levels), p.file ? u = p.file : p.levels && p.levels.length && (u = p.levels[0].file), d = u ? "pointer" : "auto";
                    var f = {
                        display: {
                            style: {
                                cursor: d,
                                width: a,
                                height: l,
                                backgroundColor: "#000",
                                position: "relative",
                                textDecoration: "none",
                                border: "none",
                                display: "block"
                            }
                        },
                        display_icon: {
                            style: {
                                cursor: d,
                                position: "absolute",
                                display: u ? "block" : "none",
                                top: 0,
                                left: 0,
                                border: 0,
                                margin: 0,
                                padding: 0,
                                zIndex: 3,
                                width: 50,
                                height: 50,
                                backgroundImage: "url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADIAAAAyCAYAAAAeP4ixAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAALdJREFUeNrs18ENgjAYhmFouDOCcQJGcARHgE10BDcgTOIosAGwQOuPwaQeuFRi2p/3Sb6EC5L3QCxZBgAAAOCorLW1zMn65TrlkH4NcV7QNcUQt7Gn7KIhxA+qNIR81spOGkL8oFJDyLJRdosqKDDkK+iX5+d7huzwM40xptMQMkjIOeRGo+VkEVvIPfTGIpKASfYIfT9iCHkHrBEzf4gcUQ56aEzuGK/mw0rHpy4AAACAf3kJMACBxjAQNRckhwAAAABJRU5ErkJggg==)"
                            }
                        },
                        display_iconBackground: {
                            style: {
                                cursor: d,
                                position: "absolute",
                                display: u ? "block" : "none",
                                top: (l - 50) / 2,
                                left: (a - 50) / 2,
                                border: 0,
                                width: 50,
                                height: 50,
                                margin: 0,
                                padding: 0,
                                zIndex: 2,
                                backgroundImage: "url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADIAAAAyCAYAAAAeP4ixAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAEpJREFUeNrszwENADAIA7DhX8ENoBMZ5KR10EryckCJiIiIiIiIiIiIiIiIiIiIiIh8GmkRERERERERERERERERERERERGRHSPAAPlXH1phYpYaAAAAAElFTkSuQmCC)"
                            }
                        },
                        display_image: {
                            style: {
                                width: a,
                                height: l,
                                display: c ? "block" : "none",
                                position: "absolute",
                                cursor: d,
                                left: 0,
                                top: 0,
                                margin: 0,
                                padding: 0,
                                textDecoration: "none",
                                zIndex: 1,
                                border: "none"
                            }
                        }
                    },
                        h = function (n, i, r) {
                            var s = document.createElement(n);
                            return r ? s.id = r : s.id = t.id + "_jwplayer_" + i, e.utils.css(s, f[i].style), s
                        };
                    o.display = h("a", "display", t.id), u && o.display.setAttribute("href", e.utils.getAbsolutePath(u)), o.display_image = h("img", "display_image"), o.display_image.setAttribute("alt", "Click to download..."), c && o.display_image.setAttribute("src", e.utils.getAbsolutePath(c)), o.display_icon = h("div", "display_icon"), o.display_iconBackground = h("div", "display_iconBackground"), o.display.appendChild(o.display_image), o.display_iconBackground.appendChild(o.display_icon), o.display.appendChild(o.display_iconBackground), _css = e.utils.css, _hide = function (e) {
                        _css(e, {
                            display: "none"
                        })
                    }, o.display_image.onerror = function () {
                        _hide(o.display_image)
                    }, o.display_image.onload = n, t.parentNode.replaceChild(o.display, t);
                    i.plugins && i.plugins.logo ? i.plugins.logo : {};
                    o.display.appendChild(new e.embed.logo(i.components.logo, "download", t.id)), s.container = document.getElementById(s.id), s.setPlayer(o.display, "download")
                }, this.supportsConfig = function () {
                    if (!i) return !0;
                    var t = e.utils.getFirstPlaylistItemFromConfig(i);
                    if ("undefined" == typeof t.file && "undefined" == typeof t.levels) return !0;
                    if (t.file) return o(t.file, t.provider, t.playlistfile);
                    if (t.levels && t.levels.length)
                        for (var n = 0; n < t.levels.length; n++)
                            if (t.levels[n].file && o(t.levels[n].file, t.provider, t.playlistfile)) return !0
                }
            }
        }(jwplayer),
        function (e) {
            e.embed.flash = function (t, n, i, r, s) {
                function o(e, t, n) {
                    var i = document.createElement("param");
                    i.setAttribute("name", t), i.setAttribute("value", n), e.appendChild(i)
                }

                function a(t, n, i) {
                    return function () {
                        i && document.getElementById(s.id + "_wrapper").appendChild(n);
                        var r = document.getElementById(s.id).getPluginConfig("display");
                        t.resize(r.width, r.height);
                        var o = {
                            left: r.x,
                            top: r.y
                        };
                        e.utils.css(n, o)
                    }
                }

                function l(e, t) {
                    if (e[t]) {
                        var n = e[t];
                        for (var i in n) {
                            var r = n[i];
                            if ("string" == typeof r) e[i] || (e[i] = r);
                            else
                                for (var s in r) e[i + "." + s] || (e[i + "." + s] = r[s])
                        }
                        delete e[t]
                    }
                }

                function u(t) {
                    if (!t) return {};
                    var n = {},
                        i = [];
                    for (var r in t) {
                        var s = e.utils.getPluginName(r),
                            o = t[r];
                        i.push(r);
                        for (var a in o) n[s + "." + a] = o[a]
                    }
                    return n.plugins = i.join(","), n
                }

                function c(t) {
                    var n = t.netstreambasepath ? "" : "netstreambasepath=" + encodeURIComponent(window.location.href.split("#")[0]) + "&";
                    for (var i in t) n += "object" == typeof t[i] ? i + "=" + encodeURIComponent("[[JSON]]" + e.utils.strings.jsonToString(t[i])) + "&" : i + "=" + encodeURIComponent(t[i]) + "&";
                    return n.substring(0, n.length - 1)
                }
                this.embed = function () {
                    i.id = s.id;
                    var d, p = e.utils.extend({}, i),
                        f = p.width,
                        h = p.height;
                    t.id + "_wrapper" == t.parentNode.id ? d = document.getElementById(t.id + "_wrapper") : (d = document.createElement("div"), d.id = t.id + "_wrapper", e.utils.wrap(t, d), e.utils.css(d, {
                        position: "relative",
                        width: f,
                        height: h
                    }));
                    var g = r.setupPlugins(s, p, a);
                    g.length > 0 ? e.utils.extend(p, u(g.plugins)) : delete p.plugins;
                    for (var m = ["height", "width", "modes", "events"], y = 0; y < m.length; y++) delete p[m[y]];
                    var v = "opaque";
                    p.wmode && (v = p.wmode), l(p, "components"), l(p, "providers"), "undefined" != typeof p["dock.position"] && "false" == p["dock.position"].toString().toLowerCase() && (p.dock = p["dock.position"], delete p["dock.position"]);
                    var A = e.utils.getCookies();
                    for (var w in A) "undefined" == typeof p[w] && (p[w] = A[w]);
                    var E, b = "#000000";
                    if (e.utils.isIE()) {
                        var x = '<object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" bgcolor="' + b + '" width="100%" height="100%" id="' + t.id + '" name="' + t.id + '" tabindex=0"">';
                        x += '<param name="movie" value="' + n.src + '">', x += '<param name="allowfullscreen" value="true">', x += '<param name="allowscriptaccess" value="always">', x += '<param name="seamlesstabbing" value="true">', x += '<param name="wmode" value="' + v + '">', x += '<param name="flashvars" value="' + c(p) + '">', x += "</object>", e.utils.setOuterHTML(t, x), E = document.getElementById(t.id)
                    } else {
                        var _ = document.createElement("object");
                        _.setAttribute("type", "application/x-shockwave-flash"), _.setAttribute("data", n.src), _.setAttribute("width", "100%"), _.setAttribute("height", "100%"), _.setAttribute("bgcolor", "#000000"), _.setAttribute("id", t.id), _.setAttribute("name", t.id), _.setAttribute("tabindex", 0), o(_, "allowfullscreen", "true"), o(_, "allowscriptaccess", "always"), o(_, "seamlesstabbing", "true"), o(_, "wmode", v), o(_, "flashvars", c(p)), t.parentNode.replaceChild(_, t), E = _
                    }
                    s.container = E, s.setPlayer(E, "flash")
                }, this.supportsConfig = function () {
                    if (e.utils.hasFlash()) {
                        if (!i) return !0;
                        var t = e.utils.getFirstPlaylistItemFromConfig(i);
                        if ("undefined" == typeof t.file && "undefined" == typeof t.levels) return !0;
                        if (t.file) return flashCanPlay(t.file, t.provider);
                        if (t.levels && t.levels.length)
                            for (var n = 0; n < t.levels.length; n++)
                                if (t.levels[n].file && flashCanPlay(t.levels[n].file, t.provider)) return !0
                    }
                    return !1
                }, flashCanPlay = function (t, n) {
                    var i = ["video", "http", "sound", "image"];
                    if (n && i.toString().indexOf(n) < 0) return !0;
                    var r = e.utils.extension(t);
                    return r ? !e.utils.exists(e.utils.extensionmap[r]) || e.utils.exists(e.utils.extensionmap[r].flash) : !0
                }
            }
        }(jwplayer),
        function (e) {
            e.embed.html5 = function (t, n, i, r, s) {
                function o(e, n, i) {
                    return function () {
                        var r = document.getElementById(t.id + "_displayarea");
                        i && r.appendChild(n), e.resize(r.clientWidth, r.clientHeight), n.left = r.style.left, n.top = r.style.top
                    }
                }
                this.embed = function () {
                    if (!e.html5) return null;
                    r.setupPlugins(s, i, o), t.innerHTML = "";
                    for (var n = e.utils.extend({
                        screencolor: "0x000000"
                    }, i), a = ["plugins", "modes", "events"], l = 0; l < a.length; l++) delete n[a[l]];
                    n.levels && !n.sources && (n.sources = i.levels), n.skin && n.skin.toLowerCase().indexOf(".zip") > 0 && (n.skin = n.skin.replace(/\.zip/i, ".xml"));
                    var u = new (e.html5(t).setup)(n);
                    s.container = document.getElementById(s.id), s.setPlayer(u, "html5")
                }, this.supportsConfig = function () {
                    if (e.vid.canPlayType) {
                        if (!i) return !0;
                        var t = e.utils.getFirstPlaylistItemFromConfig(i);
                        if ("undefined" == typeof t.file && "undefined" == typeof t.levels) return !0;
                        if (t.file) return html5CanPlay(e.vid, t.file, t.provider, t.playlistfile);
                        if (t.levels && t.levels.length)
                            for (var n = 0; n < t.levels.length; n++)
                                if (t.levels[n].file && html5CanPlay(e.vid, t.levels[n].file, t.provider, t.playlistfile)) return !0
                    }
                    return !1
                }, html5CanPlay = function (t, n, i, r) {
                    if (r) return !1;
                    if (i && "youtube" == i) return !0;
                    if (i && "video" != i && "http" != i && "sound" != i) return !1;
                    if (null !== navigator.userAgent.match(/BlackBerry/i)) return !1;
                    var s = e.utils.extension(n);
                    return e.utils.exists(s) && e.utils.exists(e.utils.extensionmap[s]) ? e.utils.exists(e.utils.extensionmap[s].html5) ? e.utils.isLegacyAndroid() && s.match(/m4v|mp4/) ? !0 : browserCanPlay(t, e.utils.extensionmap[s].html5) : !1 : !0
                }, browserCanPlay = function (e, t) {
                    return t ? e.canPlayType(t) ? !0 : "audio/mp3" == t && navigator.userAgent.match(/safari/i) ? e.canPlayType("audio/mpeg") : !1 : !0
                }
            }
        }(jwplayer),
        function (e) {
            e.embed.logo = function (t, n, i) {
                function r() {
                    s(), a(), l()
                }

                function s() {
                    if (p.prefix) {
                        var t = e.version.split(/\W/).splice(0, 2).join("/");
                        p.prefix.indexOf(t) < 0 && (p.prefix += t + "/")
                    }
                    h = e.utils.extend({}, p)
                }

                function o() {
                    var e = {
                        border: "none",
                        textDecoration: "none",
                        position: "absolute",
                        cursor: "pointer",
                        zIndex: 10
                    };
                    e.display = h.hide ? "none" : "block";
                    var t = h.position.toLowerCase().split("-");
                    for (var n in t) e[t[n]] = h.margin;
                    return e
                }

                function a() {
                    f = document.createElement("img"), f.id = i + "_jwplayer_logo", f.style.display = "none", f.onload = function () {
                        _css(f, o()), c()
                    }, h.file && (0 === h.file.indexOf("http://") ? f.src = h.file : f.src = h.prefix + h.file)
                }

                function l() {
                    h.link ? (f.onmouseover = d, f.onmouseout = c, f.onclick = u) : this.mouseEnabled = !1
                }

                function u(e) {
                    "undefined" != typeof e && (e.preventDefault(), e.stopPropagation()), h.link && window.open(h.link, h.linktarget)
                }

                function c() {
                    h.link && (f.style.opacity = h.out)
                }

                function d() {
                    h.hide && (f.style.opacity = h.over)
                }
                var p = {
                    prefix: "http://l.longtailvideo.com/" + n + "/",
                    file: "logo.png",
                    link: "http://www.longtailvideo.com/players/jw-flv-player/",
                    linktarget: "_top",
                    margin: 8,
                    out: .5,
                    over: 1,
                    timeout: 5,
                    hide: !1,
                    position: "bottom-left"
                };
                _css = e.utils.css;
                var f, h;
                return r(), h.file ? f : void 0
            }
        }(jwplayer),
        function (e) {
            e.html5 = function (t) {
                var n = t;
                return this.setup = function (t) {
                    return e.utils.extend(this, new e.html5.api(n, t)), this
                }, this
            }
        }(jwplayer),
        function (e) {
            var t = e.utils,
                n = t.css,
                i = t.isIOS();
            e.html5.view = function (r, s, o) {
                function a() {
                    function e() {
                        return R.skin.getComponentSettings("display") && R.skin.getComponentSettings("display").backgroundcolor ? R.skin.getComponentSettings("display").backgroundcolor : parseInt("000000", 16)
                    }
                    w = document.createElement("div"), w.id = T.id, w.className = T.className, _videowrapper = document.createElement("div"), _videowrapper.id = w.id + "_video_wrapper", T.id = w.id + "_video", n(w, {
                        position: "relative",
                        height: P.height,
                        width: P.width,
                        padding: 0,
                        backgroundColor: e(),
                        zIndex: 0
                    }), n(T, {
                        width: "100%",
                        height: "100%",
                        top: 0,
                        left: 0,
                        zIndex: 1,
                        margin: "auto",
                        display: "block"
                    }), n(_videowrapper, {
                        overflow: "hidden",
                        position: "absolute",
                        top: 0,
                        left: 0,
                        bottom: 0,
                        right: 0
                    }), t.wrap(T, w), t.wrap(T, _videowrapper), x = document.createElement("div"), x.id = w.id + "_displayarea", w.appendChild(x), _instreamArea = document.createElement("div"), _instreamArea.id = w.id + "_instreamarea", n(_instreamArea, {
                        overflow: "hidden",
                        position: "absolute",
                        top: 0,
                        left: 0,
                        bottom: 0,
                        right: 0,
                        zIndex: 100,
                        background: "000000",
                        display: "none"
                    }), w.appendChild(_instreamArea)
                }

                function l() {
                    for (var e = 0; e < P.plugins.order.length; e++) {
                        var n = P.plugins.order[e];
                        t.exists(P.plugins.object[n].getDisplayElement) && (P.plugins.object[n].height = t.parseDimension(P.plugins.object[n].getDisplayElement().style.height), P.plugins.object[n].width = t.parseDimension(P.plugins.object[n].getDisplayElement().style.width), P.plugins.config[n].currentPosition = P.plugins.config[n].position)
                    }
                    d()
                }

                function u() {
                    D = P.fullscreen
                }

                function c(t) {
                    if (!j) {
                        switch (t.newstate) {
                            case e.api.events.state.PLAYING:
                                P.getMedia() && P.getMedia().hasChrome() && (x.style.display = "none");
                                break;
                            default:
                                x.style.display = "block"
                        }
                        O()
                    }
                }

                function d() {
                    var e = P.getMedia() ? P.getMedia().getDisplayElement() : null;
                    if (t.exists(e)) {
                        L != e && (L && L.parentNode && L.parentNode.replaceChild(e, L), L = e);
                        for (var n = 0; n < P.plugins.order.length; n++) {
                            var i = P.plugins.order[n];
                            t.exists(P.plugins.object[i].getDisplayElement) && (P.plugins.config[i].currentPosition = P.plugins.config[i].position)
                        }
                    }
                    f(P.width, P.height)
                }

                function p(t) {
                    switch (t.keyCode) {
                        case 27:
                            R.jwGetFullscreen() && R.jwSetFullscreen(!1);
                            break;
                        case 32:
                            R.jwGetState() != e.api.events.state.IDLE && R.jwGetState() != e.api.events.state.PAUSED ? R.jwPause() : R.jwPlay()
                    }
                }

                function f(e, r) {
                    if ("none" != w.style.display) {
                        var s = [].concat(P.plugins.order);
                        if (s.reverse(), _ = s.length + 2, D && A()) try {
                            P.fullscreen && !P.getMedia().getDisplayElement().webkitDisplayingFullscreen && (P.fullscreen = !1)
                        } catch (o) { }
                        if (P.fullscreen) A() || i || h(y, s, !0);
                        else {
                            E = e, b = r, E = "string" == typeof e && e.indexOf("%") > 0 ? t.getElementWidth(t.parentNode(w)) * parseInt(e.replace("%"), "") / 100 : e, b = "string" == typeof r && r.indexOf("%") > 0 ? t.getElementHeight(t.parentNode(w)) * parseInt(r.replace("%"), "") / 100 : r;
                            var a = {
                                top: 0,
                                bottom: 0,
                                left: 0,
                                right: 0,
                                width: E,
                                height: b,
                                position: "absolute"
                            };
                            n(x, a);
                            var l, u = {};
                            try {
                                l = P.plugins.object.display.getDisplayElement()
                            } catch (o) { }
                            l && (u.width = t.parseDimension(l.style.width), u.height = t.parseDimension(l.style.height));
                            var c = t.extend({}, a, u, {
                                zIndex: _instreamArea.style.zIndex,
                                display: _instreamArea.style.display
                            });
                            n(_instreamArea, c), n(w, {
                                height: b,
                                width: E
                            });
                            var d = h(g, s);
                            if (d.length > 0) {
                                _ += d.length;
                                var p = d.indexOf("playlist"),
                                    f = d.indexOf("controlbar");
                                p >= 0 && f >= 0 && (d[p] = d.splice(f, 1, d[p])[0]), h(m, d, !0)
                            }
                            I = t.getElementWidth(x), S = t.getElementHeight(x)
                        }
                        O()
                    }
                }

                function h(i, r, s) {
                    M = 0;
                    for (var o = [], a = 0; a < r.length; a++) {
                        var l = r[a];
                        if (t.exists(P.plugins.object[l].getDisplayElement))
                            if (P.plugins.config[l].currentPosition != e.html5.view.positions.NONE) {
                                var u = i(l, _--);
                                if (u) {
                                    var c = u.width,
                                        d = u.height;
                                    s && (delete u.width, delete u.height), n(P.plugins.object[l].getDisplayElement(), u), P.plugins.object[l].resize(c, d)
                                } else o.push(l)
                            } else n(P.plugins.object[l].getDisplayElement(), {
                                display: "none"
                            })
                    }
                    return o
                }

                function g(e, n) {
                    if (t.exists(P.plugins.object[e].getDisplayElement) && P.plugins.config[e].position && v(P.plugins.config[e].position)) {
                        t.exists(P.plugins.object[e].getDisplayElement().parentNode) || w.appendChild(P.plugins.object[e].getDisplayElement());
                        var i = B(e);
                        return i.zIndex = n, i
                    }
                    return !1
                }

                function m(e, n) {
                    return t.exists(P.plugins.object[e].getDisplayElement().parentNode) || x.appendChild(P.plugins.object[e].getDisplayElement()), {
                        position: "absolute",
                        width: t.getElementWidth(x) - t.parseDimension(x.style.right),
                        height: t.getElementHeight(x) - t.parseDimension(x.style.bottom),
                        zIndex: n
                    }
                }

                function y(e, t) {
                    return {
                        position: "fixed",
                        width: P.width,
                        height: P.height,
                        zIndex: t
                    }
                }

                function v(t) {
                    return [e.html5.view.positions.TOP, e.html5.view.positions.RIGHT, e.html5.view.positions.BOTTOM, e.html5.view.positions.LEFT].toString().indexOf(t.toUpperCase()) > -1
                }

                function A() {
                    return !!(R.jwGetState() != e.api.events.state.IDLE && !C && P.getMedia() && P.getMedia().getDisplayElement() && P.getMedia().getDisplayElement().webkitSupportsFullscreen && t.useNativeFullscreen())
                }
                var w, E, b, x, _, k, L, I, S, j, N, R = r,
                    T = s,
                    P = o,
                    C = !1,
                    D = !1;
                this.setup = function () {
                    P && P.getMedia() && (T = P.getMedia().getDisplayElement()), a(), l(), R.jwAddEventListener(e.api.events.JWPLAYER_PLAYER_STATE, c), R.jwAddEventListener(e.api.events.JWPLAYER_MEDIA_LOADED, d), R.jwAddEventListener(e.api.events.JWPLAYER_MEDIA_BEFOREPLAY, u), R.jwAddEventListener(e.api.events.JWPLAYER_MEDIA_META, function () {
                        O()
                    });
                    var n;
                    t.exists(window.onresize) && (n = window.onresize), window.onresize = function (e) {
                        if (t.exists(n)) try {
                            n(e)
                        } catch (i) { }
                        if (R.jwGetFullscreen()) {
                            if (!A()) {
                                var r = t.getBoundingClientRect(document.body);
                                P.width = Math.abs(r.left) + Math.abs(r.right), P.height = window.innerHeight, f(P.width, P.height)
                            }
                        } else f(P.width, P.height)
                    }
                };
                var M, O = this.resizeMedia = function () {
                    x.style.position = "absolute";
                    var r = P.getMedia() ? P.getMedia().getDisplayElement() : N;
                    if (r)
                        if (r && "video" == r.tagName.toLowerCase()) {
                            if (!r.videoWidth || !r.videoHeight) return r.style.width = x.style.width, void (r.style.height = x.style.height);
                            if (r.style.position = "absolute", t.fadeTo(r, 1, .25), r.parentNode && (r.parentNode.style.left = x.style.left, r.parentNode.style.top = x.style.top), P.fullscreen && R.jwGetStretching() == e.utils.stretching.EXACTFIT && !t.isMobile()) {
                                var s = document.createElement("div");
                                t.stretch(e.utils.stretching.UNIFORM, s, t.getElementWidth(x), t.getElementHeight(x), I, S), t.stretch(e.utils.stretching.EXACTFIT, r, t.parseDimension(s.style.width), t.parseDimension(s.style.height), r.videoWidth ? r.videoWidth : 400, r.videoHeight ? r.videoHeight : 300), n(r, {
                                    left: s.style.left,
                                    top: s.style.top
                                })
                            } else i || t.stretch(R.jwGetStretching(), r, t.getElementWidth(x), t.getElementHeight(x), r.videoWidth ? r.videoWidth : 400, r.videoHeight ? r.videoHeight : 300)
                        } else {
                            var o = P.plugins.object.display.getDisplayElement();
                            o ? P.getMedia().resize(t.parseDimension(o.style.width), t.parseDimension(o.style.height)) : P.getMedia().resize(t.parseDimension(x.style.width), t.parseDimension(x.style.height))
                        }
                },
                    B = this.getComponentPosition = function (n) {
                        var i = {
                            position: "absolute",
                            margin: 0,
                            padding: 0,
                            top: null
                        },
                            r = P.plugins.config[n].currentPosition.toLowerCase();
                        switch (r.toUpperCase()) {
                            case e.html5.view.positions.TOP:
                                i.top = t.parseDimension(x.style.top), i.left = t.parseDimension(x.style.left), i.width = t.getElementWidth(x) - t.parseDimension(x.style.left) - t.parseDimension(x.style.right), i.height = P.plugins.object[n].height, x.style[r] = t.parseDimension(x.style[r]) + P.plugins.object[n].height + "px", x.style.height = t.getElementHeight(x) - i.height + "px";
                                break;
                            case e.html5.view.positions.RIGHT:
                                i.top = t.parseDimension(x.style.top), i.right = t.parseDimension(x.style.right), i.width = P.plugins.object[n].width, i.height = t.getElementHeight(x) - t.parseDimension(x.style.top) - t.parseDimension(x.style.bottom), x.style.width = t.getElementWidth(x) - i.width + "px";
                                break;
                            case e.html5.view.positions.BOTTOM:
                                i.left = t.parseDimension(x.style.left), i.width = t.getElementWidth(x) - t.parseDimension(x.style.left) - t.parseDimension(x.style.right), i.height = P.plugins.object[n].height, i.bottom = t.parseDimension(x.style.bottom + M), M += i.height, x.style.height = t.getElementHeight(x) - i.height + "px";
                                break;
                            case e.html5.view.positions.LEFT:
                                i.top = t.parseDimension(x.style.top), i.left = t.parseDimension(x.style.left), i.width = P.plugins.object[n].width, i.height = t.getElementHeight(x) - t.parseDimension(x.style.top) - t.parseDimension(x.style.bottom), x.style[r] = t.parseDimension(x.style[r]) + P.plugins.object[n].width + "px", x.style.width = t.getElementWidth(x) - i.width + "px"
                        }
                        return i
                    };
                this.resize = f;
                var F, Y, W;
                this.fullscreen = function (e) {
                    if (!i) {
                        var r;
                        try {
                            r = P.getMedia().getDisplayElement()
                        } catch (s) { }
                        e && (Y = P.width, W = P.height);
                        var o = {
                            position: "fixed",
                            width: "100%",
                            height: "100%",
                            top: 0,
                            left: 0,
                            zIndex: 2147483e3
                        },
                            a = {
                                position: "relative",
                                height: Y,
                                width: W,
                                zIndex: 0
                            };
                        if (A() && r && r.webkitSupportsFullscreen) {
                            if (e && !r.webkitDisplayingFullscreen) try {
                                n(r, o), t.transform(r), F = x.style.display, x.style.display = "none", r.webkitEnterFullscreen()
                            } catch (l) { } else if (!e) {
                                if (n(r, a), O(), r.webkitDisplayingFullscreen) try {
                                    r.webkitExitFullscreen()
                                } catch (l) { }
                                x.style.display = F
                            }
                            C = !1
                        } else {
                            if (e) {
                                document.onkeydown = p, clearInterval(k);
                                var u = t.getBoundingClientRect(document.body);
                                P.width = Math.abs(u.left) + Math.abs(u.right), P.height = window.innerHeight, n(w, o), o.zIndex = 1, P.getMedia() && P.getMedia().getDisplayElement() && n(P.getMedia().getDisplayElement(), o), o.zIndex = 2, n(x, o), C = !0
                            } else document.onkeydown = "", P.width = E, P.height = b, n(w, a), C = !1;
                            f(P.width, P.height)
                        }
                    }
                };
                this.setupInstream = function (e, n) {
                    t.css(_instreamArea, {
                        display: "block",
                        position: "absolute"
                    }), x.style.display = "none", _instreamArea.appendChild(e), N = n, j = !0
                };
                this.destroyInstream = function () {
                    _instreamArea.style.display = "none", _instreamArea.innerHTML = "", x.style.display = "block", N = null, j = !1, f(P.width, P.height)
                }
            }, e.html5.view.positions = {
                TOP: "TOP",
                RIGHT: "RIGHT",
                BOTTOM: "BOTTOM",
                LEFT: "LEFT",
                OVER: "OVER",
                NONE: "NONE"
            }
        }(jwplayer),
        function (e) {
            var t = {
                backgroundcolor: "",
                margin: 10,
                font: "Arial,sans-serif",
                fontsize: 10,
                fontcolor: parseInt("000000", 16),
                fontstyle: "normal",
                fontweight: "bold",
                buttoncolor: parseInt("ffffff", 16),
                position: e.html5.view.positions.BOTTOM,
                idlehide: !1,
                hideplaylistcontrols: !1,
                forcenextprev: !1,
                layout: {
                    left: {
                        position: "left",
                        elements: [{
                            name: "play",
                            type: "button"
                        }, {
                            name: "divider",
                            type: "divider"
                        }, {
                            name: "prev",
                            type: "button"
                        }, {
                            name: "divider",
                            type: "divider"
                        }, {
                            name: "next",
                            type: "button"
                        }, {
                            name: "divider",
                            type: "divider"
                        }, {
                            name: "elapsed",
                            type: "text"
                        }]
                    },
                    center: {
                        position: "center",
                        elements: [{
                            name: "time",
                            type: "slider"
                        }]
                    },
                    right: {
                        position: "right",
                        elements: [{
                            name: "duration",
                            type: "text"
                        }, {
                            name: "blank",
                            type: "button"
                        }, {
                            name: "divider",
                            type: "divider"
                        }, {
                            name: "mute",
                            type: "button"
                        }, {
                            name: "volume",
                            type: "slider"
                        }, {
                            name: "divider",
                            type: "divider"
                        }, {
                            name: "fullscreen",
                            type: "button"
                        }]
                    }
                }
            };
            _utils = e.utils, _css = _utils.css, _hide = function (e) {
                _css(e, {
                    display: "none"
                })
            }, _show = function (e) {
                _css(e, {
                    display: "block"
                })
            }, e.html5.controlbar = function (n, i) {
                function r() {
                    return Q || (Q = M.skin.getSkinElement("controlbar", "background"), Q || (Q = {
                        width: 0,
                        height: 0,
                        src: null
                    })), Q
                }

                function s() {
                    if (Y = 0, W = 0, F = 0, !ee) {
                        var e = {
                            height: r().height,
                            backgroundColor: O.backgroundcolor
                        };
                        B = document.createElement("div"), B.id = M.id + "_jwplayer_controlbar", _css(B, e)
                    }
                    var t = M.skin.getSkinElement("controlbar", "capLeft"),
                        n = M.skin.getSkinElement("controlbar", "capRight");
                    t && y("capLeft", "left", !1, B), p("background", B, {
                        position: "absolute",
                        height: r().height,
                        left: t ? t.width : 0,
                        zIndex: 0
                    }, "img"), r().src && ($.background.src = r().src), p("elements", B, {
                        position: "relative",
                        height: r().height,
                        zIndex: 1
                    }), n && y("capRight", "right", !1, B)
                }

                function o() {
                    var e = ["timeSlider", "volumeSlider", "timeSliderRail", "volumeSliderRail"];
                    for (var t in e) {
                        var n = e[t];
                        "undefined" != typeof $[n] && (te[n] = _utils.getBoundingClientRect($[n]))
                    }
                }

                function a(t) {
                    if (!ie)
                        if (clearTimeout(q), O.position == e.html5.view.positions.OVER || M.jwGetFullscreen()) switch (M.jwGetState()) {
                            case e.api.events.state.PAUSED:
                            case e.api.events.state.IDLE:
                                B && B.style.opacity < 1 && (!O.idlehide || _utils.exists(t)) && (ae = !1, setTimeout(function () {
                                    ae || u()
                                }, 100)), O.idlehide && (q = setTimeout(function () {
                                    l()
                                }, 2e3));
                                break;
                            default:
                                ae = !0, t && u(), q = setTimeout(function () {
                                    l()
                                }, 2e3)
                        } else u()
                }

                function l() {
                    ie || (ue(), 1 == B.style.opacity && (_utils.cancelAnimation(B), _utils.fadeTo(B, 0, .1, 1, 0)))
                }

                function u() {
                    ie || (le(), 0 == B.style.opacity && (_utils.cancelAnimation(B), _utils.fadeTo(B, 1, .1, 0, 0)))
                }

                function c(e) {
                    return function () {
                        re && X != e && (X = e, oe.sendEvent(e, {
                            component: "controlbar",
                            boundingRect: d()
                        }))
                    }
                }

                function d() {
                    return O.position == e.html5.view.positions.OVER || M.jwGetFullscreen() ? _utils.getDimensions(B) : {
                        x: 0,
                        y: 0,
                        width: 0,
                        height: 0
                    }
                }

                function p(e, t, n, i) {
                    var r;
                    return ee ? r = document.getElementById(B.id + "_" + e) : (i || (i = "div"), r = document.createElement(i), $[e] = r, r.id = B.id + "_" + e, t.appendChild(r)), _utils.exists(n) && _css(r, n), r
                }

                function f() {
                    if (M.jwGetHeight() <= 40) {
                        O.layout = _utils.clone(O.layout);
                        for (var e = 0; e < O.layout.left.elements.length; e++) "fullscreen" == O.layout.left.elements[e].name && O.layout.left.elements.splice(e, 1);
                        for (e = 0; e < O.layout.right.elements.length; e++) "fullscreen" == O.layout.right.elements[e].name && O.layout.right.elements.splice(e, 1);
                        N()
                    }
                    h(O.layout.left), h(O.layout.center), h(O.layout.right)
                }

                function h(e, t) {
                    var n = "right" == e.position ? "right" : "left",
                        i = _utils.extend([], e.elements);
                    _utils.exists(t) && i.reverse();
                    for (var e = p(e.position + "Group", $.elements, {
                        "float": "left",
                        styleFloat: "left",
                        cssFloat: "left",
                        height: "100%"
                    }), r = 0; r < i.length; r++) m(i[r], n, e)
                }

                function g() {
                    return F++
                }

                function m(e, t, n) {
                    var i, s, o, a, l;
                    if (n || (n = $.elements), "divider" == e.type) return void y("divider" + g(), t, !0, n, void 0, e.width, e.element);
                    switch (e.name) {
                        case "play":
                            y("playButton", t, !1, n), y("pauseButton", t, !0, n), b("playButton", "jwPlay"), b("pauseButton", "jwPause");
                            break;
                        case "prev":
                            y("prevButton", t, !0, n), b("prevButton", "jwPlaylistPrev");
                            break;
                        case "stop":
                            y("stopButton", t, !0, n), b("stopButton", "jwStop");
                            break;
                        case "next":
                            y("nextButton", t, !0, n), b("nextButton", "jwPlaylistNext");
                            break;
                        case "elapsed":
                            y("elapsedText", t, !0, n, null, null, M.skin.getSkinElement("controlbar", "elapsedBackground"));
                            break;
                        case "time":
                            s = _utils.exists(M.skin.getSkinElement("controlbar", "timeSliderCapLeft")) ? M.skin.getSkinElement("controlbar", "timeSliderCapLeft").width : 0, o = _utils.exists(M.skin.getSkinElement("controlbar", "timeSliderCapRight")) ? M.skin.getSkinElement("controlbar", "timeSliderCapRight").width : 0, i = "left" == t ? s : o, l = {
                                height: r().height,
                                position: "relative",
                                "float": "left",
                                styleFloat: "left",
                                cssFloat: "left"
                            };
                            var u = p("timeSlider", n, l);
                            y("timeSliderCapLeft", t, !0, u, "relative"), y("timeSliderRail", t, !1, u, "relative"), y("timeSliderBuffer", t, !1, u, "absolute"), y("timeSliderProgress", t, !1, u, "absolute"), y("timeSliderThumb", t, !1, u, "absolute"), y("timeSliderCapRight", t, !0, u, "relative"), x("time");
                            break;
                        case "fullscreen":
                            y("fullscreenButton", t, !1, n), y("normalscreenButton", t, !0, n), b("fullscreenButton", "jwSetFullscreen", !0), b("normalscreenButton", "jwSetFullscreen", !1);
                            break;
                        case "volume":
                            s = _utils.exists(M.skin.getSkinElement("controlbar", "volumeSliderCapLeft")) ? M.skin.getSkinElement("controlbar", "volumeSliderCapLeft").width : 0, o = _utils.exists(M.skin.getSkinElement("controlbar", "volumeSliderCapRight")) ? M.skin.getSkinElement("controlbar", "volumeSliderCapRight").width : 0, i = "left" == t ? s : o, a = M.skin.getSkinElement("controlbar", "volumeSliderRail").width + s + o, l = {
                                height: r().height,
                                position: "relative",
                                width: a,
                                "float": "left",
                                styleFloat: "left",
                                cssFloat: "left"
                            };
                            var c = p("volumeSlider", n, l);
                            y("volumeSliderCapLeft", t, !1, c, "relative"), y("volumeSliderRail", t, !1, c, "relative"), y("volumeSliderProgress", t, !1, c, "absolute"), y("volumeSliderThumb", t, !1, c, "absolute"), y("volumeSliderCapRight", t, !1, c, "relative"), x("volume");
                            break;
                        case "mute":
                            y("muteButton", t, !1, n), y("unmuteButton", t, !0, n), b("muteButton", "jwSetMute", !0), b("unmuteButton", "jwSetMute", !1);
                            break;
                        case "duration":
                            y("durationText", t, !0, n, null, null, M.skin.getSkinElement("controlbar", "durationBackground"))
                    }
                }

                function y(e, t, n, i, s, o, a) {
                    if (_utils.exists(M.skin.getSkinElement("controlbar", e)) || e.indexOf("Text") > 0 || 0 === e.indexOf("divider")) {
                        var l = {
                            height: "100%",
                            position: s ? s : "relative",
                            display: "block",
                            "float": "left",
                            styleFloat: "left",
                            cssFloat: "left"
                        };
                        0 !== e.indexOf("next") && 0 !== e.indexOf("prev") || !(M.jwGetPlaylist().length < 2 || "true" == O.hideplaylistcontrols.toString()) || "true" != O.forcenextprev.toString() && (n = !1, l.display = "none");
                        var u;
                        if (e.indexOf("Text") > 0) e.innerhtml = "00:00", l.font = O.fontsize + "px/" + (r().height + 1) + "px " + O.font, l.color = O.fontcolor, l.textAlign = "center", l.fontWeight = O.fontweight, l.fontStyle = O.fontstyle, l.cursor = "default", a && (l.background = "url(" + a.src + ") no-repeat center", l.backgroundSize = "100% " + r().height + "px"), l.padding = "0 5px";
                        else if (0 === e.indexOf("divider"))
                            if (o) isNaN(parseInt(o)) || (u = parseInt(o));
                            else if (a) {
                                var c = M.skin.getSkinElement("controlbar", a);
                                c && (l.background = "url(" + c.src + ") repeat-x center left", u = c.width)
                            } else l.background = "url(" + M.skin.getSkinElement("controlbar", "divider").src + ") repeat-x center left", u = M.skin.getSkinElement("controlbar", "divider").width;
                        else l.background = "url(" + M.skin.getSkinElement("controlbar", e).src + ") repeat-x center left", u = M.skin.getSkinElement("controlbar", e).width;
                        if ("left" == t ? n && (Y += u) : "right" == t && n && (W += u), "undefined" == _utils.typeOf(i) && (i = $.elements), l.width = u, ee) _css($[e], l);
                        else {
                            var d = p(e, i, l);
                            _utils.exists(M.skin.getSkinElement("controlbar", e + "Over")) && (d.onmouseover = function () {
                                d.style.backgroundImage = ["url(", M.skin.getSkinElement("controlbar", e + "Over").src, ")"].join("")
                            }, d.onmouseout = function () {
                                d.style.backgroundImage = ["url(", M.skin.getSkinElement("controlbar", e).src, ")"].join("")
                            }), 0 == e.indexOf("divider") && d.setAttribute("class", "divider"), d.innerHTML = "&nbsp;"
                        }
                    }
                }

                function v() {
                    M.jwAddEventListener(e.api.events.JWPLAYER_PLAYLIST_LOADED, A), M.jwAddEventListener(e.api.events.JWPLAYER_PLAYLIST_ITEM, w), M.jwAddEventListener(e.api.events.JWPLAYER_MEDIA_BUFFER, k), M.jwAddEventListener(e.api.events.JWPLAYER_PLAYER_STATE, I), M.jwAddEventListener(e.api.events.JWPLAYER_MEDIA_TIME, j), M.jwAddEventListener(e.api.events.JWPLAYER_MEDIA_MUTE, L), M.jwAddEventListener(e.api.events.JWPLAYER_MEDIA_VOLUME, P), M.jwAddEventListener(e.api.events.JWPLAYER_MEDIA_COMPLETE, S)
                }

                function A() {
                    O.hideplaylistcontrols || (M.jwGetPlaylist().length > 1 || "true" == O.forcenextprev.toString() ? (_show($.nextButton), _show($.prevButton)) : (_hide($.nextButton), _hide($.prevButton)), T(), E())
                }

                function w(e) {
                    H = M.jwGetPlaylist()[e.index].duration, ne = -1, j({
                        id: M.id,
                        duration: H,
                        position: 0
                    }), k({
                        id: M.id,
                        bufferProgress: 0
                    })
                }

                function E() {
                    j({
                        id: M.id,
                        duration: M.jwGetDuration(),
                        position: 0
                    }), k({
                        id: M.id,
                        bufferProgress: 0
                    }), L({
                        id: M.id,
                        mute: M.jwGetMute()
                    }), I({
                        id: M.id,
                        newstate: e.api.events.state.IDLE
                    }), P({
                        id: M.id,
                        volume: M.jwGetVolume()
                    })
                }

                function b(e, t, n) {
                    if (!ee && _utils.exists(M.skin.getSkinElement("controlbar", e))) {
                        var i = $[e];
                        _utils.exists(i) && (_css(i, {
                            cursor: "pointer"
                        }), "fullscreen" == t ? i.onmouseup = function (e) {
                            e.stopPropagation(), M.jwSetFullscreen(!M.jwGetFullscreen())
                        } : i.onmouseup = function (e) {
                            e.stopPropagation(), _utils.exists(n) ? M[t](n) : M[t]()
                        })
                    }
                }

                function x(e) {
                    if (!ee) {
                        var t = $[e + "Slider"];
                        _css($.elements, {
                            cursor: "pointer"
                        }), _css(t, {
                            cursor: "pointer"
                        }), t.onmousedown = function () {
                            Z = e
                        }, t.onmouseup = function (e) {
                            e.stopPropagation(), _(e.pageX)
                        }, t.onmousemove = function (t) {
                            if ("time" == Z) {
                                G = !0;
                                var n = t.pageX - te[e + "Slider"].left - window.pageXOffset;
                                _css($[Z + "SliderThumb"], {
                                    left: n
                                })
                            }
                        }
                    }
                }

                function _(t) {
                    G = !1;
                    var n;
                    if ("time" == Z) {
                        n = t - te.timeSliderRail.left + window.pageXOffset;
                        var i = n / te.timeSliderRail.width * H;
                        0 > i ? i = 0 : i > H && (i = H - 3), M.jwGetState() != e.api.events.state.PAUSED && M.jwGetState() != e.api.events.state.IDLE || M.jwPlay(), M.jwSeek(i)
                    } else if ("volume" == Z) {
                        n = t - te.volumeSliderRail.left - window.pageXOffset;
                        var r = Math.round(n / te.volumeSliderRail.width * 100);
                        10 > r ? r = 0 : r > 100 && (r = 100), M.jwGetMute() && M.jwSetMute(!1), M.jwSetVolume(r)
                    }
                    Z = "none"
                }

                function k(e) {
                    if (_utils.exists(e.bufferPercent) && (J = e.bufferPercent), te.timeSliderRail) {
                        var t = M.skin.getSkinElement("controlbar", "timeSliderCapLeft"),
                            n = te.timeSliderRail.width,
                            i = isNaN(Math.round(n * J / 100)) ? 0 : Math.round(n * J / 100);
                        _css($.timeSliderBuffer, {
                            width: i,
                            left: t ? t.width : 0
                        })
                    }
                }

                function L(e) {
                    e.mute ? (_hide($.muteButton), _show($.unmuteButton), _hide($.volumeSliderProgress)) : (_show($.muteButton), _hide($.unmuteButton), _show($.volumeSliderProgress))
                }

                function I(t) {
                    t.newstate == e.api.events.state.BUFFERING || t.newstate == e.api.events.state.PLAYING ? (_show($.pauseButton), _hide($.playButton)) : (_hide($.pauseButton), _show($.playButton)), a(), t.newstate == e.api.events.state.IDLE ? (_hide($.timeSliderBuffer), _hide($.timeSliderProgress), _hide($.timeSliderThumb), j({
                        id: M.id,
                        duration: M.jwGetDuration(),
                        position: 0
                    })) : (_show($.timeSliderBuffer), t.newstate != e.api.events.state.BUFFERING && (_show($.timeSliderProgress), _show($.timeSliderThumb)))
                }

                function S(e) {
                    k({
                        bufferPercent: 0
                    }), j(_utils.extend(e, {
                        position: 0,
                        duration: H
                    }))
                }

                function j(e) {
                    _utils.exists(e.position) && (U = e.position);
                    var t = !1;
                    _utils.exists(e.duration) && e.duration != H && (H = e.duration, t = !0);
                    var n = U === H === 0 ? 0 : U / H,
                        i = te.timeSliderRail;
                    if (i) {
                        var r = isNaN(Math.round(i.width * n)) ? 0 : Math.round(i.width * n),
                            s = M.skin.getSkinElement("controlbar", "timeSliderCapLeft"),
                            o = r + (s ? s.width : 0);
                        $.timeSliderProgress && (_css($.timeSliderProgress, {
                            width: r,
                            left: s ? s.width : 0
                        }), G || $.timeSliderThumb && ($.timeSliderThumb.style.left = o + "px"))
                    }
                    if ($.durationText && ($.durationText.innerHTML = _utils.timeFormat(H)), $.elapsedText) {
                        var a = _utils.timeFormat(U);
                        $.elapsedText.innerHTML = a, ne != a.length && (t = !0, ne = a.length)
                    }
                    t && T()
                }

                function N() {
                    for (var e, t, n = $.elements.childNodes, i = 0; i < n.length; i++) {
                        var r = n[i].childNodes;
                        for (var s in r) isNaN(parseInt(s, 10)) || (0 === r[s].id.indexOf(B.id + "_divider") && t && 0 === t.id.indexOf(B.id + "_divider") && r[s].style.backgroundImage == t.style.backgroundImage ? r[s].style.display = "none" : 0 === r[s].id.indexOf(B.id + "_divider") && e && "none" != e.style.display && (r[s].style.display = "block"), "none" != r[s].style.display && (t = r[s]), e = r[s])
                    }
                }

                function R() {
                    M.jwGetFullscreen() ? (_show($.normalscreenButton), _hide($.fullscreenButton)) : (_hide($.normalscreenButton), _show($.fullscreenButton)), M.jwGetState() == e.api.events.state.BUFFERING || M.jwGetState() == e.api.events.state.PLAYING ? (_show($.pauseButton), _hide($.playButton)) : (_hide($.pauseButton), _show($.playButton)), 1 == M.jwGetMute() ? (_hide($.muteButton), _show($.unmuteButton), _hide($.volumeSliderProgress)) : (_show($.muteButton), _hide($.unmuteButton), _show($.volumeSliderProgress))
                }

                function T() {
                    N(), R();
                    var t = {
                        width: V
                    },
                        n = {
                            "float": "left",
                            styleFloat: "left",
                            cssFloat: "left"
                        };
                    (O.position == e.html5.view.positions.OVER || M.jwGetFullscreen()) && (t.left = O.margin, t.width -= 2 * O.margin, t.top = z - r().height - O.margin, t.height = r().height);
                    var i = M.skin.getSkinElement("controlbar", "capLeft"),
                        s = M.skin.getSkinElement("controlbar", "capRight");
                    n.width = t.width - (i ? i.width : 0) - (s ? s.width : 0);
                    var a = _utils.getBoundingClientRect($.leftGroup).width,
                        l = _utils.getBoundingClientRect($.rightGroup).width,
                        u = n.width - a - l - 1,
                        c = u,
                        d = M.skin.getSkinElement("controlbar", "timeSliderCapLeft"),
                        p = M.skin.getSkinElement("controlbar", "timeSliderCapRight");
                    return _utils.exists(d) && (c -= d.width), _utils.exists(p) && (c -= p.width), $.timeSlider.style.width = u + "px", $.timeSliderRail.style.width = c + "px", _css(B, t), _css($.elements, n), _css($.background, n), o(), t
                }

                function P(e) {
                    if (_utils.exists($.volumeSliderRail)) {
                        var t = isNaN(e.volume / 100) ? 1 : e.volume / 100,
                            n = _utils.parseDimension($.volumeSliderRail.style.width),
                            i = isNaN(Math.round(n * t)) ? 0 : Math.round(n * t),
                            r = (_utils.parseDimension($.volumeSliderRail.style.right), _utils.exists(M.skin.getSkinElement("controlbar", "volumeSliderCapLeft")) ? M.skin.getSkinElement("controlbar", "volumeSliderCapLeft").width : 0);
                        if (_css($.volumeSliderProgress, {
                            width: i,
                            left: r
                        }), $.volumeSliderThumb) {
                            var s = i - Math.round(_utils.parseDimension($.volumeSliderThumb.style.width) / 2);
                            s = Math.min(Math.max(s, 0), n - _utils.parseDimension($.volumeSliderThumb.style.width)), _css($.volumeSliderThumb, {
                                left: s
                            })
                        }
                        _utils.exists($.volumeSliderCapLeft) && _css($.volumeSliderCapLeft, {
                            left: 0
                        })
                    }
                }

                function C() {
                    try {
                        var e = M.id.indexOf("_instream") > 0 ? M.id.replace("_instream", "") : M.id;
                        K = document.getElementById(e), K.addEventListener("mousemove", a)
                    } catch (t) {
                        _utils.log("Could not add mouse listeners to controlbar: " + t)
                    }
                }

                function D() {
                    s(), f(), o(), ee = !0, v(), O.idlehide = "true" == O.idlehide.toString().toLowerCase(), O.position == e.html5.view.positions.OVER && O.idlehide ? (B.style.opacity = 0, re = !0) : (B.style.opacity = 1, setTimeout(function () {
                        re = !0, le()
                    }, 1)), C(), E()
                }
                window.controlbar = this;
                var M = n,
                    O = _utils.extend({}, t, M.skin.getComponentSettings("controlbar"), i);
                if (O.position != e.html5.view.positions.NONE && "undefined" != typeof e.html5.view.positions[O.position]) {
                    _utils.mapLength(M.skin.getComponentLayout("controlbar")) > 0 && (O.layout = M.skin.getComponentLayout("controlbar"));
                    var B, F, Y, W, G, U, H, J, V, z, Q, q, X, K, Z = "none",
                        $ = {},
                        ee = !1,
                        te = {},
                        ne = -1,
                        ie = !1,
                        re = !1,
                        se = !1,
                        oe = new e.html5.eventdispatcher;
                    _utils.extend(this, oe), this.getDisplayElement = function () {
                        return B
                    }, this.resize = function (e, t) {
                        C(), _utils.cancelAnimation(B), V = e, z = t, se != M.jwGetFullscreen() && (se = M.jwGetFullscreen(), se || a(), X = void 0);
                        var n = T();
                        return j({
                            id: M.id,
                            duration: H,
                            position: U
                        }), k({
                            id: M.id,
                            bufferPercent: J
                        }), n
                    }, this.show = function () {
                        ie && (ie = !1, _show(B), le())
                    }, this.hide = function () {
                        ie || (ie = !0, _hide(B), ue())
                    };
                    var ae, le = c(e.api.events.JWPLAYER_COMPONENT_SHOW),
                        ue = c(e.api.events.JWPLAYER_COMPONENT_HIDE);
                    return D(), this
                }
            }
        }(jwplayer),
        function (e) {
            var t = e.utils;
            e.html5.controller = function (n, r, s, o) {
                function a(e) {
                    F ? W.sendEvent(e.type, e) : B.push(e)
                }

                function l(t) {
                    if (!F) {
                        for (F = !0, W.sendEvent(e.api.events.JWPLAYER_READY, t), e.utils.exists(window.playerReady) && playerReady(t), e.utils.exists(window[s.config.playerReady]) && window[s.config.playerReady](t); B.length > 0;) {
                            var n = B.shift();
                            W.sendEvent(n.type, n)
                        }
                        for (s.config.autostart && !e.utils.isIOS() && x(); G.length > 0;) {
                            var i = G.shift();
                            j(i.method, i.arguments)
                        }
                    }
                }

                function u() {
                    try {
                        return N = u, !M && (M = !0, W.sendEvent(e.api.events.JWPLAYER_MEDIA_BEFOREPLAY), M = !1, O) ? (O = !1, void (N = null)) : (y(R.item), R.playlist[R.item].levels[0].file.length > 0 && (C || R.state == e.api.events.state.IDLE ? (R.getMedia().load(R.playlist[R.item]), C = !1) : R.state == e.api.events.state.PAUSED && R.getMedia().play()), !0)
                    } catch (t) {
                        W.sendEvent(e.api.events.JWPLAYER_ERROR, t), N = null
                    }
                    return !1
                }

                function c() {
                    try {
                        if (R.playlist[R.item].levels[0].file.length > 0) switch (R.state) {
                            case e.api.events.state.PLAYING:
                            case e.api.events.state.BUFFERING:
                                R.getMedia() && R.getMedia().pause();
                                break;
                            default:
                                M && (O = !0)
                        }
                        return !0
                    } catch (t) {
                        W.sendEvent(e.api.events.JWPLAYER_ERROR, t)
                    }
                    return !1
                }

                function d(t) {
                    try {
                        if (R.playlist[R.item].levels[0].file.length > 0) switch ("number" != typeof t && (t = parseFloat(t)), R.state) {
                            case e.api.events.state.IDLE:
                                0 > D && (D = R.playlist[R.item].start, R.playlist[R.item].start = t), M || u();
                                break;
                            case e.api.events.state.PLAYING:
                            case e.api.events.state.PAUSED:
                            case e.api.events.state.BUFFERING:
                                R.seek(t)
                        }
                        return !0
                    } catch (n) {
                        W.sendEvent(e.api.events.JWPLAYER_ERROR, n)
                    }
                    return !1
                }

                function p(n) {
                    N = null, t.exists(n) || (n = !0);
                    try {
                        return (R.state != e.api.events.state.IDLE || n) && R.getMedia() && R.getMedia().stop(n), M && (O = !0), !0
                    } catch (i) {
                        W.sendEvent(e.api.events.JWPLAYER_ERROR, i)
                    }
                    return !1
                }

                function f() {
                    try {
                        if (R.playlist[R.item].levels[0].file.length > 0 && y(R.config.shuffle ? g() : R.item + 1 == R.playlist.length ? 0 : R.item + 1), R.state != e.api.events.state.IDLE) {
                            var t = R.state;
                            R.state = e.api.events.state.IDLE, W.sendEvent(e.api.events.JWPLAYER_PLAYER_STATE, {
                                oldstate: t,
                                newstate: e.api.events.state.IDLE
                            })
                        }
                        return u(), !0
                    } catch (n) {
                        W.sendEvent(e.api.events.JWPLAYER_ERROR, n)
                    }
                    return !1
                }

                function h() {
                    try {
                        if (R.playlist[R.item].levels[0].file.length > 0 && y(R.config.shuffle ? g() : 0 === R.item ? R.playlist.length - 1 : R.item - 1), R.state != e.api.events.state.IDLE) {
                            var t = R.state;
                            R.state = e.api.events.state.IDLE, W.sendEvent(e.api.events.JWPLAYER_PLAYER_STATE, {
                                oldstate: t,
                                newstate: e.api.events.state.IDLE
                            })
                        }
                        return u(), !0
                    } catch (n) {
                        W.sendEvent(e.api.events.JWPLAYER_ERROR, n)
                    }
                    return !1
                }

                function g() {
                    var e = null;
                    if (R.playlist.length > 1)
                        for (; !t.exists(e);) e = Math.floor(Math.random() * R.playlist.length), e == R.item && (e = null);
                    else e = 0;
                    return e
                }

                function m(t) {
                    if (!R.playlist || !R.playlist[t]) return !1;
                    try {
                        if (R.playlist[t].levels[0].file.length > 0) {
                            var n = R.state;
                            n !== e.api.events.state.IDLE && (R.playlist[R.item] && R.playlist[R.item].provider == R.playlist[t].provider ? p(!1) : p()), y(t), u()
                        }
                        return !0
                    } catch (i) {
                        W.sendEvent(e.api.events.JWPLAYER_ERROR, i)
                    }
                    return !1
                }

                function y(t) {
                    R.playlist[t] && (R.setActiveMediaProvider(R.playlist[t]), R.item != t && (R.item = t, C = !0, W.sendEvent(e.api.events.JWPLAYER_PLAYLIST_ITEM, {
                        index: t
                    })))
                }

                function v(t) {
                    try {
                        y(R.item);
                        var n = R.getMedia();
                        switch (typeof t) {
                            case "number":
                                n.volume(t);
                                break;
                            case "string":
                                n.volume(parseInt(t, 10))
                        }
                        return R.setVolume(t), !0
                    } catch (i) {
                        W.sendEvent(e.api.events.JWPLAYER_ERROR, i)
                    }
                    return !1
                }

                function A(t) {
                    try {
                        y(R.item);
                        var n = R.getMedia();
                        return "undefined" == typeof t ? (n.mute(!R.mute), R.setMute(!R.mute)) : "true" == t.toString().toLowerCase() ? (n.mute(!0), R.setMute(!0)) : (n.mute(!1), R.setMute(!1)), !0
                    } catch (i) {
                        W.sendEvent(e.api.events.JWPLAYER_ERROR, i)
                    }
                    return !1
                }

                function w(t, n) {
                    try {
                        return R.width = t, R.height = n, T.resize(t, n), W.sendEvent(e.api.events.JWPLAYER_RESIZE, {
                            width: R.width,
                            height: R.height
                        }), !0
                    } catch (i) {
                        W.sendEvent(e.api.events.JWPLAYER_ERROR, i)
                    }
                    return !1
                }

                function E(t, n) {
                    try {
                        return "undefined" == typeof t && (t = !R.fullscreen), "undefined" == typeof n && (n = !0), t != R.fullscreen && (R.fullscreen = "true" == t.toString().toLowerCase(), T.fullscreen(R.fullscreen), n && W.sendEvent(e.api.events.JWPLAYER_FULLSCREEN, {
                            fullscreen: R.fullscreen
                        }), W.sendEvent(e.api.events.JWPLAYER_RESIZE, {
                            width: R.width,
                            height: R.height
                        })), !0
                    } catch (i) {
                        W.sendEvent(e.api.events.JWPLAYER_ERROR, i)
                    }
                    return !1
                }

                function b(n) {
                    try {
                        return p(), M && (O = !1), R.loadPlaylist(n), R.playlist[R.item].provider ? (y(R.item), "true" != R.config.autostart.toString().toLowerCase() || t.isIOS() || M || u(), !0) : !1
                    } catch (i) {
                        W.sendEvent(e.api.events.JWPLAYER_ERROR, i)
                    }
                    return !1
                }

                function x() {
                    t.isIOS() || (y(R.item), "true" != R.config.autostart.toString().toLowerCase() || t.isIOS() || u())
                }

                function _(e) {
                    E(e.fullscreen, !1)
                }

                function k() {
                    try {
                        return R.getMedia().detachMedia()
                    } catch (e) {
                        return null
                    }
                }

                function L() {
                    try {
                        R.getMedia().attachMedia();
                        "function" == typeof N && N()
                    } catch (e) {
                        return null
                    }
                }

                function I() {
                    if (R.state == e.api.events.state.IDLE) switch (N = I, R.config.repeat.toUpperCase()) {
                        case e.html5.controller.repeatoptions.SINGLE:
                            u();
                            break;
                        case e.html5.controller.repeatoptions.ALWAYS:
                            R.item != R.playlist.length - 1 || R.config.shuffle ? f() : m(0);
                            break;
                        case e.html5.controller.repeatoptions.LIST:
                            R.item != R.playlist.length - 1 || R.config.shuffle ? f() : (p(), y(0));
                            break;
                        default:
                            p()
                    }
                }

                function S(e) {
                    return function () {
                        F ? j(e, arguments) : G.push({
                            method: e,
                            arguments: arguments
                        })
                    }
                }

                function j(e, t) {
                    var n = [];
                    for (i = 0; i < t.length; i++) n.push(t[i]);
                    e.apply(this, n)
                }
                var N, R = s,
                    T = o,
                    P = r,
                    C = !0,
                    D = -1,
                    M = !1,
                    O = !1,
                    B = [],
                    F = !1,
                    Y = t.exists(R.config.debug) && "console" == R.config.debug.toString().toLowerCase(),
                    W = new e.html5.eventdispatcher(P.id, Y);
                t.extend(this, W), R.addGlobalListener(a), R.addEventListener(e.api.events.JWPLAYER_MEDIA_BUFFER_FULL, function () {
                    R.getMedia().play()
                }), R.addEventListener(e.api.events.JWPLAYER_MEDIA_TIME, function (e) {
                    e.position >= R.playlist[R.item].start && D >= 0 && (R.playlist[R.item].start = D, D = -1)
                }), R.addEventListener(e.api.events.JWPLAYER_MEDIA_COMPLETE, function () {
                    setTimeout(I, 25)
                }), R.addEventListener(e.api.events.JWPLAYER_PLAYLIST_LOADED, x), R.addEventListener(e.api.events.JWPLAYER_FULLSCREEN, _), e.html5.controller.repeatoptions = {
                    LIST: "LIST",
                    ALWAYS: "ALWAYS",
                    SINGLE: "SINGLE",
                    NONE: "NONE"
                };
                var G = [];
                this.play = S(u), this.pause = S(c), this.seek = S(d), this.stop = S(p), this.next = S(f), this.prev = S(h), this.item = S(m), this.setVolume = S(v), this.setMute = S(A), this.resize = S(w), this.setFullscreen = S(E), this.load = S(b), this.playerReady = l, this.detachMedia = k, this.attachMedia = L, this.beforePlay = function () {
                    return M
                }, this.destroy = function () {
                    R.getMedia() && R.getMedia().destroy()
                }
            }
        }(jwplayer),
        function (e) {
            e.html5.defaultSkin = function () {
                return this.text = '<?xml version="1.0" ?><skin author="LongTail Video" name="Five" version="1.1"><components><component name="controlbar"><settings><setting name="margin" value="20"/><setting name="fontsize" value="11"/><setting name="fontcolor" value="0x000000"/></settings><layout><group position="left"><button name="play"/><divider name="divider"/><button name="prev"/><divider name="divider"/><button name="next"/><divider name="divider"/><text name="elapsed"/></group><group position="center"><slider name="time"/></group><group position="right"><text name="duration"/><divider name="divider"/><button name="blank"/><divider name="divider"/><button name="mute"/><slider name="volume"/><divider name="divider"/><button name="fullscreen"/></group></layout><elements><element name="background" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAIAAABvFaqvAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAElJREFUOI3t1LERACAMQlFgGvcfxNIhHMK4gsUvUviOmgtNsiAZkBSEKxKEnCYkkQrJn/YwbUNiSDDYRZaQRDaShv+oX9GBZEIuK+8hXVLs+/YAAAAASUVORK5CYII="/><element name="blankButton" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAUAAAAYCAYAAAAyJzegAAAAFElEQVQYV2P8//8/AzpgHBUc7oIAGZdH0RjKN8EAAAAASUVORK5CYII="/><element name="capLeft" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAAYCAYAAAA7zJfaAAAAQElEQVQIWz3LsRGAMADDQJ0XB5bMINABZ9GENGrszxhjT2WLSqxEJG2JQrTMdV2q5LpOAvyRaVmsi7WdeZ/7+AAaOTq7BVrfOQAAAABJRU5ErkJggg=="/><element name="capRight" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAAYCAYAAAA7zJfaAAAAQElEQVQIWz3LsRGAMADDQJ0XB5bMINABZ9GENGrszxhjT2WLSqxEJG2JQrTMdV2q5LpOAvyRaVmsi7WdeZ/7+AAaOTq7BVrfOQAAAABJRU5ErkJggg=="/><element name="divider" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAAYCAIAAAC0rgCNAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAADhJREFUCB0FwcENgEAAw7Aq+893g8APUILNOQcbFRktVGqUVFRkWNz3xTa2sUaLNUosKlRUvvf5AdbWOTtzmzyWAAAAAElFTkSuQmCC"/><element name="playButton" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABUAAAAYCAYAAAAVibZIAAAANUlEQVR42u2RsQkAAAjD/NTTPaW6dXLrINJA1kBpGPMAjDWmOgp1HFQXx+b1KOefO4oxY57R73YnVYCQUCQAAAAASUVORK5CYII="/><element name="pauseButton" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABUAAAAYCAYAAAAVibZIAAAAIUlEQVQ4jWNgGAWjYOiD/0gYG3/U0FFDB4Oho2AUDAYAAEwiL9HrpdMVAAAAAElFTkSuQmCC"/><element name="prevButton" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABUAAAAYCAYAAAAVibZIAAAAQklEQVQ4y2NgGAWjYOiD/1AMA/JAfB5NjCJD/YH4PRaLyDa0H4lNNUP/DxlD59PCUBCIp3ZEwYA+NZLUKBgFgwEAAN+HLX9sB8u8AAAAAElFTkSuQmCC"/><element name="nextButton" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABUAAAAYCAYAAAAVibZIAAAAQElEQVQ4y2NgGAWjYOiD/0B8Hojl0cT+U2ooCL8HYn9qGwrD/bQw9P+QMXQ+tSMqnpoRBUpS+tRMUqNgFAwGAADxZy1/mHvFnAAAAABJRU5ErkJggg=="/><element name="timeSliderRail" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAAAOElEQVRIDe3BwQkAIRADwAhhw/nU/kWwUK+KPITMABFh19Y+F0acY8CJvX9wYpXgRElwolSIiMf9ZWEDhtwurFsAAAAASUVORK5CYII="/><element name="timeSliderBuffer" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAAAN0lEQVRIDe3BwQkAMQwDMBcc55mRe9zi7RR+FCwBEWG39vcfGHFm4MTuhhMlwYlVBSdKhYh43AW/LQMKm1spzwAAAABJRU5ErkJggg=="/><element name="timeSliderProgress" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAAAIElEQVRIiWNgGAWjYBTQBfynMR61YCRYMApGwSigMQAAiVWPcbq6UkIAAAAASUVORK5CYII="/><element name="timeSliderThumb" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAMAAAAYCAYAAAA/OUfnAAAAO0lEQVQYlWP4//8/Awwz0JgDBP/BeN6Cxf/hnI2btiI4u/fsQ3AOHjqK4Jw4eQbBOX/hEoKDYjSd/AMA4cS4mfLsorgAAAAASUVORK5CYII="/><element name="muteButton" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAA4AAAAYCAYAAADKx8xXAAAAJklEQVQ4y2NgGAUjDcwH4v/kaPxPikZkxcNVI9mBQ5XoGAWDFwAAsKAXKQQmfbUAAAAASUVORK5CYII="/><element name="unmuteButton" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAA4AAAAYCAYAAADKx8xXAAAAMklEQVQ4y2NgGAWDHPyntub5xBr6Hwv/Pzk2/yfVG/8psRFE25Oq8T+tQnsIaB4FVAcAi2YVysVY52AAAAAASUVORK5CYII="/><element name="volumeSliderRail" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYAgMAAACdGdVrAAAACVBMVEUAAACmpqampqbBXAu8AAAAAnRSTlMAgJsrThgAAAArSURBVAhbY2AgErBAyA4I2QEhOyBkB4TsYOhAoaCCUCUwDTDtMMNgRuMHAFB5FoGH5T0UAAAAAElFTkSuQmCC"/><element name="volumeSliderProgress" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYAgMAAACdGdVrAAAACVBMVEUAAAAAAAAAAACDY+nAAAAAAnRSTlMAgJsrThgAAAArSURBVAhbY2AgErBAyA4I2QEhOyBkB4TsYOhAoaCCUCUwDTDtMMNgRuMHAFB5FoGH5T0UAAAAAElFTkSuQmCC"/><element name="volumeSliderCapRight" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAUAAAAYCAYAAAAyJzegAAAAFElEQVQYV2P8//8/AzpgHBUc7oIAGZdH0RjKN8EAAAAASUVORK5CYII="/><element name="fullscreenButton" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAAAQklEQVRIiWNgGAWjYMiD/0iYFDmSLbDHImdPLQtgBpEiR7Zl2NijAA5oEkT/0Whi5UiyAJ8BVMsHNMtoo2AUDAIAAGdcIN3IDNXoAAAAAElFTkSuQmCC"/><element name="normalscreenButton" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAAAP0lEQVRIx2NgGAWjYMiD/1RSQ5QB/wmIUWzJfzx8qhj+n4DYCAY0DyJ7PBbYU8sHMEvwiZFtODXUjIJRMJgBACpWIN2ZxdPTAAAAAElFTkSuQmCC"/></elements></component><component name="display"><elements><element name="background" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADIAAAAyAQMAAAAk8RryAAAABlBMVEUAAAAAAAClZ7nPAAAAAnRSTlOZpuml+rYAAAASSURBVBhXY2AYJuA/GBwY6jQAyDyoK8QcL4QAAAAASUVORK5CYII="/><element name="playIcon" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADIAAAAyCAYAAAAeP4ixAAAAiUlEQVR42u3XSw2AMBREURwgAQlIQAISKgUpSEFKJeCg5b0E0kWBTVcD9ySTsL0Jn9IBAAAA+K2UUrBlW/Rr5ZDoIeeuoFkxJD9ss03aIXXQqB9SttoG7ZA6qNcOKdttiwcJh9RB+iFl4SshkRBuLR72+9cvH0SOKI2HRo7x/Fi1/uoCAAAAwLsD8ki99IlO2dQAAAAASUVORK5CYII="/><element name="muteIcon" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADIAAAAyCAYAAAAeP4ixAAAAVUlEQVR42u3WMQrAIAxAUW/g/SdvGmvpoOBeSHgPsjj5QTANAACARCJilIhYM0tEvJM+Ik3Id9E957kQIb+F3OdCPC0hPkQriqWx9hp/x/QGAABQyAPLB22VGrpLDgAAAABJRU5ErkJggg=="/><element name="errorIcon" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADIAAAAyCAYAAAAeP4ixAAAA/0lEQVR42u2U0QmEMBAF7cASLMESUoIlpARLSCkpwRJSgiWkhOvAXD4WsgRkyaG5DbyB+Yvg8KITAAAAAAAYk+u61mwk15EjPtlEfihmqIiZR1Qx80ghjgdUuiHXGHSVsoag0x6x8DUoyjD5KovmEJ9NTDMRPIT0mtdIUkjlonuNohO+Ha99DTmkuGgKCTcvebAzx82ZoCWC3/3aIMWSRucaxcjORSFY4xpFdjYJGp1rFGcyCYZ/RVh6AUnfcNZ2zih3/mGj1jVCdiNDwyrq1rA/xMdeEXvDVdnYc1vDc3uPkDObXrlaxbNHSOohQhr/WOeLEWfWTgAAAAAAADzNF9sHJ7PJ57MlAAAAAElFTkSuQmCC"/><element name="bufferIcon" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADIAAAAyCAYAAAAeP4ixAAACBklEQVR42u3Zv0sCYRzH8USTzOsHHEWGkC1HgaDgkktGDjUYtDQ01RDSljQ1BLU02+rk1NTm2NLq4Nx/0L/h9fnCd3j4cnZe1/U8xiO8h3uurufF0/3COd/3/0UWYiEWYiEWYiGJQ+J8xuPxKhXjEMZANinjIZhkGuVRNioE4wVURo4JkHm0xKWmhRAc1bh1EyCUw5BcBIjHiApKa4CErko6DEJwuRo6IRKzyJD8FJAyI3Zp2zRImiBcRhlfo5RtlxCcE3CcDNpGrhYIT2IhAJKilO0VRmzJ32fAMTpBTS0QMfGwlcuKMRftE0DJ0wCJdcOsCkBdXP3Mh9CEFUBTPS9mDZJBG6io4aqVzMdCokCw9H3kT6j/C/9iDdSeUMNC7DkyyxAs/Rk6Qss8FPWRZgdVtUH4DjxEn1zxh+/zj1wHlf4MQhNGrwqA6sY40U8JonRJwEQh+AO3AvCG6gHv4U7IY4krxkroWoAOkoQMGfCBrgIm+YBGqPENpIJ66CJg3x66Y0gnSUidAEEnNr9jjLiWMn5DiWP0OC/oAsCgkq43xBdGDMQr7YASP/vEkHvdl1+JOCcEV5sC4hGEOzTlPuKgd0b0xD4JkRcOgnRRTjdErkYhAsQVq6IdUuPJtmk7BCL3t/h88cx91pKQkI/pkDx6pmYTIjEoxiHsN1YWYiEWYiEWknhflZ5IErA5nr8AAAAASUVORK5CYII="/></elements></component><component name="dock"><settings><setting name="fontcolor" value="0xffffff"/></settings><elements><element name="button" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADIAAAAyAQMAAAAk8RryAAAABlBMVEUAAAAAAAClZ7nPAAAAAnRSTlOZpuml+rYAAAASSURBVBhXY2AYJuA/GBwY6jQAyDyoK8QcL4QAAAAASUVORK5CYII="/></elements></component><component name="playlist"><settings><setting name="backgroundcolor" value="0xe8e8e8"/></settings><elements><element name="item" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADwAAAA8CAIAAAC1nk4lAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAHBJREFUaN7t2MENwCAMBEEe9N8wSKYC/D8YV7CyJoRkVtVImxkZPQInMxoP0XiIxkM0HsGbjjSNBx544IEHHnjggUe/6UQeey0PIh7XTftGxKPj4eXCtLsHHh+ZxkO0Iw8PR55Ni8ZD9Hu/EAoP0dc5RRg9qeRjVF8AAAAASUVORK5CYII="/><element name="sliderCapTop" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABUAAAAHCAYAAADnCQYGAAAAFUlEQVQokWP8//8/A7UB46ihI9hQAKt6FPPXhVGHAAAAAElFTkSuQmCC"/><element name="sliderRail" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABUAAAAUCAYAAABiS3YzAAAAKElEQVQ4y2P4//8/Az68bNmy/+iYkB6GUUNHDR01dNTQUUNHDaXcUABUDOKhcxnsSwAAAABJRU5ErkJggg=="/><element name="sliderThumb" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABUAAAAUCAYAAABiS3YzAAAAJUlEQVQ4T2P4//8/Ay4MBP9xYbz6Rg0dNXTU0FFDRw0dNZRyQwHH4NBa7GJsXAAAAABJRU5ErkJggg=="/><element name="sliderCapBottom" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABUAAAAHCAYAAADnCQYGAAAAFUlEQVQokWP8//8/A7UB46ihI9hQAKt6FPPXhVGHAAAAAElFTkSuQmCC"/></elements></component></components></skin>', this.xml = null, window.DOMParser ? (parser = new DOMParser, this.xml = parser.parseFromString(this.text, "text/xml")) : (this.xml = new ActiveXObject("Microsoft.XMLDOM"), this.xml.async = "false", this.xml.loadXML(this.text)), this
            }
        }(jwplayer),
        function (e) {
            _utils = e.utils, _css = _utils.css, _hide = function (e) {
                _css(e, {
                    display: "none"
                })
            }, _show = function (e) {
                _css(e, {
                    display: "block"
                })
            }, e.html5.display = function (t, n) {
                function i() {
                    C.display = o("div", "display"), C.display_text = o("div", "display_text"), C.display.appendChild(C.display_text), C.display_image = o("img", "display_image"), C.display_image.onerror = function () {
                        _hide(C.display_image)
                    }, C.display_image.onload = r, C.display_icon = o("div", "display_icon"), C.display_iconBackground = o("div", "display_iconBackground"), C.display.appendChild(C.display_image), C.display_iconBackground.appendChild(C.display_icon), C.display.appendChild(C.display_iconBackground), a(), setTimeout(function () {
                        H = !0, "true" == T.icons.toString() && z()
                    }, 1)
                }

                function r() {
                    b = C.display_image.naturalWidth, x = C.display_image.naturalHeight, s(), P.jwGetState() != e.api.events.state.IDLE && "sound" != P.jwGetPlaylist()[P.jwGetPlaylistIndex()].provider || (_css(C.display_image, {
                        display: "block",
                        opacity: 0
                    }), _utils.fadeTo(C.display_image, 1, .1)), Y = !1
                }

                function s() {
                    if (P.jwGetFullscreen() && P.jwGetStretching() == e.utils.stretching.EXACTFIT) {
                        var t = document.createElement("div");
                        _utils.stretch(e.utils.stretching.UNIFORM, t, w, E, j, N), _utils.stretch(e.utils.stretching.EXACTFIT, C.display_image, _utils.parseDimension(t.style.width), _utils.parseDimension(t.style.height), b, x), _css(C.display_image, {
                            left: t.style.left,
                            top: t.style.top
                        })
                    } else _utils.stretch(P.jwGetStretching(), C.display_image, w, E, b, x)
                }

                function o(e, t) {
                    var n = document.createElement(e);
                    return n.id = P.id + "_jwplayer_" + t, _css(n, V[t].style), n
                }

                function a() {
                    for (var e in C) _utils.exists(V[e].click) && (C[e].onclick = V[e].click)
                }

                function l(t) {
                    return "undefined" != typeof t.preventDefault ? t.preventDefault() : t.returnValue = !1, "function" == typeof S ? void S(t) : void (P.jwGetState() != e.api.events.state.PLAYING ? P.jwPlay() : P.jwPause())
                }

                function u(e) {
                    return L ? void c() : (C.display_icon.style.backgroundImage = ["url(", P.skin.getSkinElement("display", e).src, ")"].join(""), _css(C.display_icon, {
                        width: P.skin.getSkinElement("display", e).width,
                        height: P.skin.getSkinElement("display", e).height,
                        top: (P.skin.getSkinElement("display", "background").height - P.skin.getSkinElement("display", e).height) / 2,
                        left: (P.skin.getSkinElement("display", "background").width - P.skin.getSkinElement("display", e).width) / 2
                    }), d(), void (_utils.exists(P.skin.getSkinElement("display", e + "Over")) ? (C.display_icon.onmouseover = function () {
                        C.display_icon.style.backgroundImage = ["url(", P.skin.getSkinElement("display", e + "Over").src, ")"].join("");
                    }, C.display_icon.onmouseout = function () {
                        C.display_icon.style.backgroundImage = ["url(", P.skin.getSkinElement("display", e).src, ")"].join("")
                    }) : (C.display_icon.onmouseover = null, C.display_icon.onmouseout = null)))
                }

                function c() {
                    "true" == T.icons.toString() && (_hide(C.display_icon), _hide(C.display_iconBackground), Q())
                }

                function d() {
                    U || "true" != T.icons.toString() || (_show(C.display_icon), _show(C.display_iconBackground), z())
                }

                function p(e) {
                    L = !0, c(), C.display_text.innerHTML = e.message, _show(C.display_text), C.display_text.style.top = (E - _utils.getBoundingClientRect(C.display_text).height) / 2 + "px"
                }

                function f() {
                    W = !1, C.display_image.style.display = "none"
                }

                function h() {
                    B = ""
                }

                function g(t) {
                    t.type != e.api.events.JWPLAYER_PLAYER_STATE && t.type != e.api.events.JWPLAYER_PLAYLIST_ITEM || !L || (L = !1, _hide(C.display_text));
                    var n = P.jwGetState();
                    n != B && (B = n, O >= 0 && clearTimeout(O), F || P.jwGetState() == e.api.events.state.PLAYING || P.jwGetState() == e.api.events.state.PAUSED ? y(P.jwGetState()) : O = setTimeout(m(P.jwGetState()), 500))
                }

                function m(e) {
                    return function () {
                        y(e)
                    }
                }

                function y(t) {
                    switch (_utils.exists(k) && (clearInterval(k), k = null, _utils.animations.rotate(C.display_icon, 0)), t) {
                        case e.api.events.state.BUFFERING:
                            _utils.isIPod() ? (f(), c()) : ("sound" == P.jwGetPlaylist()[P.jwGetPlaylistIndex()].provider && v(), _ = 0, k = setInterval(function () {
                                _ += D, _utils.animations.rotate(C.display_icon, _ % 360)
                            }, M), u("bufferIcon"), F = !0);
                            break;
                        case e.api.events.state.PAUSED:
                            _utils.isIPod() || ("sound" != P.jwGetPlaylist()[P.jwGetPlaylistIndex()].provider && _css(C.display_image, {
                                background: "transparent no-repeat center center"
                            }), u("playIcon"), F = !0);
                            break;
                        case e.api.events.state.IDLE:
                            P.jwGetPlaylist()[P.jwGetPlaylistIndex()] && P.jwGetPlaylist()[P.jwGetPlaylistIndex()].image ? v() : f(), u("playIcon"), F = !0;
                            break;
                        default:
                            P.jwGetPlaylist()[P.jwGetPlaylistIndex()] && "sound" == P.jwGetPlaylist()[P.jwGetPlaylistIndex()].provider ? _utils.isIPod() ? (f(), F = !1) : v() : (f(), F = !1), P.jwGetMute() && T.showmute ? u("muteIcon") : c()
                    }
                    O = -1
                }

                function v() {
                    if (P.jwGetPlaylist()[P.jwGetPlaylistIndex()]) {
                        var e = P.jwGetPlaylist()[P.jwGetPlaylistIndex()].image;
                        e && (e != G ? (G = e, Y = !0, C.display_image.src = _utils.getAbsolutePath(e)) : Y || W || (W = !0, C.display_image.style.opacity = 0, C.display_image.style.display = "block", _utils.fadeTo(C.display_image, 1, .1)))
                    }
                }

                function A(e) {
                    return function () {
                        H && (U || I == e || (I = e, J.sendEvent(e, {
                            component: "display",
                            boundingRect: _utils.getDimensions(C.display_iconBackground)
                        })))
                    }
                }
                var w, E, b, x, _, k, L, I, S, j, N, R = {
                    icons: !0,
                    showmute: !1
                },
                    T = _utils.extend({}, R, n),
                    P = t,
                    C = {},
                    D = _utils.exists(P.skin.getComponentSettings("display").bufferrotation) ? parseInt(P.skin.getComponentSettings("display").bufferrotation, 10) : 15,
                    M = _utils.exists(P.skin.getComponentSettings("display").bufferinterval) ? parseInt(P.skin.getComponentSettings("display").bufferinterval, 10) : 100,
                    O = -1,
                    B = e.api.events.state.IDLE,
                    F = !0,
                    Y = !1,
                    W = !0,
                    G = "",
                    U = !1,
                    H = !1,
                    J = new e.html5.eventdispatcher;
                _utils.extend(this, J);
                var V = {
                    display: {
                        style: {
                            cursor: "pointer",
                            top: 0,
                            left: 0,
                            overflow: "hidden"
                        },
                        click: l
                    },
                    display_icon: {
                        style: {
                            cursor: "pointer",
                            position: "absolute",
                            top: (P.skin.getSkinElement("display", "background").height - P.skin.getSkinElement("display", "playIcon").height) / 2,
                            left: (P.skin.getSkinElement("display", "background").width - P.skin.getSkinElement("display", "playIcon").width) / 2,
                            border: 0,
                            margin: 0,
                            padding: 0,
                            zIndex: 3,
                            display: "none"
                        }
                    },
                    display_iconBackground: {
                        style: {
                            cursor: "pointer",
                            position: "absolute",
                            top: (E - P.skin.getSkinElement("display", "background").height) / 2,
                            left: (w - P.skin.getSkinElement("display", "background").width) / 2,
                            border: 0,
                            backgroundImage: ["url(", P.skin.getSkinElement("display", "background").src, ")"].join(""),
                            width: P.skin.getSkinElement("display", "background").width,
                            height: P.skin.getSkinElement("display", "background").height,
                            margin: 0,
                            padding: 0,
                            zIndex: 2,
                            display: "none"
                        }
                    },
                    display_image: {
                        style: {
                            display: "none",
                            width: w,
                            height: E,
                            position: "absolute",
                            cursor: "pointer",
                            left: 0,
                            top: 0,
                            margin: 0,
                            padding: 0,
                            textDecoration: "none",
                            zIndex: 1
                        }
                    },
                    display_text: {
                        style: {
                            zIndex: 4,
                            position: "relative",
                            opacity: .8,
                            backgroundColor: parseInt("000000", 16),
                            color: parseInt("ffffff", 16),
                            textAlign: "center",
                            fontFamily: "Arial,sans-serif",
                            padding: "0 5px",
                            fontSize: 14
                        }
                    }
                };
                P.jwAddEventListener(e.api.events.JWPLAYER_PLAYER_STATE, g), P.jwAddEventListener(e.api.events.JWPLAYER_MEDIA_MUTE, g), P.jwAddEventListener(e.api.events.JWPLAYER_PLAYLIST_LOADED, h), P.jwAddEventListener(e.api.events.JWPLAYER_PLAYLIST_ITEM, g), P.jwAddEventListener(e.api.events.JWPLAYER_ERROR, p), i(), this.getDisplayElement = function () {
                    return C.display
                }, this.resize = function (e, t) {
                    P.jwGetFullscreen() && _utils.isMobile() || (_css(C.display, {
                        width: e,
                        height: t
                    }), _css(C.display_text, {
                        width: e - 10,
                        top: (t - _utils.getBoundingClientRect(C.display_text).height) / 2
                    }), _css(C.display_iconBackground, {
                        top: (t - P.skin.getSkinElement("display", "background").height) / 2,
                        left: (e - P.skin.getSkinElement("display", "background").width) / 2
                    }), w == e && E == t || (w = e, E = t, I = void 0, z()), P.jwGetFullscreen() || (j = e, N = t), s(), g({}))
                }, this.show = function () {
                    U && (U = !1, y(P.jwGetState()))
                }, this.hide = function () {
                    U || (c(), U = !0)
                };
                var z = A(e.api.events.JWPLAYER_COMPONENT_SHOW),
                    Q = A(e.api.events.JWPLAYER_COMPONENT_HIDE);
                return this.setAlternateClickHandler = function (e) {
                    S = e
                }, this.revertAlternateClickHandler = function () {
                    S = void 0
                }, this
            }
        }(jwplayer),
        function (e) {
            var t = e.utils,
                n = t.css;
            e.html5.dock = function (i, r) {
                function s() {
                    return {
                        align: e.html5.view.positions.RIGHT
                    }
                }

                function o(e) {
                    return "url(" + e + ") no-repeat center center"
                }

                function a(n, r) {
                    if (f(), E.length > 0) {
                        var s, o, a = 10,
                            l = a,
                            u = -1,
                            c = i.skin.getSkinElement("dock", "button").height,
                            d = i.skin.getSkinElement("dock", "button").width,
                            p = n - d - a;
                        h.align == e.html5.view.positions.LEFT && (u = 1, p = a);
                        for (var v = 0; v < E.length; v++) {
                            var A = Math.floor(l / r);
                            l + c + a > (A + 1) * r && (l = (A + 1) * r + a, A = Math.floor(l / r));
                            var b = w[E[v]].div;
                            b.style.top = l % r + "px", b.style.left = p + (i.skin.getSkinElement("dock", "button").width + a) * A * u + "px";
                            var k = {
                                x: t.parseDimension(b.style.left),
                                y: t.parseDimension(b.style.top),
                                width: d,
                                height: c
                            };
                            (!s || k.x <= s.x && k.y <= s.y) && (s = k), (!o || k.x >= o.x && k.y >= o.y) && (o = k), b.style.width = d + "px", b.style.height = c + "px", l += i.skin.getSkinElement("dock", "button").height + a
                        }
                        _ = {
                            x: s.x,
                            y: s.y,
                            width: o.x - s.x + o.width,
                            height: s.y - o.y + o.height
                        }
                    }
                    x == i.jwGetFullscreen() && g == n && m == r || (g = n, m = r, x = i.jwGetFullscreen(), y = void 0, setTimeout(I, 1))
                }

                function l(e) {
                    return function () {
                        !b && y != e && E.length > 0 && (y = e, k.sendEvent(e, {
                            component: "dock",
                            boundingRect: _
                        }))
                    }
                }

                function u(n) {
                    t.isMobile() ? n.newstate == e.api.events.state.IDLE ? j() : N() : c()
                }

                function c(n) {
                    if (!b)
                        if (clearTimeout(A), r.position == e.html5.view.positions.OVER || i.jwGetFullscreen()) switch (i.jwGetState()) {
                            case e.api.events.state.PAUSED:
                            case e.api.events.state.IDLE:
                                L && L.style.opacity < 1 && (!r.idlehide || t.exists(n)) && p(), r.idlehide && (A = setTimeout(function () {
                                    d()
                                }, 2e3));
                                break;
                            default:
                                t.exists(n) && p(), A = setTimeout(function () {
                                    d()
                                }, 2e3)
                        } else p()
                }

                function d() {
                    b || (S(), 1 == L.style.opacity && (t.cancelAnimation(L), t.fadeTo(L, 0, .1, 1, 0)))
                }

                function p() {
                    b || (I(), 0 == L.style.opacity && (t.cancelAnimation(L), t.fadeTo(L, 1, .1, 0, 0)))
                }

                function f() {
                    try {
                        v = document.getElementById(i.id), v.addEventListener("mousemove", c)
                    } catch (e) {
                        t.log("Could not add mouse listeners to dock: " + e)
                    }
                }
                var h = t.extend({}, s(), r);
                if ("FALSE" != h.align) {
                    var g, m, y, v, A, w = {},
                        E = [],
                        b = !1,
                        x = !1,
                        _ = {
                            x: 0,
                            y: 0,
                            width: 0,
                            height: 0
                        },
                        k = new e.html5.eventdispatcher;
                    t.extend(this, k);
                    var L = document.createElement("div");
                    L.id = i.id + "_jwplayer_dock", L.style.opacity = 1, f(), i.jwAddEventListener(e.api.events.JWPLAYER_PLAYER_STATE, u), this.getDisplayElement = function () {
                        return L
                    }, this.setButton = function (n, r, s, l) {
                        !r && w[n] ? (t.arrays.remove(E, n), L.removeChild(w[n].div), delete w[n]) : r && (w[n] || (w[n] = {}), w[n].handler = r, w[n].outGraphic = s, w[n].overGraphic = l, w[n].div || (E.push(n), w[n].div = document.createElement("div"), w[n].div.style.position = "absolute", L.appendChild(w[n].div), w[n].div.appendChild(document.createElement("div")), w[n].div.childNodes[0].style.position = "relative", w[n].div.childNodes[0].style.width = "100%", w[n].div.childNodes[0].style.height = "100%", w[n].div.childNodes[0].style.zIndex = 10, w[n].div.childNodes[0].style.cursor = "pointer", w[n].div.appendChild(document.createElement("img")), w[n].div.childNodes[1].style.position = "absolute", w[n].div.childNodes[1].style.left = 0, w[n].div.childNodes[1].style.top = 0, i.skin.getSkinElement("dock", "button") && (w[n].div.childNodes[1].src = i.skin.getSkinElement("dock", "button").src), w[n].div.childNodes[1].style.zIndex = 9, w[n].div.childNodes[1].style.cursor = "pointer", w[n].div.onmouseover = function () {
                            w[n].overGraphic && (w[n].div.childNodes[0].style.background = o(w[n].overGraphic)), i.skin.getSkinElement("dock", "buttonOver") && (w[n].div.childNodes[1].src = i.skin.getSkinElement("dock", "buttonOver").src)
                        }, w[n].div.onmouseout = function () {
                            w[n].outGraphic && (w[n].div.childNodes[0].style.background = o(w[n].outGraphic)), i.skin.getSkinElement("dock", "button") && (w[n].div.childNodes[1].src = i.skin.getSkinElement("dock", "button").src)
                        }, i.skin.getSkinElement("dock", "button") && (w[n].div.childNodes[1].src = i.skin.getSkinElement("dock", "button").src)), w[n].outGraphic ? w[n].div.childNodes[0].style.background = o(w[n].outGraphic) : w[n].overGraphic && (w[n].div.childNodes[0].style.background = o(w[n].overGraphic)), r && (w[n].div.onclick = function (t) {
                            t.preventDefault(), e(i.id).callback(n), w[n].overGraphic && (w[n].div.childNodes[0].style.background = o(w[n].overGraphic)), i.skin.getSkinElement("dock", "button") && (w[n].div.childNodes[1].src = i.skin.getSkinElement("dock", "button").src)
                        })), a(g, m)
                    };
                    var I = l(e.api.events.JWPLAYER_COMPONENT_SHOW),
                        S = l(e.api.events.JWPLAYER_COMPONENT_HIDE);
                    this.resize = a;
                    var j = function () {
                        n(L, {
                            display: "block"
                        }), b && (b = !1, I())
                    },
                        N = function () {
                            n(L, {
                                display: "none"
                            }), b || (S(), b = !0)
                        };
                    return this.hide = N, this.show = j, this
                }
            }
        }(jwplayer),
        function (e) {
            e.html5.eventdispatcher = function (t, n) {
                var i = new e.events.eventdispatcher(n);
                e.utils.extend(this, i), this.sendEvent = function (n, r) {
                    e.utils.exists(r) || (r = {}), e.utils.extend(r, {
                        id: t,
                        version: e.version,
                        type: n
                    }), i.sendEvent(n, r)
                }
            }
        }(jwplayer),
        function (e) {
            var t = e.utils;
            e.html5.instream = function (n, i, r, s) {
                function o() {
                    _fakemodel = new e.html5.model(this, N.getMedia() ? N.getMedia().getDisplayElement() : N.container, N), L = new e.html5.eventdispatcher, j.jwAddEventListener(e.api.events.JWPLAYER_RESIZE, h), j.jwAddEventListener(e.api.events.JWPLAYER_FULLSCREEN, h)
                }

                function a() {
                    _fakemodel.setMute(N.mute), _fakemodel.setVolume(N.volume)
                }

                function l() {
                    x || (x = new e.html5.mediavideo(_fakemodel, N.getMedia() ? N.getMedia().getDisplayElement() : N.container), x.addGlobalListener(u), x.addEventListener(e.api.events.JWPLAYER_MEDIA_META, p), x.addEventListener(e.api.events.JWPLAYER_MEDIA_COMPLETE, d), x.addEventListener(e.api.events.JWPLAYER_MEDIA_BUFFER_FULL, c)), x.attachMedia()
                }

                function u(e) {
                    P && f(e.type, e)
                }

                function c() {
                    P && x.play()
                }

                function d() {
                    P && setTimeout(function () {
                        C.jwInstreamDestroy(!0)
                    }, 10)
                }

                function p(e) {
                    e.metadata.width && e.metadata.height && R.resizeMedia()
                }

                function f(e, t, n) {
                    (P || n) && L.sendEvent(e, t)
                }

                function h() {
                    var e = N.plugins.object.display.getDisplayElement().style;
                    if (_) {
                        var n = N.plugins.object.controlbar.getDisplayElement().style;
                        _.resize(t.parseDimension(e.width), t.parseDimension(e.height)), _css(_.getDisplayElement(), t.extend({}, n, {
                            zIndex: 1001,
                            opacity: 1
                        }))
                    }
                    k && (k.resize(t.parseDimension(e.width), t.parseDimension(e.height)), _css(k.getDisplayElement(), t.extend({}, e, {
                        zIndex: 1e3
                    }))), R && R.resizeMedia()
                }
                var g, m, y, v, A, w, E, b, x, _, k, L, I, S = {
                    controlbarseekable: "always",
                    controlbarpausable: !0,
                    controlbarstoppable: !0,
                    playlistclickable: !0
                },
                    j = n,
                    N = i,
                    R = r,
                    T = s,
                    P = !1,
                    C = this;
                return this.load = function (n, i) {
                    if (a(), P = !0, m = t.extend(S, i), g = e.html5.playlistitem(n), l(), I = document.createElement("div"), I.id = C.id + "_instream_container", T.detachMedia(), y = x.getDisplayElement(), b = N.playlist[N.item], E = j.jwGetState(), E != e.api.events.state.BUFFERING && E != e.api.events.state.PLAYING || y.pause(), v = y.src ? y.src : y.currentSrc, A = y.innerHTML, w = y.currentTime, k = new e.html5.display(C, t.extend({}, N.plugins.config.display)), k.setAlternateClickHandler(function (t) {
                        _fakemodel.state == e.api.events.state.PAUSED ? C.jwInstreamPlay() : f(e.api.events.JWPLAYER_INSTREAM_CLICK, t)
                    }), I.appendChild(k.getDisplayElement()), !t.isMobile())
                        if (_ = new e.html5.controlbar(C, t.extend({}, N.plugins.config.controlbar, {})), N.plugins.config.controlbar.position == e.html5.view.positions.OVER) I.appendChild(_.getDisplayElement());
                        else {
                            var r = N.plugins.object.controlbar.getDisplayElement().parentNode;
                            r.appendChild(_.getDisplayElement())
                        }
                    R.setupInstream(I, y), h(), x.load(g)
                }, this.jwInstreamDestroy = function (t) {
                    if (P) {
                        if (P = !1, E != e.api.events.state.IDLE ? (x.load(b, !1), x.stop(!1)) : x.stop(!0), x.detachMedia(), R.destroyInstream(), _) try {
                            _.getDisplayElement().parentNode.removeChild(_.getDisplayElement())
                        } catch (n) { }
                        f(e.api.events.JWPLAYER_INSTREAM_DESTROYED, {
                            reason: t ? "complete" : "destroyed"
                        }, !0), T.attachMedia(), E != e.api.events.state.BUFFERING && E != e.api.events.state.PLAYING || (y.play(), N.playlist[N.item] == b && N.getMedia().seek(w))
                    }
                }, this.jwInstreamAddEventListener = function (e, t) {
                    L.addEventListener(e, t)
                }, this.jwInstreamRemoveEventListener = function (e, t) {
                    L.removeEventListener(e, t)
                }, this.jwInstreamPlay = function () {
                    P && x.play(!0)
                }, this.jwInstreamPause = function () {
                    P && x.pause(!0)
                }, this.jwInstreamSeek = function (e) {
                    P && x.seek(e)
                }, this.jwInstreamGetState = function () {
                    return P ? _fakemodel.state : void 0
                }, this.jwInstreamGetPosition = function () {
                    return P ? _fakemodel.position : void 0
                }, this.jwInstreamGetDuration = function () {
                    return P ? _fakemodel.duration : void 0
                }, this.playlistClickable = function () {
                    return !P || "true" == m.playlistclickable.toString().toLowerCase()
                }, this.jwPlay = function () {
                    "true" == m.controlbarpausable.toString().toLowerCase() && this.jwInstreamPlay()
                }, this.jwPause = function () {
                    "true" == m.controlbarpausable.toString().toLowerCase() && this.jwInstreamPause()
                }, this.jwStop = function () {
                    "true" == m.controlbarstoppable.toString().toLowerCase() && (this.jwInstreamDestroy(), j.jwStop())
                }, this.jwSeek = function (e) {
                    switch (m.controlbarseekable.toLowerCase()) {
                        case "always":
                            this.jwInstreamSeek(e);
                            break;
                        case "backwards":
                            _fakemodel.position > e && this.jwInstreamSeek(e)
                    }
                }, this.jwGetPosition = function () { }, this.jwGetDuration = function () { }, this.jwGetWidth = j.jwGetWidth, this.jwGetHeight = j.jwGetHeight, this.jwGetFullscreen = j.jwGetFullscreen, this.jwSetFullscreen = j.jwSetFullscreen, this.jwGetVolume = function () {
                    return N.volume
                }, this.jwSetVolume = function (e) {
                    x.volume(e), j.jwSetVolume(e)
                }, this.jwGetMute = function () {
                    return N.mute
                }, this.jwSetMute = function (e) {
                    x.mute(e), j.jwSetMute(e)
                }, this.jwGetState = function () {
                    return _fakemodel.state
                }, this.jwGetPlaylist = function () {
                    return [g]
                }, this.jwGetPlaylistIndex = function () {
                    return 0
                }, this.jwGetStretching = function () {
                    return N.config.stretching
                }, this.jwAddEventListener = function (e, t) {
                    L.addEventListener(e, t)
                }, this.jwRemoveEventListener = function (e, t) {
                    L.removeEventListener(e, t)
                }, this.skin = j.skin, this.id = j.id + "_instream", o(), this
            }
        }(jwplayer),
        function (e) {
            var t = {
                prefix: "",
                file: "",
                link: "",
                linktarget: "_top",
                margin: 8,
                out: .5,
                over: 1,
                timeout: 5,
                hide: !0,
                position: "bottom-left"
            };
            _css = e.utils.css, e.html5.logo = function (n, i) {
                function r() {
                    s(), v.jwAddEventListener(e.api.events.JWPLAYER_PLAYER_STATE, h), o(), a()
                }

                function s() {
                    if (t.prefix) {
                        var r = n.version.split(/\W/).splice(0, 2).join("/");
                        t.prefix.indexOf(r) < 0 && (t.prefix += r + "/")
                    }
                    i.position == e.html5.view.positions.OVER && (i.position = t.position);
                    try {
                        0 == window.location.href.indexOf("https") && (t.prefix = t.prefix.replace("http://l.longtailvideo.com", "https://securel.longtailvideo.com"))
                    } catch (s) { }
                    m = e.utils.extend({}, t, i)
                }

                function o() {
                    y = document.createElement("img"), y.id = v.id + "_jwplayer_logo", y.style.display = "none", y.onload = function () {
                        _css(y, d()), u()
                    }, m.file && (m.file.indexOf("/") >= 0 ? y.src = m.file : y.src = m.prefix + m.file)
                }

                function a() {
                    m.link ? (y.onmouseover = c, y.onmouseout = u, y.onclick = l) : this.mouseEnabled = !1
                }

                function l(e) {
                    "undefined" != typeof e && e.stopPropagation(), A && (v.jwPause(), v.jwSetFullscreen(!1), m.link && window.open(m.link, m.linktarget))
                }

                function u() {
                    m.link && A && (y.style.opacity = m.out)
                }

                function c() {
                    A && (y.style.opacity = m.over)
                }

                function d() {
                    var e = {
                        textDecoration: "none",
                        position: "absolute",
                        cursor: "pointer"
                    };
                    e.display = "true" != m.hide.toString() || A ? "block" : "none";
                    var t = m.position.toLowerCase().split("-");
                    for (var n in t) e[t[n]] = parseInt(m.margin);
                    return e
                }

                function p() {
                    "true" == m.hide.toString() && (y.style.display = "block", y.style.opacity = 0, e.utils.fadeTo(y, m.out, .1, parseFloat(y.style.opacity)), g = setTimeout(function () {
                        f()
                    }, 1e3 * m.timeout)), A = !0
                }

                function f() {
                    A = !1, "true" == m.hide.toString() && e.utils.fadeTo(y, 0, .1, parseFloat(y.style.opacity))
                }

                function h(t) {
                    t.newstate == e.api.events.state.BUFFERING && (clearTimeout(g), p())
                }
                var g, m, y, v = n,
                    A = !1;
                return r(), m.file ? (this.resize = function () { }, this.getDisplayElement = function () {
                    return y
                }, this) : void 0
            }
        }(jwplayer),
        function (e) {
            var t, n, i = {
                ended: e.api.events.state.IDLE,
                playing: e.api.events.state.PLAYING,
                pause: e.api.events.state.PAUSED,
                buffering: e.api.events.state.BUFFERING
            },
                r = e.utils,
                s = r.isMobile(),
                o = {};
            e.html5.mediavideo = function (a, l) {
                function u(e, t) {
                    return R[e] ? R[e] : (R[e] = function (e) {
                        r.exists(e.target.parentNode) && t(e)
                    }, R[e])
                }

                function c() {
                    C = e.api.events.state.IDLE, J = !0, P = d(), P.setAttribute("x-webkit-airplay", "allow"), U.parentNode && (P.id = U.id, U.parentNode.replaceChild(P, U))
                }

                function d() {
                    var e = o[G.id];
                    e || (e = "video" == U.tagName.toLowerCase() ? U : document.createElement("video"), o[G.id] = e, e.id || (e.id = U.id));
                    for (var t in N) e.addEventListener(t, u(t, N[t]), !0);
                    return e
                }

                function p(t) {
                    if (t != e.api.events.state.PAUSED || C != e.api.events.state.IDLE) {
                        if (s) switch (t) {
                            case e.api.events.state.PLAYING:
                                I();
                                break;
                            case e.api.events.state.BUFFERING:
                            case e.api.events.state.PAUSED:
                                S()
                        }
                        if (C != t) {
                            var n = C;
                            G.state = C = t, j(e.api.events.JWPLAYER_PLAYER_STATE, {
                                oldstate: n,
                                newstate: t
                            })
                        }
                    }
                }

                function f() { }

                function h() {
                    var t = Math.round(100 * P.volume);
                    j(e.api.events.JWPLAYER_MEDIA_VOLUME, {
                        volume: t
                    }, !0), j(e.api.events.JWPLAYER_MEDIA_MUTE, {
                        mute: P.muted
                    }, !0)
                }

                function g(t) {
                    if (J) {
                        var n;
                        if (r.exists(t) && t.lengthComputable && t.total) n = t.loaded / t.total * 100;
                        else if (r.exists(P.buffered) && P.buffered.length > 0) {
                            var i = P.buffered.length - 1;
                            i >= 0 && (n = P.buffered.end(i) / P.duration * 100)
                        }
                        r.useNativeFullscreen() && r.exists(P.webkitDisplayingFullscreen) && G.fullscreen != P.webkitDisplayingFullscreen && j(e.api.events.JWPLAYER_FULLSCREEN, {
                            fullscreen: P.webkitDisplayingFullscreen
                        }, !0), Y === !1 && C == e.api.events.state.BUFFERING && (j(e.api.events.JWPLAYER_MEDIA_BUFFER_FULL), Y = !0), F || (100 == n && (F = !0), r.exists(n) && n > G.buffer && (G.buffer = Math.round(n), j(e.api.events.JWPLAYER_MEDIA_BUFFER, {
                            bufferPercent: Math.round(n)
                        })))
                    }
                }

                function m(t) {
                    if (J) {
                        if (r.exists(t) && r.exists(t.target) && (V > 0 && !isNaN(t.target.duration) && (isNaN(G.duration) || G.duration < 1) && (t.target.duration == 1 / 0 ? G.duration = 0 : G.duration = Math.round(10 * t.target.duration) / 10), !D && P.readyState > 0 && p(e.api.events.state.PLAYING), C == e.api.events.state.PLAYING)) {
                            if (P.readyState > 0 && (B > -1 || !D)) {
                                D = !0;
                                try {
                                    P.currentTime != B && B > -1 && (P.currentTime = B, B = -1)
                                } catch (n) { }
                                P.volume = G.volume / 100, P.muted = G.mute
                            }
                            if (G.position = G.duration > 0 ? Math.round(10 * t.target.currentTime) / 10 : 0, j(e.api.events.JWPLAYER_MEDIA_TIME, {
                                position: G.position,
                                duration: G.duration
                            }), G.position >= G.duration && (G.position > 0 || G.duration > 0)) return void _()
                        }
                        g(t)
                    }
                }

                function y() { }

                function v(e) {
                    J && (t && n && (P.style.width = t, P.style.height = n, t = _previousHieght = 0), i[e.type] && ("ended" == e.type ? _() : p(i[e.type])))
                }

                function A() {
                    if (J) {
                        var t = Math.round(10 * P.duration) / 10,
                            n = {
                                height: P.videoHeight,
                                width: P.videoWidth,
                                duration: t
                            };
                        V || (G.duration < t || isNaN(G.duration)) && P.duration != 1 / 0 && (G.duration = t), j(e.api.events.JWPLAYER_MEDIA_META, {
                            metadata: n
                        })
                    }
                }

                function w(t) {
                    if (J && C != e.api.events.state.IDLE) {
                        var n = "There was an error: ";
                        if (t.target.error && "video" == t.target.tagName.toLowerCase() || t.target.parentNode.error && "video" == t.target.parentNode.tagName.toLowerCase()) {
                            var i = r.exists(t.target.error) ? t.target.error : t.target.parentNode.error;
                            switch (i.code) {
                                case i.MEDIA_ERR_ABORTED:
                                    return void r.log("User aborted the video playback.");
                                case i.MEDIA_ERR_NETWORK:
                                    n = "A network error caused the video download to fail part-way: ";
                                    break;
                                case i.MEDIA_ERR_DECODE:
                                    n = "The video playback was aborted due to a corruption problem or because the video used features your browser did not support: ";
                                    break;
                                case i.MEDIA_ERR_SRC_NOT_SUPPORTED:
                                    n = "The video could not be loaded, either because the server or network failed or because the format is not supported: ";
                                    break;
                                default:
                                    n = "An unknown error occurred: "
                            }
                        } else {
                            if ("source" != t.target.tagName.toLowerCase()) return void r.log("An unknown error occurred.  Continuing...");
                            if (W-- , W > 0) return;
                            if (r.userAgentMatch(/firefox/i)) return r.log("The video could not be loaded, either because the server or network failed or because the format is not supported."), void z(!1);
                            n = "The video could not be loaded, either because the server or network failed or because the format is not supported: "
                        }
                        z(!1), n += E(), _error = !0, j(e.api.events.JWPLAYER_ERROR, {
                            message: n
                        })
                    }
                }

                function E() {
                    var t = "";
                    for (var n in M.levels) {
                        var i = M.levels[n];
                        U.ownerDocument.createElement("source");
                        t += e.utils.getAbsolutePath(i.file), n < M.levels.length - 1 && (t += ", ")
                    }
                    return t
                }

                function b() {
                    r.exists(O) || (O = setInterval(function () {
                        g()
                    }, 100))
                }

                function x() {
                    clearInterval(O), O = null
                }

                function _() {
                    C == e.api.events.state.PLAYING && (z(!1), j(e.api.events.JWPLAYER_MEDIA_BEFORECOMPLETE), j(e.api.events.JWPLAYER_MEDIA_COMPLETE))
                }

                function k() {
                    r.exists(P.webkitDisplayingFullscreen) && G.fullscreen && !P.webkitDisplayingFullscreen && j(e.api.events.JWPLAYER_FULLSCREEN, {
                        fullscreen: !1
                    }, !0)
                }

                function L(e) {
                    if (e.length > 0 && r.userAgentMatch(/Safari/i) && !r.userAgentMatch(/Chrome/i)) {
                        for (var t = -1, n = 0; n < e.length; n++) switch (r.extension(e[n].file)) {
                            case "mp4":
                                0 > t && (t = n);
                                break;
                            case "webm":
                                e.splice(n, 1)
                        }
                        if (t > 0) {
                            var i = e.splice(t, 1)[0];
                            e.unshift(i)
                        }
                    }
                }

                function I() {
                    setTimeout(function () {
                        P.setAttribute("controls", "controls")
                    }, 100)
                }

                function S() {
                    setTimeout(function () {
                        P.removeAttribute("controls")
                    }, 250)
                }

                function j(e, t, n) {
                    (J || n) && (t ? T.sendEvent(e, t) : T.sendEvent(e))
                }
                var N = {
                    abort: f,
                    canplay: v,
                    canplaythrough: v,
                    durationchange: A,
                    emptied: f,
                    ended: v,
                    error: w,
                    loadeddata: A,
                    loadedmetadata: A,
                    loadstart: v,
                    pause: v,
                    play: f,
                    playing: v,
                    progress: g,
                    ratechange: f,
                    seeked: v,
                    seeking: v,
                    stalled: v,
                    suspend: v,
                    timeupdate: m,
                    volumechange: h,
                    waiting: v,
                    canshowcurrentframe: f,
                    dataunavailable: f,
                    empty: f,
                    load: y,
                    loadedfirstframe: f,
                    webkitfullscreenchange: k
                },
                    R = {},
                    T = new e.html5.eventdispatcher;
                r.extend(this, T);
                var P, C, D, M, O, B, F, Y, W, G = a,
                    U = l,
                    H = !1,
                    J = !1,
                    V = !1;
                c(), this.load = function (i, o) {
                    if ("undefined" == typeof o && (o = !0), J) {
                        if (M = i, V = M.duration > 0, G.duration = M.duration, r.empty(P), P.style.display = "block", P.style.opacity = 1, t && n && (P.style.width = t, P.style.height = n, t = _previousHieght = 0), W = 0, L(i.levels), i.levels && i.levels.length > 0)
                            if (1 == i.levels.length || r.isIOS()) P.src = i.levels[0].file;
                            else {
                                P.src && P.removeAttribute("src");
                                for (var a = 0; a < i.levels.length; a++) {
                                    var l = P.ownerDocument.createElement("source");
                                    l.src = i.levels[a].file, P.appendChild(l), W++
                                }
                            } else P.src = i.file;
                        P.volume = G.volume / 100, P.muted = G.mute, s && I(), F = Y = D = !1, G.buffer = 0, r.exists(i.start) || (i.start = 0), B = i.start > 0 ? i.start : -1, j(e.api.events.JWPLAYER_MEDIA_LOADED), (s || 1 != i.levels.length) && H || P.load(), H = !1, o && (p(e.api.events.state.BUFFERING), j(e.api.events.JWPLAYER_MEDIA_BUFFER, {
                            bufferPercent: 0
                        }), b()), P.videoWidth > 0 && P.videoHeight > 0 && A()
                    }
                }, this.play = function () {
                    J && (b(), Y ? p(e.api.events.state.PLAYING) : (P.load(), p(e.api.events.state.BUFFERING)), P.play())
                }, this.pause = function () {
                    J && (P.pause(), p(e.api.events.state.PAUSED))
                }, this.seek = function (e) {
                    J && (!D && P.readyState > 0 ? G.duration <= 0 || isNaN(G.duration) || G.position <= 0 || isNaN(G.position) || (P.currentTime = e, P.play()) : B = e)
                };
                var z = this.stop = function (i) {
                    if (J) {
                        if (r.exists(i) || (i = !0), x(), i) {
                            Y = !1;
                            navigator.userAgent;
                            if (P.webkitSupportsFullscreen) try {
                                P.webkitExitFullscreen()
                            } catch (s) { }
                            P.style.opacity = 0, S(), r.isIE() ? P.src = "" : P.removeAttribute("src"), r.empty(P), P.load(), H = !0
                        }
                        if (r.isIPod()) t = P.style.width, n = P.style.height, P.style.width = 0, P.style.height = 0;
                        else if (r.isIPad()) {
                            P.style.display = "none";
                            try {
                                P.webkitExitFullscreen()
                            } catch (o) { }
                        }
                        p(e.api.events.state.IDLE)
                    }
                };
                this.fullscreen = function (e) {
                    e === !0 ? this.resize("100%", "100%") : this.resize(G.config.width, G.config.height)
                }, this.resize = function () { }, this.volume = function (t) {
                    s || (P.volume = t / 100, j(e.api.events.JWPLAYER_MEDIA_VOLUME, {
                        volume: t / 100
                    }))
                }, this.mute = function (t) {
                    s || (P.muted = t, j(e.api.events.JWPLAYER_MEDIA_MUTE, {
                        mute: t
                    }))
                }, this.getDisplayElement = function () {
                    return P
                }, this.hasChrome = function () {
                    return s && C == e.api.events.state.PLAYING
                }, this.detachMedia = function () {
                    return J = !1, this.getDisplayElement()
                }, this.attachMedia = function () {
                    J = !0
                }, this.destroy = function () {
                    if (P && P.parentNode) {
                        x();
                        for (var e in N) P.removeEventListener(e, u(e, N[e]), !0);
                        r.empty(P), U = P.parentNode, P.parentNode.removeChild(P), delete o[G.id], P = null
                    }
                }
            }
        }(jwplayer),
        function (e) {
            var t = ({
                ended: e.api.events.state.IDLE,
                playing: e.api.events.state.PLAYING,
                pause: e.api.events.state.PAUSED,
                buffering: e.api.events.state.BUFFERING
            }, e.utils.css);
            e.html5.mediayoutube = function (n, i) {
                function r(t) {
                    if (p != t) {
                        var n = p;
                        c.state = t, p = t, a.sendEvent(e.api.events.JWPLAYER_PLAYER_STATE, {
                            oldstate: n,
                            newstate: t
                        })
                    }
                }

                function s(e) {
                    var t = e.levels[0].file;
                    t = ["http://www.youtube.com/v/", o(t), "&amp;hl=en_US&amp;fs=1&autoplay=1"].join(""), l = document.createElement("object"), l.id = d.id, l.style.position = "absolute";
                    var n = {
                        movie: t,
                        allowfullscreen: "true",
                        allowscriptaccess: "always"
                    };
                    for (var i in n) {
                        var r = document.createElement("param");
                        r.name = i, r.value = n[i], l.appendChild(r)
                    }
                    u = document.createElement("embed"), l.appendChild(u);
                    var s = {
                        src: t,
                        type: "application/x-shockwave-flash",
                        allowfullscreen: "true",
                        allowscriptaccess: "always",
                        width: l.width,
                        height: l.height
                    };
                    for (var a in s) u.setAttribute(a, s[a]);
                    l.appendChild(u), l.style.zIndex = 2147483e3, d != l && d.parentNode && d.parentNode.replaceChild(l, d), d = l
                }

                function o(e) {
                    for (var t = e.split(/\?|\#\!/), n = "", i = 0; i < t.length; i++) "v=" == t[i].substr(0, 2) && (n = t[i].substr(2));
                    return "" == n && (n = e.indexOf("/v/") >= 0 ? e.substr(e.indexOf("/v/") + 3) : e.indexOf("youtu.be") >= 0 ? e.substr(e.indexOf("youtu.be/") + 9) : e), n.indexOf("?") > -1 && (n = n.substr(0, n.indexOf("?"))), n.indexOf("&") > -1 && (n = n.substr(0, n.indexOf("&"))), n
                }
                var a = new e.html5.eventdispatcher;
                e.utils.extend(this, a);
                var l, u, c = n,
                    d = document.getElementById(i.id),
                    p = e.api.events.state.IDLE;
                return this.getDisplayElement = this.detachMedia = function () {
                    return d
                }, this.attachMedia = function () { }, this.play = function () {
                    p == e.api.events.state.IDLE ? (a.sendEvent(e.api.events.JWPLAYER_MEDIA_BUFFER, {
                        bufferPercent: 100
                    }), a.sendEvent(e.api.events.JWPLAYER_MEDIA_BUFFER_FULL), r(e.api.events.state.PLAYING)) : p == e.api.events.state.PAUSED && r(e.api.events.state.PLAYING)
                }, this.pause = function () {
                    r(e.api.events.state.PAUSED)
                }, this.seek = function () { }, this.stop = function (n) {
                    _utils.exists(n) || (n = !0), c.position = 0, r(e.api.events.state.IDLE), n && t(d, {
                        display: "none"
                    })
                }, this.volume = function (t) {
                    c.setVolume(t), a.sendEvent(e.api.events.JWPLAYER_MEDIA_VOLUME, {
                        volume: Math.round(t)
                    })
                }, this.mute = function (t) {
                    d.muted = t, a.sendEvent(e.api.events.JWPLAYER_MEDIA_MUTE, {
                        mute: t
                    })
                }, this.resize = function (e, t) {
                    e * t > 0 && l && (l.width = u.width = e, l.height = u.height = t)
                }, this.fullscreen = function (e) {
                    e === !0 ? this.resize("100%", "100%") : this.resize(c.config.width, c.config.height)
                }, this.load = function (n) {
                    s(n), t(l, {
                        display: "block"
                    }), r(e.api.events.state.BUFFERING), a.sendEvent(e.api.events.JWPLAYER_MEDIA_BUFFER, {
                        bufferPercent: 0
                    }), a.sendEvent(e.api.events.JWPLAYER_MEDIA_LOADED), this.play()
                }, this.hasChrome = function () {
                    return p != e.api.events.state.IDLE
                }, this.embed = u, this
            }
        }(jwplayer),
        function (jwplayer) {
            var _configurableStateVariables = ["width", "height", "start", "duration", "volume", "mute", "fullscreen", "item", "plugins", "stretching"],
                _utils = jwplayer.utils;
            jwplayer.html5.model = function (api, container, options) {
                function _loadExternal(e) {
                    var t = new jwplayer.html5.playlistloader;
                    t.addEventListener(jwplayer.api.events.JWPLAYER_PLAYLIST_LOADED, function (e) {
                        _model.playlist = new jwplayer.html5.playlist(e), _loadComplete(!0)
                    }), t.addEventListener(jwplayer.api.events.JWPLAYER_ERROR, function () {
                        _model.playlist = new jwplayer.html5.playlist({
                            playlist: []
                        }), _loadComplete(!1)
                    }), t.load(e)
                }

                function _loadComplete() {
                    _model.config.shuffle ? _model.item = _getShuffleItem() : (_model.config.item >= _model.playlist.length ? _model.config.item = _model.playlist.length - 1 : _model.config.item < 0 && (_model.config.item = 0), _model.item = _model.config.item), _model.position = 0, _model.duration = _model.playlist.length > 0 ? _model.playlist[_model.item].duration : 0, _eventDispatcher.sendEvent(jwplayer.api.events.JWPLAYER_PLAYLIST_LOADED, {
                        playlist: _model.playlist
                    }), _eventDispatcher.sendEvent(jwplayer.api.events.JWPLAYER_PLAYLIST_ITEM, {
                        index: _model.item
                    })
                }

                function _getShuffleItem() {
                    var e = null;
                    if (_model.playlist.length > 1)
                        for (; !jwplayer.utils.exists(e);) e = Math.floor(Math.random() * _model.playlist.length), e == _model.item && (e = null);
                    else e = 0;
                    return e
                }

                function forward(e) {
                    switch (e.type) {
                        case jwplayer.api.events.JWPLAYER_MEDIA_LOADED:
                            _container = _media.getDisplayElement();
                            break;
                        case jwplayer.api.events.JWPLAYER_MEDIA_MUTE:
                            this.mute = e.mute;
                            break;
                        case jwplayer.api.events.JWPLAYER_MEDIA_VOLUME:
                            this.volume = e.volume
                    }
                    _eventDispatcher.sendEvent(e.type, e)
                }
                var _api = api,
                    _container = container,
                    _cookies = _utils.getCookies(),
                    _model = {
                        id: _container.id,
                        playlist: [],
                        state: jwplayer.api.events.state.IDLE,
                        position: 0,
                        buffer: 0,
                        container: _container,
                        config: {
                            width: 480,
                            height: 320,
                            item: -1,
                            skin: void 0,
                            file: void 0,
                            image: void 0,
                            start: 0,
                            duration: 0,
                            bufferlength: 5,
                            volume: _cookies.volume ? _cookies.volume : 90,
                            mute: !(!_cookies.mute || "true" != _cookies.mute.toString().toLowerCase()),
                            fullscreen: !1,
                            repeat: "",
                            stretching: jwplayer.utils.stretching.UNIFORM,
                            autostart: !1,
                            debug: void 0,
                            screencolor: void 0
                        }
                    },
                    _media, _eventDispatcher = new jwplayer.html5.eventdispatcher,
                    _components = ["display", "logo", "controlbar", "playlist", "dock"];
                jwplayer.utils.extend(_model, _eventDispatcher);
                for (var option in options) {
                    if ("string" == typeof options[option]) {
                        var type = /color$/.test(option) ? "color" : null;
                        options[option] = jwplayer.utils.typechecker(options[option], type)
                    }
                    var config = _model.config,
                        path = option.split(".");
                    for (var edge in path) edge == path.length - 1 ? config[path[edge]] = options[option] : (jwplayer.utils.exists(config[path[edge]]) || (config[path[edge]] = {}), config = config[path[edge]])
                }
                for (var index in _configurableStateVariables) {
                    var configurableStateVariable = _configurableStateVariables[index];
                    _model[configurableStateVariable] = _model.config[configurableStateVariable]
                }
                var pluginorder = _components.concat([]);
                if (jwplayer.utils.exists(_model.plugins) && "string" == typeof _model.plugins) {
                    var userplugins = _model.plugins.split(",");
                    for (var userplugin in userplugins) "string" == typeof userplugins[userplugin] && pluginorder.push(userplugins[userplugin].replace(/^\s+|\s+$/g, ""))
                }
                if (jwplayer.utils.isMobile() ? (pluginorder = ["display", "logo", "dock", "playlist"], jwplayer.utils.exists(_model.config.repeat) || (_model.config.repeat = "list")) : _model.config.chromeless && (pluginorder = ["logo", "dock", "playlist"], jwplayer.utils.exists(_model.config.repeat) || (_model.config.repeat = "list")), _model.plugins = {
                    order: pluginorder,
                    config: {},
                    object: {}
                }, "undefined" != typeof _model.config.components)
                    for (var component in _model.config.components) _model.plugins.config[component] = _model.config.components[component];
                var playlistVisible = !1;
                for (var pluginIndex in _model.plugins.order) {
                    var pluginName = _model.plugins.order[pluginIndex],
                        pluginConfig = jwplayer.utils.exists(_model.plugins.config[pluginName]) ? _model.plugins.config[pluginName] : {};
                    _model.plugins.config[pluginName] = jwplayer.utils.exists(_model.plugins.config[pluginName]) ? jwplayer.utils.extend(_model.plugins.config[pluginName], pluginConfig) : pluginConfig, jwplayer.utils.exists(_model.plugins.config[pluginName].position) ? ("playlist" == pluginName && (playlistVisible = !0), _model.plugins.config[pluginName].position = _model.plugins.config[pluginName].position.toString().toUpperCase()) : "playlist" == pluginName ? _model.plugins.config[pluginName].position = jwplayer.html5.view.positions.NONE : _model.plugins.config[pluginName].position = jwplayer.html5.view.positions.OVER
                }
                if (_model.plugins.config.controlbar && playlistVisible && (_model.plugins.config.controlbar.hideplaylistcontrols = !0), "undefined" != typeof _model.plugins.config.dock) {
                    if ("object" != typeof _model.plugins.config.dock) {
                        var position = _model.plugins.config.dock.toString().toUpperCase();
                        _model.plugins.config.dock = {
                            position: position
                        }
                    }
                    if ("undefined" != typeof _model.plugins.config.dock.position && (_model.plugins.config.dock.align = _model.plugins.config.dock.position, _model.plugins.config.dock.position = jwplayer.html5.view.positions.OVER),
                        "undefined" == typeof _model.plugins.config.dock.idlehide) try {
                            _model.plugins.config.dock.idlehide = _model.plugins.config.controlbar.idlehide
                        } catch (e) { }
                }
                _model.loadPlaylist = function (arg) {
                    var input;
                    if ("string" == typeof arg)
                        if (0 == arg.indexOf("[") || "0" == arg.indexOf("{")) try {
                            input = eval(arg)
                        } catch (err) {
                            input = arg
                        } else input = arg;
                    else input = arg;
                    var config;
                    switch (jwplayer.utils.typeOf(input)) {
                        case "object":
                            config = input;
                            break;
                        case "array":
                            config = {
                                playlist: input
                            };
                            break;
                        default:
                            config = {
                                file: input
                            }
                    }
                    _model.playlist = new jwplayer.html5.playlist(config), _model.item = _model.config.item >= 0 ? _model.config.item : 0, !_model.playlist[0].provider && _model.playlist[0].file ? _loadExternal(_model.playlist[0].file) : _loadComplete()
                };
                var _mediaProviders = {};
                return _model.setActiveMediaProvider = function (e) {
                    "audio" == e.provider && (e.provider = "sound");
                    var t = e.provider,
                        n = _media ? _media.getDisplayElement() : null;
                    if ("sound" != t && "http" != t && "" != t || (t = "video"), jwplayer.utils.exists(_mediaProviders[t])) _media != _mediaProviders[t] && (_media && _media.stop(), _media = _mediaProviders[t]);
                    else {
                        switch (t) {
                            case "video":
                                _media = new jwplayer.html5.mediavideo(_model, n ? n : _container);
                                break;
                            case "youtube":
                                _media = new jwplayer.html5.mediayoutube(_model, n ? n : _container)
                        }
                        if (!jwplayer.utils.exists(_media)) return !1;
                        _media.addGlobalListener(forward), _mediaProviders[t] = _media
                    }
                    return !0
                }, _model.getMedia = function () {
                    return _media
                }, _model.seek = function (e) {
                    return _eventDispatcher.sendEvent(jwplayer.api.events.JWPLAYER_MEDIA_SEEK, {
                        position: _model.position,
                        offset: e
                    }), _media.seek(e)
                }, _model.setVolume = function (e) {
                    _utils.saveCookie("volume", e), _model.volume = e
                }, _model.setMute = function (e) {
                    _utils.saveCookie("mute", e), _model.mute = e
                }, _model.setupPlugins = function () {
                    if (!jwplayer.utils.exists(_model.plugins) || !jwplayer.utils.exists(_model.plugins.order) || 0 == _model.plugins.order.length) return jwplayer.utils.log("No plugins to set up"), _model;
                    for (var e = 0; e < _model.plugins.order.length; e++) try {
                        var t = _model.plugins.order[e];
                        jwplayer.utils.exists(jwplayer.html5[t]) ? "playlist" == t ? _model.plugins.object[t] = new jwplayer.html5.playlistcomponent(_api, _model.plugins.config[t]) : _model.plugins.object[t] = new jwplayer.html5[t](_api, _model.plugins.config[t]) : _model.plugins.order.splice(plugin, plugin + 1), "function" == typeof _model.plugins.object[t].addGlobalListener && _model.plugins.object[t].addGlobalListener(forward)
                    } catch (n) {
                        jwplayer.utils.log("Could not setup " + t)
                    }
                }, _model
            }
        }(jwplayer),
        function (e) {
            e.html5.playlist = function (t) {
                var n = [];
                if (t.playlist && t.playlist instanceof Array && t.playlist.length > 0)
                    for (var i in t.playlist) isNaN(parseInt(i)) || n.push(new e.html5.playlistitem(t.playlist[i]));
                else n.push(new e.html5.playlistitem(t));
                return n
            }
        }(jwplayer),
        function (e) {
            var t = {
                size: 180,
                position: e.html5.view.positions.NONE,
                itemheight: 60,
                thumbs: !0,
                fontcolor: "#000000",
                overcolor: "",
                activecolor: "",
                backgroundcolor: "#f8f8f8",
                font: "_sans",
                fontsize: "",
                fontstyle: "",
                fontweight: ""
            },
                n = {
                    _sans: "Arial, Helvetica, sans-serif",
                    _serif: "Times, Times New Roman, serif",
                    _typewriter: "Courier New, Courier, monospace"
                };
            _utils = e.utils, _css = _utils.css, _hide = function (e) {
                _css(e, {
                    display: "none"
                })
            }, _show = function (e) {
                _css(e, {
                    display: "block"
                })
            }, e.html5.playlistcomponent = function (i, r) {
                function s() {
                    switch (E = document.createElement("div"), E.id = A.id + "_jwplayer_playlistcomponent", E.setAttribute("class", "jwplayer-playlist-box"), E.style.overflow = "hidden", w.position) {
                        case e.html5.view.positions.RIGHT:
                        case e.html5.view.positions.LEFT:
                            E.style.width = w.size + "px";
                            break;
                        case e.html5.view.positions.TOP:
                        case e.html5.view.positions.BOTTOM:
                            E.style.height = w.size + "px"
                    }
                    y(), I.item && (w.itemheight = I.item.height), E.style.backgroundColor = "#C6C6C6", A.jwAddEventListener(e.api.events.JWPLAYER_PLAYLIST_LOADED, c), A.jwAddEventListener(e.api.events.JWPLAYER_PLAYLIST_ITEM, g), A.jwAddEventListener(e.api.events.JWPLAYER_PLAYER_STATE, m)
                }

                function o() {
                    var e = document.createElement("ul");
                    return _css(e, {
                        width: E.style.width,
                        minWidth: E.style.width,
                        height: E.style.height,
                        backgroundColor: w.backgroundcolor,
                        backgroundImage: I.background ? "url(" + I.background.src + ")" : "",
                        color: w.fontcolor,
                        listStyle: "none",
                        margin: 0,
                        padding: 0,
                        fontFamily: n[w.font] ? n[w.font] : n._sans,
                        fontSize: (w.fontsize ? w.fontsize : 11) + "px",
                        fontStyle: w.fontstyle,
                        fontWeight: w.fontweight,
                        overflowY: "auto"
                    }), e
                }

                function a(e) {
                    return function () {
                        var t = k.getElementsByClassName("item")[e],
                            n = w.fontcolor,
                            i = I.item ? "url(" + I.item.src + ")" : "";
                        e == A.jwGetPlaylistIndex() && ("" !== w.activecolor && (n = w.activecolor), I.itemActive && (i = "url(" + I.itemActive.src + ")")), _css(t, {
                            color: "" !== w.overcolor ? w.overcolor : n,
                            backgroundImage: I.itemOver ? "url(" + I.itemOver.src + ")" : i
                        })
                    }
                }

                function l(e) {
                    return function () {
                        var t = k.getElementsByClassName("item")[e],
                            n = w.fontcolor,
                            i = I.item ? "url(" + I.item.src + ")" : "";
                        e == A.jwGetPlaylistIndex() && ("" !== w.activecolor && (n = w.activecolor), I.itemActive && (i = "url(" + I.itemActive.src + ")")), _css(t, {
                            color: n,
                            backgroundImage: i
                        })
                    }
                }

                function u(t) {
                    var n = _[t],
                        i = document.createElement("li");
                    i.className = "item", _css(i, {
                        height: w.itemheight,
                        display: "block",
                        cursor: "pointer",
                        backgroundImage: I.item ? "url(" + I.item.src + ")" : "",
                        backgroundSize: "100% " + w.itemheight + "px"
                    }), i.onmouseover = a(t), i.onmouseout = l(t);
                    var r = document.createElement("div"),
                        s = new Image,
                        o = 0,
                        u = 0,
                        c = 0;
                    h() && (n.image || n["playlist.image"] || I.itemImage) && (s.className = "image", I.itemImage ? (o = (w.itemheight - I.itemImage.height) / 2, u = I.itemImage.width, c = I.itemImage.height) : (u = 4 * w.itemheight / 3, c = w.itemheight), _css(r, {
                        height: c,
                        width: u,
                        "float": "left",
                        styleFloat: "left",
                        cssFloat: "left",
                        margin: "0 5px 0 0",
                        background: "black",
                        overflow: "hidden",
                        margin: o + "px",
                        position: "relative"
                    }), _css(s, {
                        position: "relative"
                    }), r.appendChild(s), s.onload = function () {
                        e.utils.stretch(e.utils.stretching.FILL, s, u, c, this.naturalWidth, this.naturalHeight)
                    }, n["playlist.image"] ? s.src = n["playlist.image"] : n.image ? s.src = n.image : I.itemImage && (s.src = I.itemImage.src), i.appendChild(r));
                    var d = b - u - 2 * o;
                    x < w.itemheight * _.length && (d -= 15);
                    var p = document.createElement("div");
                    _css(p, {
                        position: "relative",
                        height: "100%",
                        overflow: "hidden"
                    });
                    var f = document.createElement("span");
                    n.duration > 0 && (f.className = "duration", _css(f, {
                        fontSize: (w.fontsize ? w.fontsize : 11) + "px",
                        fontWeight: w.fontweight ? w.fontweight : "bold",
                        width: "40px",
                        height: w.fontsize ? w.fontsize + 10 : 20,
                        lineHeight: 24,
                        "float": "right",
                        styleFloat: "right",
                        cssFloat: "right"
                    }), f.innerHTML = _utils.timeFormat(n.duration), p.appendChild(f));
                    var g = document.createElement("span");
                    if (g.className = "title", _css(g, {
                        width: (n.duration > 0 ? d - 50 : d) - 10 + "px"
                    }), g.innerHTML = n ? n.title : "", p.appendChild(g), n.description) {
                        var m = document.createElement("span");
                        m.className = "description", _css(m, {}), m.innerHTML = n.description, p.appendChild(m)
                    }
                    return i.appendChild(p), i
                }

                function c() {
                    if (E.innerHTML = "", _ = d()) {
                        items = [], k = o();
                        for (var e = 0; e < _.length; e++) {
                            var t = u(e);
                            t.onclick = p(e), k.appendChild(t), items.push(t)
                        }
                        if (L = A.jwGetPlaylistIndex(), l(L)(), E.appendChild(k), _utils.isIOS() && window.iScroll) {
                            k.style.height = w.itemheight * _.length + "px";
                            new iScroll(E.id)
                        }
                    }
                }

                function d() {
                    for (var e = A.jwGetPlaylist(), t = [], n = 0; n < e.length; n++) e[n]["ova.hidden"] || t.push(e[n]);
                    return t
                }

                function p(e) {
                    return function () {
                        A.jwPlaylistItem(e), A.jwPlay(!0)
                    }
                }

                function f() {
                    k.scrollTop = A.jwGetPlaylistIndex() * w.itemheight
                }

                function h() {
                    return "true" == w.thumbs.toString().toLowerCase()
                }

                function g(e) {
                    L >= 0 && (l(L)(), L = e.index), l(e.index)(), f()
                }

                function m() {
                    if (w.position == e.html5.view.positions.OVER) switch (A.jwGetState()) {
                        case e.api.events.state.IDLE:
                            _show(E);
                            break;
                        default:
                            _hide(E)
                    }
                }

                function y() {
                    for (var e in I) I[e] = v(e)
                }

                function v(e) {
                    return A.skin.getSkinElement("playlist", e)
                }
                var A = i,
                    w = e.utils.extend({}, t, A.skin.getComponentSettings("playlist"), r);
                if (w.position != e.html5.view.positions.NONE && "undefined" != typeof e.html5.view.positions[w.position]) {
                    var E, b, x, _, k, L = -1,
                        I = {
                            background: void 0,
                            item: void 0,
                            itemOver: void 0,
                            itemImage: void 0,
                            itemActive: void 0
                        };
                    return this.getDisplayElement = function () {
                        return E
                    }, this.resize = function (e, t) {
                        if (b = e, x = t, A.jwGetFullscreen()) _hide(E);
                        else {
                            var n = {
                                display: "block",
                                width: b,
                                height: x
                            };
                            _css(E, n)
                        }
                    }, this.show = function () {
                        _show(E)
                    }, this.hide = function () {
                        _hide(E)
                    }, s(), this
                }
            }
        }(jwplayer),
        function (e) {
            function t(t) {
                if (e.utils.isYouTube(t.file)) return "youtube";
                var n, i = e.utils.extension(t.file);
                if (i && e.utils.extensionmap[i]) {
                    if ("m3u8" == i) return "video";
                    n = e.utils.extensionmap[i].html5
                } else t.type && (n = t.type);
                if (n) {
                    var r = n.split("/")[0];
                    if ("audio" == r) return "sound";
                    if ("video" == r) return r
                }
                return ""
            }
            e.html5.playlistitem = function (n) {
                var i = {
                    author: "",
                    date: "",
                    description: "",
                    image: "",
                    link: "",
                    mediaid: "",
                    tags: "",
                    title: "",
                    provider: "",
                    file: "",
                    streamer: "",
                    duration: -1,
                    start: 0,
                    currentLevel: -1,
                    levels: []
                },
                    r = e.utils.extend({}, i, n);
                return r.type && (r.provider = r.type, delete r.type), 0 === r.levels.length && (r.levels[0] = new e.html5.playlistitemlevel(r)), r.provider ? r.provider = r.provider.toLowerCase() : r.provider = t(r.levels[0]), r
            }
        }(jwplayer),
        function (e) {
            e.html5.playlistitemlevel = function (t) {
                var n = {
                    file: "",
                    streamer: "",
                    bitrate: 0,
                    width: 0
                };
                for (var i in n) e.utils.exists(t[i]) && (n[i] = t[i]);
                return n
            }
        }(jwplayer),
        function (e) {
            e.html5.playlistloader = function () {
                function t(t) {
                    var r = [];
                    try {
                        var r = e.utils.parsers.rssparser.parse(t.responseXML.firstChild);
                        i.sendEvent(e.api.events.JWPLAYER_PLAYLIST_LOADED, {
                            playlist: new e.html5.playlist({
                                playlist: r
                            })
                        })
                    } catch (s) {
                        n("Could not parse the playlist")
                    }
                }

                function n(t) {
                    i.sendEvent(e.api.events.JWPLAYER_ERROR, {
                        message: t ? t : "Could not load playlist an unknown reason."
                    })
                }
                var i = new e.html5.eventdispatcher;
                e.utils.extend(this, i), this.load = function (i) {
                    e.utils.ajax(i, t, n)
                }
            }
        }(jwplayer),
        function (e) {
            e.html5.skin = function () {
                var t = {},
                    n = !1;
                this.load = function (i, r) {
                    new e.html5.skinloader(i, function (e) {
                        n = !0, t = e, r()
                    }, function () {
                        new e.html5.skinloader("", function (e) {
                            n = !0, t = e, r()
                        })
                    })
                }, this.getSkinElement = function (i, r) {
                    if (n) try {
                        return t[i].elements[r]
                    } catch (s) {
                        e.utils.log("No such skin component / element: ", [i, r])
                    }
                    return null
                }, this.getComponentSettings = function (e) {
                    return n && t && t[e] ? t[e].settings : null
                }, this.getComponentLayout = function (e) {
                    return n ? t[e].layout : null
                }
            }
        }(jwplayer),
        function (e) {
            e.html5.skinloader = function (t, n, i) {
                function r() {
                    "string" != typeof m || "" === m ? s(e.html5.defaultSkin().xml) : e.utils.ajax(e.utils.getAbsolutePath(m), function (t) {
                        try {
                            if (e.utils.exists(t.responseXML)) return void s(t.responseXML)
                        } catch (n) {
                            l()
                        }
                        s(e.html5.defaultSkin().xml)
                    }, function () {
                        s(e.html5.defaultSkin().xml)
                    })
                }

                function s(t) {
                    var n = t.getElementsByTagName("component");
                    if (0 !== n.length)
                        for (var i = 0; i < n.length; i++) {
                            var r = n[i].getAttribute("name"),
                                s = {
                                    settings: {},
                                    elements: {},
                                    layout: {}
                                };
                            p[r] = s;
                            for (var l = n[i].getElementsByTagName("elements")[0].getElementsByTagName("element"), u = 0; u < l.length; u++) a(l[u], r);
                            var c = n[i].getElementsByTagName("settings")[0];
                            if (c && c.childNodes.length > 0)
                                for (var d = c.getElementsByTagName("setting"), f = 0; f < d.length; f++) {
                                    var h = d[f].getAttribute("name"),
                                        m = d[f].getAttribute("value"),
                                        y = /color$/.test(h) ? "color" : null;
                                    p[r].settings[h] = e.utils.typechecker(m, y)
                                }
                            var v = n[i].getElementsByTagName("layout")[0];
                            if (v && v.childNodes.length > 0)
                                for (var A = v.getElementsByTagName("group"), w = 0; w < A.length; w++) {
                                    var E = A[w];
                                    p[r].layout[E.getAttribute("position")] = {
                                        elements: []
                                    };
                                    for (var b = 0; b < E.attributes.length; b++) {
                                        var x = E.attributes[b];
                                        p[r].layout[E.getAttribute("position")][x.name] = x.value
                                    }
                                    for (var _ = E.getElementsByTagName("*"), k = 0; k < _.length; k++) {
                                        var L = _[k];
                                        p[r].layout[E.getAttribute("position")].elements.push({
                                            type: L.tagName
                                        });
                                        for (var I = 0; I < L.attributes.length; I++) {
                                            var S = L.attributes[I];
                                            p[r].layout[E.getAttribute("position")].elements[k][S.name] = S.value
                                        }
                                        e.utils.exists(p[r].layout[E.getAttribute("position")].elements[k].name) || (p[r].layout[E.getAttribute("position")].elements[k].name = L.tagName)
                                    }
                                }
                            g = !1, o()
                        }
                }

                function o() {
                    clearInterval(d), y || (d = setInterval(function () {
                        u()
                    }, 100))
                }

                function a(t, n) {
                    var i, r = new Image,
                        s = t.getAttribute("name"),
                        a = t.getAttribute("src");
                    if (0 === a.indexOf("data:image/png;base64,")) i = a;
                    else {
                        var l = e.utils.getAbsolutePath(m),
                            u = l.substr(0, l.lastIndexOf("/"));
                        i = [u, n, a].join("/")
                    }
                    p[n].elements[s] = {
                        height: 0,
                        width: 0,
                        src: "",
                        ready: !1,
                        image: r
                    }, r.onload = function () {
                        c(r, s, n)
                    }, r.onerror = function () {
                        y = !0, o(), h()
                    }, r.src = i
                }

                function l() {
                    for (var e in p) {
                        var t = p[e];
                        for (var n in t.elements) {
                            var i = t.elements[n],
                                r = i.image;
                            r.onload = null, r.onerror = null, delete i.image, delete t.elements[n]
                        }
                        delete p[e]
                    }
                }

                function u() {
                    for (var e in p)
                        if ("properties" != e)
                            for (var t in p[e].elements)
                                if (!p[e].elements[t].ready) return;
                    g === !1 && (clearInterval(d), f(p))
                }

                function c(t, n, i) {
                    p[i] && p[i].elements[n] ? (p[i].elements[n].height = t.height, p[i].elements[n].width = t.width, p[i].elements[n].src = t.src, p[i].elements[n].ready = !0, o()) : e.utils.log("Loaded an image for a missing element: " + i + "." + n)
                }
                var d, p = {},
                    f = n,
                    h = i,
                    g = !0,
                    m = t,
                    y = !1;
                r()
            }
        }(jwplayer),
        function (e) {
            e.html5.api = function (t, n) {
                function i() {
                    d.state == e.api.events.state.PLAYING || d.state == e.api.events.state.BUFFERING ? f.pause() : f.play()
                }

                function r(e) {
                    return function () {
                        return d[e]
                    }
                }

                function s(e, t, n) {
                    return function () {
                        var i = d.plugins.object[e];
                        i && i[t] && "function" == typeof i[t] && i[t].apply(i, n)
                    }
                }

                function o(e) {
                    return function () {
                        return h && "function" == typeof h[e] ? h[e].apply(this, arguments) : void _utils.log("Could not call instream method - instream API not initialized")
                    }
                }

                function a() {
                    d.config.playlistfile ? (d.addEventListener(e.api.events.JWPLAYER_PLAYLIST_LOADED, l), d.loadPlaylist(d.config.playlistfile)) : "string" == typeof d.config.playlist ? (d.addEventListener(e.api.events.JWPLAYER_PLAYLIST_LOADED, l), d.loadPlaylist(d.config.playlist)) : (d.loadPlaylist(d.config), setTimeout(l, 25))
                }

                function l(t) {
                    d.removeEventListener(e.api.events.JWPLAYER_PLAYLIST_LOADED, l), d.setupPlugins(), p.setup();
                    var t = {
                        id: u.id,
                        version: u.version
                    };
                    f.playerReady(t)
                }
                var u = {},
                    c = document.createElement("div");
                t.parentNode.replaceChild(c, t), c.id = t.id, u.version = e.version, u.id = c.id;
                var d = new e.html5.model(u, c, n),
                    p = new e.html5.view(u, c, d),
                    f = new e.html5.controller(u, c, d, p);
                u.skin = new e.html5.skin, u.jwPlay = function (e) {
                    "undefined" == typeof e ? i() : "true" == e.toString().toLowerCase() ? f.play() : f.pause()
                }, u.jwPause = function (e) {
                    "undefined" == typeof e ? i() : "true" == e.toString().toLowerCase() ? f.pause() : f.play()
                }, u.jwStop = f.stop, u.jwSeek = f.seek, u.jwPlaylistItem = function (e) {
                    return h ? h.playlistClickable() ? (h.jwInstreamDestroy(), f.item(e)) : void 0 : f.item(e)
                }, u.jwPlaylistNext = f.next, u.jwPlaylistPrev = f.prev, u.jwResize = f.resize, u.jwLoad = f.load, u.jwDetachMedia = f.detachMedia, u.jwAttachMedia = f.attachMedia, u.jwGetPlaylistIndex = r("item"), u.jwGetPosition = r("position"), u.jwGetDuration = r("duration"), u.jwGetBuffer = r("buffer"), u.jwGetWidth = r("width"), u.jwGetHeight = r("height"), u.jwGetFullscreen = r("fullscreen"), u.jwSetFullscreen = f.setFullscreen, u.jwGetVolume = r("volume"), u.jwSetVolume = f.setVolume, u.jwGetMute = r("mute"), u.jwSetMute = f.setMute, u.jwGetStretching = function () {
                    return d.stretching.toUpperCase()
                }, u.jwGetState = r("state"), u.jwGetVersion = function () {
                    return u.version
                }, u.jwGetPlaylist = function () {
                    return d.playlist
                }, u.jwAddEventListener = f.addEventListener, u.jwRemoveEventListener = f.removeEventListener, u.jwSendEvent = f.sendEvent, u.jwDockSetButton = function (e, t, n, i) {
                    d.plugins.object.dock && d.plugins.object.dock.setButton && d.plugins.object.dock.setButton(e, t, n, i)
                }, u.jwControlbarShow = s("controlbar", "show"), u.jwControlbarHide = s("controlbar", "hide"), u.jwDockShow = s("dock", "show"), u.jwDockHide = s("dock", "hide"), u.jwDisplayShow = s("display", "show"), u.jwDisplayHide = s("display", "hide");
                var h;
                return u.jwLoadInstream = function (t, n) {
                    h || (h = new e.html5.instream(u, d, p, f)), setTimeout(function () {
                        h.load(t, n)
                    }, 10)
                }, u.jwInstreamDestroy = function () {
                    h && h.jwInstreamDestroy()
                }, u.jwInstreamAddEventListener = o("jwInstreamAddEventListener"), u.jwInstreamRemoveEventListener = o("jwInstreamRemoveEventListener"), u.jwInstreamGetState = o("jwInstreamGetState"), u.jwInstreamGetDuration = o("jwInstreamGetDuration"), u.jwInstreamGetPosition = o("jwInstreamGetPosition"), u.jwInstreamPlay = o("jwInstreamPlay"), u.jwInstreamPause = o("jwInstreamPause"), u.jwInstreamSeek = o("jwInstreamSeek"), u.jwDestroy = function () {
                    f.destroy()
                }, u.jwGetLevel = function () { }, u.jwGetBandwidth = function () { }, u.jwGetLockState = function () { }, u.jwLock = function () { }, u.jwUnlock = function () { }, d.config.chromeless && !e.utils.isIOS() ? a() : u.skin.load(d.config.skin, a), u
            }
        }(jwplayer)
} ! function (e) {
    e.fn.extend({
        fmsmedia: function (t) {
            function n(t, n) {
                var s = o(t, n),
                    l = i();
                n.html('<div class="fmsmedia-player" id="' + l + '">' + n.html() + "</div>");
                var u = e("img.fmsmedia-thumb", n).attr("width"),
                    c = e("img.fmsmedia-thumb", n).attr("height"),
                    d = e("a.fmsmedia-btnplay", n).attr("href"),
                    p = n.attr("playauto"),
                    f = (e("img.fmsmedia-thumb", n).attr("alt"), a(e("img.fmsmedia-thumb", n).attr("src"), u, c)),
                    h = {
                        width: u,
                        height: c,
                        autostart: p,
                        skin: "/Images/newtubedark/newtubedark.xml",
                        controlbar: "bottom",
                        playlist: "none",
                        "playlist.position": "bottom",
                        "playlist.size": "0",
                        image: f
                    };
                if ("html5" == s) {
                    var g = d;
                    h.file = g, h.modes = [{
                        type: "html5"
                    }, {
                        type: "flash",
                        src: t.player
                    }]
                } else h.file = d, h.modes = [{
                    type: "flash",
                    src: t.player
                }, {
                    type: "html5"
                }];
                jwplayer(l).setup(h), r(t, n, l), e(window).resize(function () {
                    r(t, n, l)
                }), n.show()
            }

            function i() {
                var e = (new Date).getTime(),
                    t = "fmsmedia_xxxx_xxxx_2013".replace(/[xy]/g, function (t) {
                        var n = (e + 16 * Math.random()) % 16 | 0;
                        return e = Math.floor(e / 16), ("x" == t ? n : 7 & n | 8).toString(16)
                    });
                return t
            }

            function r(e, t, n) {
                var i = s(e, t),
                    r = i.w,
                    o = i.h;
                jwplayer(n).resize(r, o)
            }

            function s(t, n) {
                var i = n.attr("autofit"),
                    r = (e(window).width() - 20, e(window).height() - 20),
                    s = n.parent().width(),
                    o = (n.parent().height(), t.baseW),
                    a = t.baseH;
                "true" == i && (a = Math.round(a * s / o), o = s), a > r && (o = Math.round(o * r / a), a = r), n.width(o).height(a).css({
                    width: o + "px",
                    height: a + "px"
                });
                var l = new Array;
                return l.w = o, l.h = a, l
            }

            function o(e) {
                var t = "normal";
                return "undefined" != typeof navigator.plugins["Shockwave Flash"] && "true" == e.allowEmbed ? t = "embed" : document.createElement("video").canPlayType && "true" == e.allowHTML5 && (t = "html5"), t
            }

            function a(e, t, n) {
                var i = e.split("?");
                return i[0] + "?w=" + t + "&amp;h=" + n
            }

            function l(t, i) {
                if (0 == i.length) return !1;
                var r = o(t, i);
                e("a", i).each(function () {
                    var t = e(this).attr("href");
                    e(this).attr("href", t)
                }), "embed" != r && "html5" != r || n(t, i), "normal" == r && (e("a", i).each(function () {
                    var t = c + e(this).attr("href");
                    e(this).attr("href", t)
                }), e(window).resize(function () {
                    s(t, i)
                }), i.show())
            }
            var u = "",
                c = "",
                d = {
                    allowEmbed: "true",
                    allowHTML5: "true",
                    player: u + "/Scripts/fmsmedia.v2.0.0.swf",
                    expressInstall: u + "js/expressInstall.swf",
                    baseW: "650",
                    baseH: "400",
                    embed: {
                        version: "9.0.0",
                        name: "FMSMediaPlayer",
                        menu: "false",
                        wmode: "transparent",
                        allowScriptAccess: "sameDomain",
                        scale: "noscale",
                        allowFullScreen: "true",
                        salign: "lt",
                        quality: "high"
                    }
                },
                t = e.extend(d, t);
            return this.each(function () {
                var n = t;
                l(n, e(this))
            })
        }
    })
}(jQuery);