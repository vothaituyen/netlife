$(document).ready(function(){
$(".content").find("[style]").css("width", "100%");
$(".content").find("[width]").css("width", "100%");
});