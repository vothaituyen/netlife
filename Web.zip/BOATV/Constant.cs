using System;
using System.Collections.Generic;
using System.Text;

namespace BOATV
{
    public class Constant
    {
        #region Phim rap
        public const string CINE_PHIMRAP_STRING = "CINE_PHIMRAP_STRING_{0}_{1}";
        public const string CINE_PHIMRAP_DATA = "CINE_PHIMRAP_DATA_{0}_{1}";
        #endregion
        #region Trang Phim Truyen
        public const string DANH_SACH_TIN_CINE_STRING = "Danh_Sach_Tin_Cine_String{0}_{1}_{2}_{3}";
        
        #endregion
    }
}
